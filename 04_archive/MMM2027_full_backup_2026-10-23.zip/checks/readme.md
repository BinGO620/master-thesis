# 校验与去 AI 痕迹工具

这些脚本服务于论文写作过程，**不参与编译**，也不进投稿包。

⚠ 脚本里的路径全部硬编码为旧的 bundle 位置
`/data/monogs-ours/papers/maskfree_bundle/`，那是 2026-09 之前的结构。
现在论文 1 的真身在 `biyelunwen/01_small_papers/MMM2027/`。
要重新跑这些脚本，先把路径改掉。

## 文件

| 文件 | 作用 |
|---|---|
| `deai_main.py` | 对正文逐条套用去 AI 痕迹规则（冒号、破折号、否定式插入语等） |
| `deai_si.py` | 同上，针对补充材料 |
| `find_drift.py` | 检查 `body_v3.tex` 与 `manuscript_v3.md` 是否同步 |
| `mirror_md.py` | 把 tex 的改动镜像回 md |
| `sync_stale_md.py` | 同上，另一套规则 |
| `RoGS-SLAM_v3_plagcheck.docx` | 查重用的 Word 版，数字引文格式 |

## 为什么留着

`deai_*.py` 里的规则是从实际改稿中攒出来的，对写大论文时降 AI 率有参考价值，
和 `03_main/WRITING_RULES.md` 是同一类东西。`find_drift.py` 的思路
（md 与 tex 双源一致性检查）在大论文那边也能用。
