#!/usr/bin/env python3
"""Report REAL wording drift between the submitted .tex and its markdown mirror.
Comparison key = alphabetic words only, so LaTeX/markdown notation, math and
citation syntax cannot masquerade as content drift. Numbers are checked
separately, per matched sentence."""
import re, difflib

# Inline math is normalized (not dropped) so that numbers and symbols inside
# $...$ on the tex side stay comparable with the unicode math used in the md mirrors.
_MATH = [(r'\geq', '≥'), (r'\leq', '≤'), (r'\neq', '≠'),
         (r'\ge', '≥'), (r'\le', '≤'), (r'\ne', '≠'),
         (r'\rightarrow', '→'), (r'\times', '×'), (r'\approx', '≈'),
         (r'\pm', '±'), (r'\sqrt', '√'), (r'\max', 'max'), (r'\min', 'min'),
         (r'\%', '%')]
def _math(m):
    s = m.group(1)
    for k, v in _MATH:
        s = s.replace(k, v)
    s = re.sub(r'\\[a-zA-Z]+', ' ', s)
    s = s.replace('^2', '²').replace('^3', '³')
    return ' ' + s.replace('{', '').replace('}', '') + ' '

def from_tex(t):
    t = '\n'.join(l for l in t.split('\n') if not l.startswith('%'))
    for env in ('tabular', 'longtable', 'figure', 'equation'):
        t = re.sub(r'\\begin\{%s\}.*?\\end\{%s\}' % (env, env), ' ', t, flags=re.S)
    t = re.sub(r'~?\\cite\{[^{}]*\}', ' ', t)
    t = re.sub(r'\\setlength\{[^{}]*\}\{[^{}]*\}', ' ', t)
    t = re.sub(r'\\(?:begin|end)\{[^{}]*\}(?:\[[^\]]*\])?', ' ', t)
    t = re.sub(r'\$([^$]*)\$', _math, t)
    t = re.sub(r'\\(section|subsection|textbf|emph|texttt|path|textit)\*?\{([^{}]*)\}', r'\2', t)
    t = re.sub(r'\\[a-zA-Z]+\{([^{}]*)\}', r'\1', t)
    t = re.sub(r'\\[a-zA-Z]+', ' ', t)
    return t

def from_md(t):
    t = re.sub(r'^\s*\|.*$', ' ', t, flags=re.M)
    t = re.sub(r'^\s*>.*$', ' ', t, flags=re.M)
    t = re.sub(r'\$\$.*?\$\$', ' ', t, flags=re.S)
    t = re.sub(r'~?\\cite\{[^{}]*\}', ' ', t)
    t = re.sub(r'\$([^$]*)\$', _math, t)
    t = re.sub(r'\*\*|\*|`', '', t)
    t = re.sub(r'^#+\s*(?:\d+(?:\.\d+)*\.?\s*)?', '', t, flags=re.M)
    t = re.sub(r'^\s*\d+\.\s+', '', t, flags=re.M)
    return t

WORD = re.compile(r'[a-z]{3,}')
def key(s):     return ' '.join(WORD.findall(s.lower()))
def digits(s):  return re.findall(r'\d+\.?\d*', s)

def sents(text):
    out = []
    for para in re.split(r'\n\s*\n', text):
        p = re.sub(r'\s+', ' ', para).strip()
        for s in re.split(r'(?<=[.:?])\s+(?=[A-Z(])', p):
            if len(key(s).split()) >= 7:
                out.append(s.strip())
    return out

def report(texpath, mdpath, label):
    A, B = sents(from_tex(open(texpath).read())), sents(from_md(open(mdpath).read()))
    kB = {}
    for s in B:
        kB.setdefault(key(s), s)
    print(f"\n{'='*76}\n{label}\n{'='*76}")
    word_drift, num_drift = [], []
    for s in A:
        k = key(s)
        if k in kB:
            if digits(s) != digits(kB[k]):
                num_drift.append((s, kB[k]))
            continue
        m = difflib.get_close_matches(k, list(kB), n=1, cutoff=0.60)
        word_drift.append((s, kB[m[0]] if m else None))
    for i, (a, b) in enumerate(word_drift, 1):
        print(f"\n--- [{i}] wording")
        print(f"  TEX: {a[:280]}")
        print(f"  MD : {b[:280] if b else '*** MISSING FROM MD ***'}")
    for i, (a, b) in enumerate(num_drift, 1):
        print(f"\n--- [N{i}] NUMBERS {digits(a)} vs {digits(b)}")
        print(f"  TEX: {a[:280]}\n  MD : {b[:280]}")
    print(f"\n  >>> {len(word_drift)} wording, {len(num_drift)} number drift")
    return len(word_drift) + len(num_drift)

B = '/data/monogs-ours/papers/maskfree_bundle'
n  = report(f'{B}/latex/body_v3.tex',       f'{B}/manuscript_v3.md', 'MAIN: body_v3.tex -> manuscript_v3.md')
n += report(f'{B}/latex_si/si_body_v3.tex', f'{B}/supplementary.md', 'SI:   si_body_v3.tex -> supplementary.md')
print(f"\nTOTAL: {n}")
