#!/usr/bin/env python3
"""Mirror the .tex de-AI edits into the markdown sources.
Converts each LaTeX rule to markdown form, matches with flexible whitespace
(the .md is hard-wrapped), and reports every rule that does not apply so it can
be handled by hand. Never silently skips."""
import re

def rules_from(path, varname):
    """Exec just the rule-table portion of a de-AI script and return the table."""
    src = open(path).read()
    cut = min(i for i in (src.find('\ndef apply'), src.find('\ntxt = open(')) if i > 0)
    ns = {}
    exec(compile(src[:cut], path, 'exec'), ns)
    return ns[varname]

def mdify(s):
    s = re.sub(r'\\emph\{([^{}]*)\}',   r'*\1*', s)
    s = re.sub(r'\\textbf\{([^{}]*)\}', r'**\1**', s)
    s = re.sub(r'\\texttt\{([^{}]*)\}', r'`\1`', s)
    s = re.sub(r'\\path\{([^{}]*)\}',   r'`\1`', s)
    s = s.replace('\\_', '_')
    s = s.replace('$\\times$', '\u00d7').replace('$-$', '\u2212')
    s = s.replace('``', '"').replace("''", '"')
    s = s.replace('~4c', ' 4c')
    s = s.replace('---', '\u2014')
    s = re.sub(r'(?<=[0-9A-Za-z])--(?=[0-9A-Za-z])', '\u2013', s)
    return s

def flexible(text):
    """Regex matching `text` with any run of whitespace where it has a space."""
    return re.compile('[ \n]+'.join(re.escape(w) for w in text.split(' ')))

def apply_md(path, rules, skip=frozenset()):
    txt = open(path).read()
    applied, missed = [], []
    for tag, old, new in rules:
        if tag in skip:
            applied.append(f'{tag}(skip: md already current)')
            continue
        pat = flexible(mdify(old))
        if len(pat.findall(txt)) != 1:
            missed.append((tag, len(pat.findall(txt)), mdify(old)))
            continue
        txt = pat.sub(mdify(new).replace('\\', '\\\\'), txt, count=1)
        applied.append(tag)
    open(path, 'w').write(txt)
    return applied, missed

BUNDLE = '/data/monogs-ours/papers/maskfree_bundle'
JOBS = [('/tmp/deai_main.py', 'BODY_RULES', f'{BUNDLE}/manuscript_v3.md', {'X01'}),
        ('/tmp/deai_si.py',   'RULES',      f'{BUNDLE}/supplementary.md', set())]

for pyfile, var, mdpath, skip in JOBS:
    ap, ms = apply_md(mdpath, rules_from(pyfile, var), skip)
    print(f"\n=== {mdpath.split('/')[-1]}: {len(ap)} applied, {len(ms)} need manual handling ===")
    for tag, cnt, o in ms:
        print(f"  MISS {tag} (found {cnt}): {o[:115]}")
