#!/usr/bin/env python3
"""Bring the markdown mirrors back in line with the submitted .tex.
Direction is always tex -> md: the .tex is the reviewed, submitted text.
Every rule asserts exactly one match."""
import sys

MAIN = [
 # tex kept the terser scope wording; md had an older phrasing
 ("M1", "one\nlands inside the $N$-ambiguity band and is undecidable):",
        "one\nlands in the $N$-ambiguity band, undecidable):"),
 ("M2", "(`f3_wk_hf` 3.29 vs 3.25 cm for RGD-SLAM; `pt2` 10.44 vs 6.1 for DG-SLAM; Table 1, S12),\nand by 3.4× against the monocular WildGS-SLAM on `pt2` (Table 1).",
        "(`f3_wk_hf` 3.29 vs 3.25 cm, RGD-SLAM; `pt2` 10.44 vs 6.1, DG-SLAM; Table 1, S12),\nand monocular WildGS-SLAM by 3.4× on `pt2`."),
]

SI = [
 # --- stale cross-references (md still points at main-text section numbers) ---
 ("S1", "denominator used by the completion gate in Sec. 4.4.",
        "denominator used by the completion gate of S1.4."),
 ("S2", "cannot be compared against one that did not; hence Sec. 4.4.",
        "cannot be compared against one that did not; hence the completion gate of S1.4."),
 ("S3", "our rows in the protocol table (Sec. 2.4) to state a bounded rewrite scope.",
        "our rows in the protocol table (S6) to state a bounded rewrite scope."),
 ("S4", "The improvement ratios in Sec. 5.1 divide by the 3-seed rerun",
        "The improvement ratios in S3.2 divide by the 3-seed rerun"),
 # --- stale CLAIM: md forbids all competitor comparison; Table 1 does compare
 #     GPU memory against RGD-SLAM on the same 3090 ---
 ("S5", "**Efficiency numbers are only ever compared between our own configurations on identical\n"
        "hardware.** They are never placed beside a competitor's, because the hardware differs and, for at\n"
        "least one system in Sec. 2.4, is not reported at all.",
        "**Efficiency numbers are only ever compared on identical hardware: between our own\n"
        "configurations, and against our RGD-SLAM reproduction on the same RTX 3090 (the only\n"
        "same-hardware pair).** Other competitors' numbers are reported but never compared, because\n"
        "their hardware differs and, for at least one system in Sec. 2.1, is not reported at all."),
 ("S6", "deployment must pay it. Efficiency is only ever compared between our own configurations on\n"
        "identical hardware, never beside a competitor's figure.",
        "deployment must pay it. Efficiency is only ever compared on identical hardware, between our\n"
        "own configurations and against the RGD-SLAM reproduction on the same RTX 3090 (Table S5.1);\n"
        "figures from other machines are reported but never compared."),
 # --- stale NUMBER + a disclosed marginal case missing from md ---
 ("S7", "ever better than Huber** — 9 of 10 comparisons are indistinguishable within the floor\n"
        "(max(0.43 cm, 6% of the larger mean); 3 seeds, descriptive; the Huber anchor comes from the\n"
        "main-table campaign, so the ~30% cross-campaign drift discipline applies), and the single\n"
        "clear degradation reproduces on the high-dynamic person regime (Cauchy +1.8 cm and\n"
        "Geman–McClure +2.5 cm on `pt2`; Geman–McClure +1.8 cm with one bistable seed on `pt1`).",
        "ever better than Huber**. Outside `pt2`, 8 of the 10 comparisons are indistinguishable within\n"
        "the floor (max(0.43 cm, 6% of the larger mean); 3 seeds, descriptive; the Huber anchor comes\n"
        "from the main-table campaign, so the ~30% cross-campaign drift discipline applies), one is\n"
        "marginal (Geman–McClure on `balloon`, +0.46 against a 0.43 floor), and the one clear\n"
        "non-`pt2` degradation (Geman–McClure on `pt1`, +1.8 cm with one bistable seed) reproduces\n"
        "the clear `pt2` result (Cauchy +1.8, Geman–McClure +2.5 cm)."),
 # --- S10 retitled + lead sentence rewritten in tex ---
 ("S8", "## S10. The cue-split factorial, in full (Limitation 8)",
        "## S10. The cue-split factorial, in full (Limitations, Scope)"),
 ("S9", "Limitation 8 states that which cue wins is regime-dependent and that we have no selector. The\n"
        "48-run factorial behind the first half of that statement: the reliability signal's two cues",
        "The Scope note of the Limitations section in the main text reports that the sequence-level\n"
        "semantic area, the simplest cue selector tested, does not separate the regimes. The evidence\n"
        "has two halves; the first is that which cue wins is regime-dependent, and the 48-run\n"
        "factorial behind it: the reliability signal's two cues"),
 # --- stale NUMBER (Table 1 has four data columns) + sentence missing from md ---
 ("S10", "The main text's Table 1 shows five selected BONN dynamic scenes for all methods; this is",
         "The main text's Table 1 shows four selected BONN dynamic scenes for all methods; this is"),
 ("S11", "exception, recoverable to 2.67±0.27 cm at async50 but degrading balloon to 13.96 cm).",
         "exception, recoverable to 2.67±0.27 cm at async50 but degrading balloon to 13.96 cm). Body\n"
         "ratios are computed from full-precision per-run values, so they can differ in the last digit\n"
         "from quotients of the rounded values here."),
]

for path, rules in (('manuscript_v3.md', MAIN), ('supplementary.md', SI)):
    txt = open(path).read()
    for tag, old, new in rules:
        n = txt.count(old)
        if n != 1:
            print(f"  FAIL {tag} in {path}: matched {n}\n    {old[:100]!r}"); sys.exit(1)
        txt = txt.replace(old, new); print(f"  ok   {tag}  {path}")
    open(path, 'w').write(txt)
