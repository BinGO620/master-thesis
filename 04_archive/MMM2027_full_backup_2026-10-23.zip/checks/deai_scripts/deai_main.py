#!/usr/bin/env python3
"""DE-AI pass on the main paper. Every rule asserts exactly-one match before applying.
Pure ASCII output only (the converter and XeTeX both require it)."""
import re, sys

BODY = '/data/monogs-ours/papers/maskfree_bundle/latex/body_v3.tex'
MAIN = '/data/monogs-ours/papers/maskfree_bundle/latex/main_v3.tex'

# (tag, old, new) -- tag: P##=plan rule, U##=uncovered dash, N#=negation-tic, F#=frame/head, X#=defect
BODY_RULES = [
 # ---------- Introduction ----------
 ("P01", "removes them --- an external, class-conditioned network labels",
         "removes them. An external, class-conditioned network labels"),
 ("U01", "many movers in these benchmarks --- balloons, carried boxes, objects placed and removed --- have no label",
         "many movers in these benchmarks (balloons, carried boxes, objects placed and removed) have no label"),
 ("P02", "from \\emph{consistency} --- the disagreement between observed optical flow and the flow a rigid scene would produce --- and it down-weights",
         "from \\emph{consistency}, the disagreement between observed optical flow and the flow a rigid scene would produce, and it down-weights"),
 ("F01", "What is missing is evidence for two questions: \\emph{which} of its parts are necessary, on which sequences --- and is a reported gain attributable to the mechanism, or merely to the extra information it was handed?",
         "Evidence is missing on two questions: \\emph{which} of its parts are necessary, and on which sequences; and whether a reported gain is attributable to the mechanism or merely to the extra information it was handed."),
 ("P03", "\\textbf{negative on the two hardest} --- the mixed-mover and the person-hard one;",
         "\\textbf{negative on the two hardest}, the mixed-mover and the person-hard one;"),
 ("P04", "\\textbf{No sequence demonstrably rewards all three --- 0 of 5 --- so the full bundle is nowhere strictly necessary}",
         "\\textbf{No sequence demonstrably rewards all three (0 of 5), so the full bundle is nowhere strictly necessary}"),
 ("P05", "on all four (Sec. 5.4) --- closing the",
         "on all four (Sec. 5.4), closing the"),
 ("P06", "One single-variable intervention --- extending the semantic hard tracking mask of the \\emph{combined} configuration from 10 to all 100 tracking iterations --- moves",
         "One single-variable intervention, extending the semantic hard tracking mask of the \\emph{combined} configuration from 10 to all 100 tracking iterations, moves"),
 ("U02", "falling ($-$0.0248, 1.38$\\times$) --- on one sequence, with two legs near their floors (Sec. 5.6). The consequence generalises beyond this system: \\textbf{name the endpoint}.",
         "falling ($-$0.0248, 1.38$\\times$). This rests on one sequence, with two legs near their floors (Sec. 5.6). The consequence generalises beyond this system: a pose-side claim must \\textbf{name its endpoint}."),
 # ---------- Related Work ----------
 ("P07", "class-conditioned model --- with the costs named in Sec. 1.",
         "class-conditioned model, with the costs named in Sec. 1."),
 ("U03", "as ``not using class priors'' --- the class prior is removed, a learned appearance prior remains.",
         "as ``not using class priors''. The class prior is removed; a learned appearance prior remains."),
 ("P08", "never \\emph{prior-free} --- it, too, keeps a pretrained network (the frozen RAFT flow of Sec. 3.4) --- so the distinction",
         "never \\emph{prior-free}; it, too, keeps a pretrained network (the frozen RAFT flow of Sec. 3.4), so the distinction"),
 ("P09", "individually classical --- robust M-estimation (Huber~\\cite{huber}), residual reweighting, and keyframe management all have ample precedent --- and our backbone, MonoGS~\\cite{monogs},",
         "individually classical: robust M-estimation (Huber~\\cite{huber}), residual reweighting, and keyframe management all have ample precedent. Our backbone, MonoGS~\\cite{monogs},"),
 # ---------- Method ----------
 ("P10", "forces an insert --- the native criterion is floored, not replaced.",
         "forces an insert; the native criterion is floored, not replaced."),
 ("F02", "\\textbf{Two flows, one disagreement.}", "\\textbf{Observed and rigid flow.}"),
 ("P11", "depth and ego-motion --- the mover shows up in that disagreement",
         "depth and ego-motion. The mover shows up in that disagreement"),
 ("U04", "reconstruct the static office --- mask-free without any class label.",
         "reconstruct the static office, the mask-free one without any class label."),
 ("P19", "run's saved final map --- illustration, not a benchmark metric.",
         "run's saved final map; illustration, not a benchmark metric."),
 ("P12", "\\textbf{never removed} --- the sharpest difference from a mask, and the comparison",
         "\\textbf{never removed}, the sharpest difference from a mask and the comparison"),
 ("P13", "lifecycle of Sec. 3.5 --- a \\emph{pair} of interventions",
         "lifecycle of Sec. 3.5, a \\emph{pair} of interventions"),
 ("F03", "\\textbf{A limitation the estimator creates.}", "\\textbf{Limitation of the robust knee.}"),
 ("P14", "setting its own knee --- one reason the mask stays dominant",
         "setting its own knee, one reason the mask stays dominant"),
 ("P15", "load-bearing --- the deleted fraction of created lineages has median \\textbf{0.55} --- so",
         "load-bearing (the deleted fraction of created lineages has median \\textbf{0.55}), so"),
 ("P16", "the \\textbf{tracking residual} --- the last only for the first",
         "the \\textbf{tracking residual}, the last only for the first"),
 # ---------- Protocol ----------
 ("P17", "18 RGB-D sequences --- 8 BONN RGB-D Dynamic~\\cite{bonn}, 10 TUM RGB-D~\\cite{tumrgbd} --- spanning",
         "18 RGB-D sequences (8 BONN RGB-D Dynamic~\\cite{bonn}, 10 TUM RGB-D~\\cite{tumrgbd}), spanning"),
 ("P18", "\\textbf{compared only on identical hardware} --- between our own configurations, and against",
         "\\textbf{compared only on identical hardware}, between our own configurations and against"),
 ("U05", "each reported cell maps to exactly one run directory --- where a seed was run more than once, the latest qualifying run is used",
         "each reported cell maps to exactly one run directory, and where a seed was run more than once the latest qualifying run is used"),
 # ---------- Results ----------
 ("P20", "share one RTX 3090 --- the only same-hardware pair;",
         "share one RTX 3090, the only same-hardware pair;"),
 ("P21", "(1.92--3.96$\\times$) --- a split Sec. 5.5 tracks",
         "(1.92--3.96$\\times$), a split Sec. 5.5 tracks"),
 ("P22", "A pre-registered factorial over K, R, L --- 8 cells $\\times$ 5 sequences $\\times$ 3 seeds = 120 runs, mask-free, D pinned identically in all cells.",
         "The pre-registered factorial varies K, R, and L (8 cells $\\times$ 5 sequences $\\times$ 3 seeds = 120 runs); it runs mask-free, with D pinned identically in all cells."),
 ("P23", "support rule instead --- a cell supports a component only where",
         "support rule instead: a cell supports a component only where"),
 ("U06", "\\textbf{no sequence has all three components supported --- 0 of 5 --- so the full bundle is nowhere strictly necessary across the five measured sequences}",
         "\\textbf{no sequence has all three components supported (0 of 5), so the full bundle is nowhere strictly necessary across the five measured sequences}"),
 ("P24", "on \\texttt{balloon} and \\texttt{pt1} --- uniform temporal sampling hurts",
         "on \\texttt{balloon} and \\texttt{pt1}: uniform temporal sampling hurts"),
 ("N01", "so the crowd result is attributed to the bundle, not to one component.",
         "so the crowd result is attributed to the bundle rather than to any one component."),
 ("N02", "this control rules out the information alone, not every flow-consuming treatment.",
         "this control rules out the information alone; it does not rule out every flow-consuming treatment."),
 ("P25", "differing 12.6-fold --- per-frame drift tracks mask necessity",
         "differing 12.6-fold: per-frame drift tracks mask necessity"),
 ("F04", "\\textbf{What this is.} The interval requires \\emph{running} the mask-free arm --- a post-hoc diagnosis, not a selector.",
         "\\textbf{Scope of the interval.} The interval requires \\emph{running} the mask-free arm, which makes it a post-hoc diagnosis rather than a selector."),
 ("U07", "8 of the 10 decidable agree in direction --- 4 of 5 in the first round (the squares in Fig.~4c), 4 of 6 in the second (S8) --- no frozen-sense counterexample ($N \\le 0.8$), both misses \\textbf{conservative};",
         "8 of the 10 decidable agree in direction (4 of 5 in the first round, the squares in Fig.~4c; 4 of 6 in the second, S8), with no frozen-sense counterexample ($N \\le 0.8$) and both misses \\textbf{conservative};"),
 ("P27", "One intervention --- extending the semantic hard tracking mask from 10 to 100 iterations in combined, while retaining soft reliability on surviving static pixels --- changes",
         "One intervention, extending the semantic hard tracking mask from 10 to 100 iterations in combined while retaining soft reliability on surviving static pixels, changes"),
 # ---------- Limitations: duplicated phrase introduced by an earlier hand-edit ----------
 ("X01", "combined trails the best RGB-D dynamic comparator by 1.0--1.7$\\times$ on the walking and person sequences (\\texttt{f3\\_wk\\_hf}",
         "combined trails the best RGB-D dynamic comparator in our tables by 1.0--1.7$\\times$ (\\texttt{f3\\_wk\\_hf}"),
]

MAIN_RULES = [
 ("P28", "over three of its four components ---\nuniform temporal keyframe coverage, robust residual reweighting, and a\nflow-consistency reliability signal; the density lifecycle is held fixed --- finds that component necessity is",
         "over three of its four components (uniform\ntemporal keyframe coverage, robust residual reweighting, and a\nflow-consistency reliability signal; the density lifecycle is held fixed) finds that component necessity is"),
 ("P29", "\\emph{regime-dependent} --- no sequence demonstrably rewards",
         "\\emph{regime-dependent}: no sequence demonstrably rewards"),
]

def apply(path, rules):
    txt = open(path).read()
    orig = txt
    for tag, old, new in rules:
        n = txt.count(old)
        if n != 1:
            print(f"  FAIL {tag}: matched {n} times (need 1)")
            print(f"       old={old[:90]!r}")
            sys.exit(1)
        txt = txt.replace(old, new)
        print(f"  ok   {tag}")
    if not txt.isascii():
        bad = [c for c in set(txt) if not c.isascii()]
        print(f"  FAIL non-ASCII introduced: {bad}"); sys.exit(1)
    open(path, 'w').write(txt)
    return orig, txt

for path, rules, label in ((BODY, BODY_RULES, 'body_v3.tex'), (MAIN, MAIN_RULES, 'main_v3.tex')):
    print(f"\n=== {label} ({len(rules)} rules) ===")
    o, t = apply(path, rules)
    tot = len(re.findall(r'(?<!-)---(?!-)', t))
    ph  = len(re.findall(r'(?:&\s*---\s*(?:&|\\\\))', t))
    print(f"  dashes after: total={tot} placeholder={ph} prose={tot-ph}")
