#!/usr/bin/env python3
"""DE-AI pass on the SI. Assert-exactly-once; ASCII-only.
Deliberately KEPT (paired appositive is the clearest mark there): L143 lifecycle
variant, L315 protocol-difference enumeration, L459 four-arm list = 6 dashes.
NOT TOUCHED: L59 ``---'' is a quoted glyph naming the table's not-run marker."""
import re, sys

SI = '/data/monogs-ours/papers/maskfree_bundle/latex_si/si_body_v3.tex'

RULES = [
 ("S01", "\\textbf{18 RGB-D sequences} --- 8 from BONN RGB-D Dynamic and 10 from TUM RGB-D --- spanning",
         "\\textbf{18 RGB-D sequences} (8 from BONN RGB-D Dynamic and 10 from TUM RGB-D), spanning"),
 ("S02", "cannot be compared against one that did not --- hence the completion gate of S1.4.",
         "cannot be compared against one that did not; hence the completion gate of S1.4."),
 ("S03", "In the one instance where this was measured directly --- the same configuration and seed executed twice, both completing all 873 frames --- the two runs differed by",
         "In the one instance where this was measured directly (the same configuration and seed executed twice, both completing all 873 frames), the two runs differed by"),
 ("S04", "optimises Gaussian parameters only --- it performs no pose optimisation step --- so the trajectory we report is not modified by it.",
         "optimises Gaussian parameters only and performs no pose optimisation step, so the trajectory we report is not modified by it."),
 ("S05", "run is used for every metric of that cell --- so that a cell's trajectory error and its rendering metrics always come from the same run --- and the duplicate is listed explicitly",
         "run is used for every metric of that cell, so that a cell's trajectory error and its rendering metrics always come from the same run, and the duplicate is listed explicitly"),
 ("S06", "& 2.0 --- \\textbf{inert} &", "& 2.0 (\\textbf{inert}) &"),
 ("S07", "\\path{slam_frontend.py:863-870}) --- an attribution our own earlier draft got wrong.",
         "\\path{slam_frontend.py:863-870}); our own earlier draft got this attribution wrong."),
 ("S08", "well defined and byte-reproducible --- the floor is 0.10 in both configurations --- but the constant is not stored",
         "well defined and byte-reproducible (the floor is 0.10 in both configurations), but the constant is not stored"),
 ("S09", "$\\delta$ is fixed at 0.10 throughout --- the kernel $\\times$ $\\delta$ interaction is untested.",
         "$\\delta$ is fixed at 0.10 throughout; the kernel $\\times$ $\\delta$ interaction is untested."),
 ("S10", "rendering numbers are not reproduced here --- they come from a different measurement chain",
         "rendering numbers are not reproduced here; they come from a different measurement chain"),
 ("S11", "compared on identical hardware --- between our own configurations, and against the RGD-SLAM reproduction",
         "compared on identical hardware, between our own configurations and against the RGD-SLAM reproduction"),
 ("S12", "We tested the obvious fix --- restricting PSNR to a static band --- and it accounts for",
         "We tested the obvious fix, restricting PSNR to a static band, and it accounts for"),
 ("S13", "sequence-specific rather than a constant --- elsewhere the same-seed spread has been as small as 0.05--0.59 cm and as large as 2.99 vs 33.70 cm --- so no single measurement",
         "sequence-specific rather than a constant (elsewhere the same-seed spread has been as small as 0.05--0.59 cm and as large as 2.99 vs 33.70 cm), so no single measurement"),
 ("S14", "coherence is $\\approx$0.93 for both arms --- dominated by trajectory drift, structurally unable to separate them.",
         "coherence is $\\approx$0.93 for both arms, dominated by trajectory drift and structurally unable to separate them."),
 ("S15", "re-run floor of 0.0180 --- the 1.38$\\times$ margin reported in the body.",
         "re-run floor of 0.0180, the 1.38$\\times$ margin reported in the body."),
 ("S16", "nearly equal to its between-seed noise --- itself consistent with the variance-side of the mechanism:",
         "nearly equal to its between-seed noise, itself consistent with the variance-side of the mechanism:"),
 ("S17", "supports the decomposition --- the covariate exists nowhere else, so the conclusion is sequence-local.",
         "supports the decomposition; the covariate exists nowhere else, so the conclusion is sequence-local."),
 ("S18", "as \\emph{a} mechanism, not the only one --- a map-side contribution to the ATE gain is not excluded.",
         "as \\emph{a} mechanism, not the only one. A map-side contribution to the ATE gain is not excluded."),
 ("S19", "regression against the emitted verdict) --- a gate that never fails is not a gate.",
         "regression against the emitted verdict); a gate that never fails is not a gate."),
 ("S20", "fusion as a universal kernel --- but \\path{mv_no_box} is the counterexample",
         "fusion as a universal kernel, but \\path{mv_no_box} is the counterexample"),
 ("S21", "reverses that (geometry best, flow worst) --- a direct instance of why the protocol requires 3 seeds",
         "reverses that (geometry best, flow worst), a direct instance of why the protocol requires 3 seeds"),
 ("S22", "The second half of the limitation --- the selector candidate we tested and rejected --- is sequence-level semantic area:",
         "The second half of the limitation (the selector candidate we tested and rejected) is sequence-level semantic area:"),
 ("S23", "\\textbf{Cross-seed dispersion understates total dispersion} --- see S5.",
         "\\textbf{Cross-seed dispersion understates total dispersion}; see S5."),
 ("S24", "\\textbf{Rendering metrics do not corroborate trajectory claims} --- see S5.",
         "\\textbf{Rendering metrics do not corroborate trajectory claims}; see S5."),
 ("S25", "did not improve separation --- it fell to 0.99 at K=8 --- so the per-frame estimate",
         "did not improve separation (it fell to 0.99 at K=8), so the per-frame estimate"),
 ("S26", "degenerated to $\\le$1\\% --- narrower than the noise tolerance, i.e. indistinguishable",
         "degenerated to $\\le$1\\%, narrower than the noise tolerance, i.e. indistinguishable"),
 ("S27", "\\textbf{Optical flow cost is outside the online figures} --- see S5.",
         "\\textbf{Optical flow cost is outside the online figures}; see S5."),
]

txt = open(SI).read()
for tag, old, new in RULES:
    n = txt.count(old)
    if n != 1:
        print(f"  FAIL {tag}: matched {n} (need 1)\n       {old[:95]!r}"); sys.exit(1)
    txt = txt.replace(old, new); print(f"  ok   {tag}")
if not txt.isascii():
    print("  FAIL non-ASCII"); sys.exit(1)
open(SI, 'w').write(txt)

tot = len(re.findall(r'(?<!-)---(?!-)', txt))
ph  = len(re.findall(r'(?:&\s*---\s*(?:&|\\\\))', txt))
quoted = len(re.findall(r"``---''", txt))
print(f"\n  dashes after: total={tot} placeholder={ph} quoted-glyph={quoted} "
      f"prose-kept={tot-ph-quoted}")
