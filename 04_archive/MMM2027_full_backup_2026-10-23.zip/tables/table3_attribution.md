| Sequence | simpler arm | +coverage | +reliability | full arm |
|---|---:|---:|---:|---:|
| `mv_no_box` | 3.65±0.33 | **2.71±0.04** | 3.46±0.25 | 2.63±0.09 |
| `crowd2` | 6.89±1.64 | 5.16±2.25 | 6.00±2.11 | 2.11±0.08 |
