| Sequence | mask-free | combined | ratio | reading |
|---|---:|---:|---:|---|
| `mv_no_box2` | 5.62±0.30 | 5.14±0.28 | 1.09× | mask redundant |
| `mv_no_box` | 3.09±0.46 | 2.66±0.12 | 1.16× | mask redundant |
| `pt2` | 9.30±0.64 | 10.44±0.84 | 0.89× | mask redundant (mask-free marginally better) |
| `balloon2` | 10.14±0.62 | 5.28±0.11 | 1.92× | mask dominant |
| `pt1` | 32.41±8.51 | 11.89±2.36 | 2.73× | mask dominant |
| `balloon` | 12.11±2.33 | 3.06±0.14 | 3.96× | mask dominant |
