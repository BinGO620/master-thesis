# MMM 2026 Review

Overall recommendation: Weak Reject

Confidence: 4/5

Dimension scores: relevance to MMM 3/5; novelty 2/5; technical soundness 2/5; presentation quality 3/5; experimental rigor 2/5.

## Summary

The manuscript presents RoGS-SLAM, a dynamic-scene RGB-D Gaussian-splatting SLAM configuration using flow-based reliability weighting, robust residual weighting, denser keyframe coverage, and a lineage-based Gaussian lifecycle (Secs. 3.1-3.5). Its main contribution is positioned as an empirical attribution study rather than a novel primitive, including a 120-run factorial, an equal-flow comparison, and a pose-error decomposition (Secs. 1 and 5.2-5.6). The paper is unusually explicit about negative results, static-scene degradation, unstable baselines, excluded flow cost, and the cases in which a semantic mask remains necessary (Secs. 5.7 and 6). However, the principal factorial conclusion is logically inconsistent with the manuscript's own definition and measurements. The paper also describes four load-bearing components while factorially testing only three, with the fourth held fixed despite being described as load-bearing (Secs. 3.1, 3.5, and 5.2). Several central claims cannot be independently assessed because their protocols, complete results, and validation details are assigned to supplementary items S1-S12 that are not present in the submitted PDF. Consequently, the current manuscript does not establish its central attribution claims reliably enough for acceptance.

## Strengths

- The method's attachment points and the distinction between mask-free and combined configurations are explained clearly (Fig. 1 / Secs. 3.1 and 3.6).
- The comparisons use three seeds and report standard deviations, completion criteria, alignment conventions, and important protocol caveats (Sec. 4 / Tables 1-3).
- The authors report unfavorable evidence rather than suppressing it, including mask-free failures, severe static-scene degradation, baseline instability, and the external cost of RAFT (Sec. 6).
- Table 1 separates RGB-D 3DGS, monocular 3DGS, other dynamic SLAM, and classical/backbone systems, which helps prevent an undifferentiated state-of-the-art claim (Table 1 / Sec. 5.1).
- The limitations are substantive rather than cosmetic, particularly the single-backbone scope, post-hoc diagnostic status, and failure under large dynamic occupancy (Secs. 3.4, 5.5, and 6).

## Major Concerns

- **R1-M1, Blocking: Yes. Location: Sec. 5.2 / Eq. 2 / Fig. 3 / Abstract / Sec. 1.**
  **Concern:** The central factorial conclusion contradicts the stated mathematical question. Section 5.2 defines a globally necessary component as one satisfying `exists f: Delta_f(s) >= 0 for all s`. The same section reports that L is never negative on all five sequences, explicitly "5/5." Therefore, by the paper's own definition, L is globally necessary. The observation that no individual sequence has all three components positive, "0 of 5," answers a different question. It does not establish that no globally necessary component or subset exists. In addition, Eq. 2 does not make clear whether each reported effect is a marginal factorial effect averaged over the other factors or a removal from the all-enabled configuration. The eight-cell design suggests the former, while the notation `E[log ATE | full, s]` suggests the latter; support for the exact estimand is not locatable in the PDF.
  **Why it matters:** "No globally necessary subset exists" is a headline conclusion in the abstract, Introduction, Fig. 3, Sec. 5.2, and Conclusion. The reported data support the opposite answer for L under the manuscript's definition.
  **What would resolve it:** Define the factorial estimand and recompute the intended logical proposition, then align Eq. 2, the bottom strip of Fig. 3, and every headline statement. If the intended claim concerns the necessity of the complete three-component bundle rather than any component, it must be stated as such and cannot be presented as the answer to the current existential definition.

- **R1-M2, Blocking: No. Location: Abstract / Secs. 3.1, 3.5, and 5.2 / Fig. 1.**
  **Concern:** The abstract calls K, R, and L "the three components this core adds," but Sec. 3.1 states that RoGS-SLAM adds four components, including the lineage lifecycle D. Section 3.5 calls D "load-bearing" and reports a median deleted-lineage fraction of 0.55, while the factorial fixes D identically in every cell (Sec. 5.2). Thus, the experiment assesses K, R, and L only conditional on D, not component necessity for the full RoGS-SLAM core.
  **Why it matters:** The paper's primary novelty is the claimed measurement of component necessity. Omitting a component that materially changes the map from that analysis prevents the stated system-level conclusion. This does not invalidate the conditional K/R/L measurements, so the concern is major but not independently blocking if the claim is narrowed.
  **What would resolve it:** Either include D in a suitable necessity analysis or narrow all claims explicitly to the conditional effects of K, R, and L given the fixed lifecycle D. The abstract and contribution list must no longer describe these as all components added by the core.

- **R1-M3, Blocking: Yes. Location: Secs. 2-6, references to S1-S12.**
  **Concern:** Load-bearing evidence is repeatedly deferred to supplementary material that is not contained in the reviewed PDF. This includes the full preregistered protocol (S1), constants and lifecycle variants (S2), six-sequence mask comparison (S3), rendering results (S5), cross-system protocol differences (S6), cross-sequence mechanism check (S7), held-out threshold tests (S8), bundle attribution and cue analysis (S10), reproducibility limitations (S11), and the full 18-sequence results (S12). Their contents and consistency are not assessable from the PDF alone; support not locatable. This is an assessment boundary, not evidence that the analyses were not performed.
  **Why it matters:** The main paper relies on these items to substantiate preregistration, non-selection, reproducibility, generalization, and several numerical conclusions. Without them, the central empirical case cannot be audited.
  **What would resolve it:** Provide the referenced supplement as part of the review package. At minimum, the main paper must contain enough protocol, complete-result, and held-out-split information to verify its headline claims independently.

- **R1-M4, Blocking: No. Location: Abstract / Secs. 1 and 5.6.**
  **Concern:** The pose-side result is framed as a "confirmed" variance-bias mechanism and as a lesson that generalizes beyond this system. Yet only the balloon sequence has the required per-frame annotation, while the cross-sequence check is below its noise floor (Sec. 5.6). The decomposition also assumes a zero-mean noise term, but validation of that assumption and the measurement procedure for the coherent component is not locatable in the main PDF.
  **Why it matters:** The numerical observation on balloon is potentially useful, but the present wording promotes a single-sequence, partly post-hoc analysis into a general mechanism claim.
  **What would resolve it:** Either provide adequately powered cross-sequence evidence and define how the decomposition is estimated, or consistently frame this result as a descriptive case study and hypothesis.

## Minor Comments

- **R1-m1, location: Abstract / Sec. 1 / Table 1.** The 147.5 cm backbone result is locatable in Table 1, but the 39.3 cm mixed-mover value and the "roughly 1.5 cm" static value are not shown in the main displays; support not locatable. **Required correction:** Cite a visible table or state that these values are reported only in the supplement.
- **R1-m2, location: Sec. 5.4 / Fig. 4a,b and caption.** "0.90x vanilla" is called worse, although panel b defines the displayed quantity as a log ATE ratio to vanilla, for which worse performance corresponds to an ATE ratio above 1. **Required correction:** Define the direction and numerator of every ratio consistently in the text, axes, and caption.
- **R1-m3, location: Table 1.** The adjacent headers "Avg." and "GPU (GB)" visually read as one heading, while only selected memory values are same-hardware measurements. **Required correction:** Separate these columns more clearly and mark directly in the table which memory entries are reproduced versus author-reported.
- **R1-m4, location: Sec. 5.5 / Fig. 4c caption.** The caption says the grey held-out point "lands in-band," whereas the prose says no RPE fell inside "the band." These appear to refer to different bands, one for N and one for RPE, but the terminology is ambiguous. **Required correction:** Name the mask-necessity ambiguity band and the RPE threshold interval separately.
- **R1-m5, location: Sec. 5.7 / Table 3.** The statement that the memory gap is caused by the lifecycle rather than map size is not established by Table 3. Both reported arms use the lifecycle, their Gaussian counts differ, and their memory standard deviations are larger than the difference between their means. **Required correction:** Remove the causal attribution or provide a controlled memory decomposition.
- **R1-m6, location: Abstract / Table 1 / Sec. 5.1.** The abstract compares 4.0 GB with 7.4 GB for "the strongest segmentation-based system," but Table 1 does not define "strongest." RGD-SLAM is the closest RGB-D 3DGS method on the two crowd columns, whereas DG-SLAM has the lower four-scene average. **Required correction:** Name the comparator directly and state the criterion under which it is selected.
- **R1-m7, location: Sec. 1 / Fig. 3 caption / Sec. 5.2.** The Introduction calls R "indistinguishable from zero" on three sequences, but the manuscript reports only three-seed descriptive summaries and explicitly labels small effects as directional. No equivalence or inferential test is locatable. **Required correction:** Replace "indistinguishable from zero" with wording such as "small relative to the observed seed spread" or supply the analysis that supports statistical indistinguishability.

## Questions to Authors

1. Under Eq. 2, why is L, which has `Delta_L > 0` on all five sequences, not a globally necessary component?
2. Was the complete S1-S12 supplement included in the actual submission package, and where can reviewers locate it?
3. What conclusions about component necessity remain if the lineage lifecycle D is removed or varied?
4. Which sequences established the RPE midpoint, which were first-round held-out tests, and which were second-round tests?
5. What is the resulting end-to-end FPS when the 54 ms RAFT cost and any data-transfer cost are included, and are flow inference and SLAM execution sequential or overlapped?

## MMM Fit Assessment

The work concerns RGB-D video, visual motion, reconstruction, and scene modeling, so it is relevant to MMM despite being primarily a single-media SLAM paper (Secs. 3-5). Its multimedia relevance is moderate rather than central, but the topic is within a reasonable interpretation of MMM's visual-media modeling scope.
