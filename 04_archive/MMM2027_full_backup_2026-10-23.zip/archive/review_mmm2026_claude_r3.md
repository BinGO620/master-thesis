# Review — MMM 2026 (Round 3, independent)

**Paper:** RoGS-SLAM: Robust Dynamic-Scene Gaussian Splatting SLAM via Reliability-Guided Weighting and Coverage Sampling
**Reviewer expertise:** multimedia content analysis, dynamic scene reconstruction and visualization
**Material read:** Main PDF (14 pp: 12 body + 2 references), Supplementary PDF (9 pp). All five figures and Table 1 inspected as rendered page images at 300–400 dpi in addition to text extraction.
**Independence note:** No prior `review_*.md` in the bundle was opened. All findings below were derived from the two PDFs.

---

## Summary

The paper addresses a real and well-posed failure: an unmodified 3DGS-SLAM backbone (MonoGS) interprets moving-object residuals as camera motion and drifts to 39–147 cm on dynamic RGB-D benchmarks against ~1.5 cm on static ones. Rather than the dominant detect-then-exclude response, the authors down-weight pixels according to the disagreement between observed RAFT flow and the flow a rigid scene would produce, combined multiplicatively with a depth-residual cue, with a weight floored at 0.10 so no pixel is ever removed (Sec. 3.4, p5).

The unusual move is the framing. The authors explicitly decline to claim the mask-free operation as novel ("Operating without semantic segmentation is not itself a contribution we claim; prior work has done that", Sec. 1, p2) and instead offer three *measurements* as the contribution: (i) a pre-registered 120-run three-factor factorial showing component necessity is regime-dependent and that no sequence rewards all three components; (ii) a flow-budget control showing the gain is not attributable to the extra information alone; (iii) a three-endpoint pose-side measurement showing one intervention moves per-frame and full-trajectory error in opposite directions.

The empirical discipline is genuinely above the norm for this subfield: a fixed 18-sequence denominator declared in advance, a 95%-completion gate, 3 seeds everywhere, every competitor row reproduced by the authors under one protocol, hardware comparability explicitly scoped to a single same-GPU pair, and a supplementary section that discloses an inert configuration field, a configuration-hygiene wart, and a prior attribution error in the authors' own draft.

My concerns are almost entirely about *framing, self-sufficiency, and venue fit* rather than about whether the experiments were done correctly. Three of them are structural: the title names the two mechanisms the paper's own evidence supports least; the main text never states that on four of the eighteen pre-registered sequences the method is worse than doing nothing (one by ~10×); and multimedia relevance is not argued anywhere in the submission. Several concrete figure defects (collisions, an inverted sign convention, a caption rule that contradicts its own figure) compound the presentation problems.

---

## Strengths

**S1. The controlled flow-budget experiment is the right experiment, and it is cleanly executed (Sec. 5.4, p10; Fig. 4a–b, p11).**
The obvious objection to any flow-consuming method — "your gain is the flow, not your mechanism" — is answered by handing a naive p90 threshold the *byte-identical* frozen flow ("Frozen optical flow is precomputed and stored per sequence, which makes the flow input byte-identical across every arm that consumes it", S1.8) under a pre-registered rule ("3 arms × 4 sequences × 3 seeds = 36 runs, rule fixed before the first"). The result is decisive in the honest direction: the naive counterpart is *worse than vanilla* on pt2 while the authors' weighting improves on 4 of 4. This is a better-designed control than most papers in this area attempt, and the authors correctly bound what it establishes ("this control rules out the information alone; it does not rule out every flow-consuming treatment").

**S2. The paper applies its own critical standard to itself (Sec. 2.2, p3; S2, SI pp2–3).**
Sec. 2.2 notes that WildGS-SLAM's "Prior Free" label survives only because the *class* prior is dropped while a learned appearance prior remains, then immediately concedes the same about RoGS-SLAM: "our label for our own configuration is mask-free, never prior-free; it, too, keeps a pretrained network (the frozen RAFT flow of Sec. 3.4)". S2 goes further and discloses an unreachable configuration field ("The one inert field, reported rather than removed"), a misplaced constant ("One configuration-hygiene wart, stated rather than tidied"), and a self-correction ("our own earlier draft got this attribution wrong"). This is rare and should be preserved in any revision.

**S3. Reproduction under a single protocol, with comparability explicitly scoped (Table 1, p8; S1.6, S6).**
"every row, competitors included, is our own reproduction under one protocol" (Table 1 caption) is much stronger than the usual practice of copying published numbers, and S6 lists the axes along which cross-system absolutes should *not* be read (input modality, which pretrained networks are consumed, how far back the trajectory is rewritten, hardware), closing with "No conclusion in this paper rests on that table." The GPU column is likewise scoped to "the only same-hardware pair".

**S4. Fig. 2 (p6) is an excellent, genuinely self-contained figure.**
It shows the failure mode (movers' ghost trails circled), both repairs, ATE annotated on the two treatment panels, and the timing logic (frame 80 with movers, frame 400 after they leave). Its caption pre-empts over-reading — "The two arms' maps are similar here; they differ in tracking stability, not map appearance" and "Post-hoc offline renders ... illustration, not a benchmark metric". A reader who saw only this figure would understand the paper's problem and its result. It is the one figure that needs no repair.

**S5. Negative and null results are reported rather than buried (S2.1, S10, S11 items 5–6).**
A rejected lifecycle variant ("was not adopted: its trajectory error was worse on 4 of 6 sequences"), a failed temporal aggregation ("it fell to 0.99 at K=8"), and a closed-out weight family ("the worst case doubled the error ... The safe share of re-admitted dynamic pixels degenerated to ≤1%") are all recorded with the lesson attached. S10 additionally documents a single-seed screen that the 3-seed factorial *reversed*, and states why single-seed conclusions are never quoted in the body.

---

## Major Concerns

### C1. The title names the two mechanisms the paper's own measurements support least

**Location:** Title, p1; Fig. 3, p10; Sec. 5.2, p9; S4, SI p4; S10, SI p8.

**Title:** "RoGS-SLAM: Robust Dynamic-Scene Gaussian Splatting SLAM via **Reliability-Guided Weighting and Coverage Sampling**"

Against this, the paper's own evidence:

*On coverage.* Fig. 3 gives ΔK = **−0.18 ± 0.13** on balloon and **−0.20 ± 0.18** on pt1. Both meet the paper's own support rule (|mean| ≥ 1 sd, though pt1 only marginally), so these are not "undetermined" cells — coverage is *supported-negative* on the two hardest sequences. Sec. 5.2 states it plainly: "uniform temporal sampling hurts on the mixed-mover sequence and the hardest person one." S4 states it more strongly still, and this is the sentence that matters most: **"On balloon the mask axis moves ATE roughly fourfold while the coverage axis moves it essentially not at all (3.06 vs 3.03), which is consistent with the negative coverage marginal reported in Sec. 5.2 and is why we do not describe coverage as the kernel."**

*On reliability-guided weighting.* ΔL is positive on 5 of 5 but "3 of the 5 cells are directional" (Sec. 5.2) — i.e. undetermined under the paper's own rule. Worse for the title, S10 reports that the *shipped* multiplicative fusion is beaten by a simpler ablation on most sequences: "Geometry-only takes the lowest mean on 3 of 4 sequences, which is why the body refuses to describe fixed multiplicative fusion as a universal kernel" (balloon 12.25 vs 13.85; mv_no_box2 4.88 vs 5.67; pt2 8.78 vs 9.18).

I want to be fair about what is and is not hidden: the *body* does disclose the negative coverage marginal (Sec. 1 contribution 1, p2; Sec. 5.2, p9). The problem is that the title asserts, as the paper's identity, exactly what the body and SI spend their pages qualifying. A reviewer reading title-then-Fig. 3 will read this as overclaiming, and the S4 sentence quoted above will be turned against the authors verbatim. The gap between "via Coverage Sampling" and "we do not describe coverage as the kernel" is not a nuance a reader is obliged to reconcile on the authors' behalf.

**Minimum fix required:** (a) Retitle so the title names what the paper establishes rather than which knobs it ships — the regime-dependence of component necessity and the controlled attribution are the defensible headline. (b) Promote S4's "we do not describe coverage as the kernel" sentence and S10's geometry-only result into the main text; both are currently reachable only by a reader who works through the SI (and S4 is not even cited from the body — see M10).

### C2. The main text never states that on 4 of the 18 pre-registered sequences the method is worse than doing nothing — one by ~10×

**Location:** Sec. 6 Limitations, p12; Sec. 1, p2; Sec. 5.5, p10; S12, SI p9.

From S12, comparing the unmodified backbone against the two RoGS-SLAM arms:

| sequence | MonoGS | mask-free | combined |
|---|---|---|---|
| f3_st_hf | 2.80 ± 0.92 | **35.59 ± 0.47** | **29.43 ± 8.00** |
| f3_st_xyz | 1.66 ± 0.04 | 2.66 ± 0.64 | 4.69 ± 0.71 |
| f2_person | 6.30 ± 0.40 | 6.79 ± 0.18 | 7.34 ± 0.25 |
| f2_xyz | 1.66 ± 0.13 | 1.91 ± 0.03 | 1.93 ± 0.03 |

On f3_st_hf the method is **10.5× (combined) and 12.7× (mask-free) worse than doing nothing**, on an in-denominator sequence.

Sec. 6 lists five limitations. Item 3 is the only one about degradation, and it is explicitly scoped away from the benchmark: "On Replica [16] **outside the pre-registered denominator**, combined is worse and less stable than the backbone". Item 2 ("Accuracy scope") frames the shortfall only as *trailing comparators* by 1.0–1.7×, not as regressing against the backbone. Nothing in the twelve body pages tells the reader that four in-denominator sequences regress.

Two things sharpen this into a Major rather than a Minor.

First, Sec. 1 (p2) claims: **"we claim no state-of-the-art accuracy, and the full 18-sequence table is given without selective highlighting (S12)."** Providing the table in the SI while the body names only the favourable comparisons *is* selective highlighting, by omission. The claim of non-selectivity is the one claim in the paper that the paper's own structure contradicts.

Second, Sec. 5.5 (p10) uses f3_st_hf as its *illustrative example* — "f3_st_hf and crowd have nearly identical mask-free ATE yet N differing 12.6-fold: per-frame drift tracks mask necessity, accumulated error does not" — without ever mentioning that on that same sequence both arms are an order of magnitude worse than the unmodified backbone. Choosing the paper's worst regression as a positive illustration, and describing it only in terms of a ratio between the two treatment arms, reads badly.

The authors clearly know: S12 carries a ‡ footnote ("the f3_st_hf training-budget exception, recoverable to 2.67 ± 0.27 cm at async50 but degrading balloon to 13.96 cm"). That footnote contains a real and interesting finding — a genuine operating-point trade — and it belongs in the body.

**Minimum fix required:** Add a Limitations item naming the in-denominator regressions with the f3_st_hf numbers and the async50 trade now buried in S12's footnote; and either drop "without selective highlighting" from Sec. 1 or make it true by naming the losses in the body.

### C3. The third headline contribution rests on quantities that are never defined

**Location:** Sec. 1 contribution 3, p2; Sec. 5.6, p11; Fig. 5, p11; S7, SI p6.

Contribution 3 is stated as a headline: "One single-variable intervention ... moves per-frame tracking error worse (**+0.0806**, 1.22× its noise floor) yet full-trajectory error better (−1.42 cm, 4.0×)". The quantity that moved by +0.0806 is called three different things and defined nowhere:

- Sec. 1, p2: "per-frame tracking error"
- Sec. 5.6, p11: "per-frame penalty worse (+0.0806, 1.22× floor)"
- Fig. 5 row label, p11: "per-frame dynamic penalty"

I searched both documents. The string "penalty" appears **once** in the entire SI, at S7, and only in passing: "median RPE(hi) sits at 1.42–1.70 cm, consistent with the penalty endpoint's magnitude". There is no definition and **no unit anywhere** — note that its two companions in the same sentence and the same figure both carry cm ("−0.0248 cm", "−1.42 cm") while "+0.0806" is bare. A reader cannot tell whether it is cm, cm/frame, a log ratio, or a dimensionless index.

The middle endpoint, "coherent amplitude", is defined only in S7 ("coherence × median|RPE| on the high-dynamic pairs, where coherence is the mean cosine similarity between consecutive RPE vectors") and nowhere in the body.

The consequence is that the paper's most transferable claim — "a pose-side claim must name its endpoint", which Sec. 1 says "generalises beyond this system" — cannot be evaluated from the main text, because two of the three endpoints are not defined in it. For a venue whose readership is not primarily SLAM, this is disqualifying for that contribution.

**Minimum fix required:** Two sentences in Sec. 5.6 defining the per-frame dynamic penalty and the coherent amplitude, both with units, and one consistent name for each used in Sec. 1, Sec. 5.6, and Fig. 5.

### C4. Multimedia relevance is never argued (see the dedicated section below for the full assessment)

**Location:** whole submission.

Word counts over the extracted text: **"multimedia" — 0 occurrences** in the main paper and 0 in the SI. "video" — 2 occurrences in the main paper, of which one is the keyword line ("RGB-D video") and one is inside a cited title ("Segment anything in images and videos"). No occurrence of streaming, AR/VR, telepresence, content creation, perceptual quality, or any user-facing application.

For MMM this is a first-order problem, not a cosmetic one: it is the single most common reason a technically sound vision/robotics paper is declined here. Details and the required fix are in **Multimedia Relevance** below.

### C5. Fig. 3's caption states a rule that contradicts what Fig. 3 plots, and its bottom strip is typographically broken

**Location:** Fig. 3, p10.

*The rule.* The caption says: "The bottom strip marks, per sequence, whether **all three ∆f meet the support rule** (bold cells only; directional cells are undetermined, not negative)."

On the balloon column, all three cells are bold in the rendered PDF: −0.18 ± 0.13, +0.78 ± 0.04, +0.29 ± 0.20. Under the caption's rule as literally written, balloon's strip cell should read **yes**. It reads **no**.

The rule actually applied is the conjunction of *support* and *positivity*, which is the question Sec. 5.2 poses ("Does any sequence reward the full bundle (∆f (s) ≥ 0 ∀f )?") but which the caption drops. As written, the figure's headline banner — "No sequence rewards all three components (0 of 5): the full bundle is nowhere strictly necessary" — is unsupported by the figure's own stated criterion. Since "0 of 5" is quoted in the abstract, in Sec. 1 contribution 1, and in the Conclusion, the caption defect propagates to the paper's most-repeated claim.

*The typography.* The bottom strip repeats the label "K, R, L all supported?" five times, once per column. Each instance overflows its rounded box and collides with the next; at 400 dpi the strip reads as a run-together string ("…all supportedK, R, L all supported?…"). This is visible at 100% zoom and will be visible in print.

**Minimum fix required:** State the sign requirement in the caption (e.g. "whether all three ∆f are *supported and positive*"); print the strip label once, left of the row, rather than five times.

### C6. Figs. 4 and 5 carry text-over-data collisions, unexplained encodings, and an inverted sign convention

**Location:** Fig. 4, p11; Fig. 5, p11.

*Fig. 4b.* The annotation "naive ÷ vanilla: crosses parity on pt2" is overprinted by a blue seed marker, which lands inside the word "naive". Text and data collide.

*Fig. 4c.* Three separate collisions, all verified at 350–400 dpi: the sequence label **"f3_st_hf" is overprinted by the grey triangle marker**, rendering it partly unreadable; **"pt2" is overlapped by a blue circle**; **"pt1" is overlapped by an orange diamond**. Additionally the legend entry "ambiguous, excluded (1)" runs directly into the "τ = 1.6445" annotation with no separating whitespace.

*Fig. 4c encodings unexplained by the caption.* The caption explains the squares and the non-overlap, but not: the grey vertical band, the two dotted horizontal reference lines (N = 1.5, N = 1.2), or the difference between the grey *triangle* (the excluded sequence) and the grey *square* (the in-band held-out check). Two different grey markers mean two different things and the caption mentions only one of them ("the grey one lands in the N-ambiguity interval").

*Fig. 5 — the sign convention is inverted relative to its own annotations.* The x-axis runs "worse ← 0 → better". The per-frame penalty bar therefore extends in the **negative** x direction while carrying the label "**+**0.0806", and the other two bars extend in the **positive** direction while carrying the labels "**−**0.0248 cm" and "**−**1.42 cm". Every printed sign is the opposite of the direction its bar points. The caption ("shift in units of that endpoint's own re-run noise floor") never says the axis is oriented by goodness rather than by raw sign. The small "worse"/"better" headers help but do not resolve it, and this is the figure carrying contribution 3. The "+0.0806" annotation is additionally overprinted by the +1 floor dashed line, which passes through its final digit.

**Minimum fix required:** Repel all labels from markers and annotations in Fig. 4 (matplotlib `adjustText` or manual offsets); complete Fig. 4c's caption legend; in Fig. 5, either plot raw signed shifts or state the goodness orientation explicitly in the caption, and move the "+0.0806" annotation clear of the dashed line.

### C7. The held-out validation of Sec. 5.5 does not close arithmetically as written, and its decision bands are never defined

**Location:** Sec. 5.5, p11; Fig. 4 caption, p11; S8, SI p7.

**Body text:** "its pre-registered midpoint (τ = 1.6445 cm/frame) was tested on two rounds of unseen sequences (**5 + 6 = 11** ...; one lands in the N-ambiguity band, undecidable): **8 of the 10 decidable** agree in direction (**4 of 5** in the first round, the squares in Fig. 4c; **4 of 6** in the second, S8)".

The parenthetical denominators sum to 5 + 6 = 11, but the stated decidable total is 10. The reconciliation — that the undecidable sequence sits in round 1, so round 1 has 4 decidable and the "4 of 5" denominator counts *tested* rather than *decidable* — is inferable only by cross-reading the Fig. 4 caption ("four agree, the grey one lands in the N-ambiguity interval"). A reader should not have to reverse-engineer a validation count.

Compounding this, **three different thresholds are in play and the "ambiguity band" is never defined**. Sec. 5.5 introduces "N ≥ 1.5 necessary, N ≤ 1.2 redundant", then in the next paragraph invokes a third value: "with no frozen-sense counterexample (N ≤ 0.8)". Whether the ambiguity band is (1.2, 1.5) or (0.8, 1.5) is never stated, so a reader cannot independently classify any held-out point in Fig. 4c or in S8's per-run table. Since this held-out test is the only out-of-sample validation in the paper, it should be the most reconstructible claim in it.

**Minimum fix required:** Define the ambiguity band once, explicitly, with its relation to all three of 0.8 / 1.2 / 1.5; restate the counts as "4 of 4 decidable in round 1 (one of the five in-band), 4 of 6 in round 2, 8 of 10 overall".

---

## Minor Issues

**M1.** "RoGS" is never expanded anywhere in either document. Presumably Robust + Gaussian Splatting, but the reader is left to guess a name that appears ~40 times.

**M2.** ATE and RPE are never expanded in the main text (RPE is expanded only in S1.2; ATE nowhere). MAD is used four times in Sec. 3.4 without expansion. "Hampel-type robust z-score" (Sec. 3.4, p5) is unexplained jargon. For MMM's readership these should each cost one clause.

**M3.** The abstract's third sentence is ~90 words joining three independent claims with semicolons around a nested parenthetical ("A pre-registered 120-run factorial over three of its four components (…) finds that component necessity is regime-dependent: no sequence …; a controlled counterpart …; and three pose-side endpoints …"). Split into three sentences. Within it, "a controlled counterpart given the same frozen flow is worse than the baseline on one held-out sequence **where our weighting is not**" requires the reader to reconstruct an elided predicate across fifteen words.

**M4.** Sec. 2.2, p3: "so the distinction from prior-free systems is one we claim for no one." I could not determine what this asserts. Presumably "we neither claim it for ourselves nor deny it to others" — but as written it is opaque and sits at the end of an otherwise admirably clear paragraph.

**M5. Terminology drift.** The unmodified backbone is called four things: "vanilla" (Fig. 4a legend), "MonoGS (unmodified)" (Table 1), "the baseline" (Sec. 5.4), "the backbone" (Sec. 6 item 3), plus "MonoGS" as the S12 column header. Separately, the same N category is "dominant" in Sec. 5.1 and "necessary" in Sec. 5.5. The flow control is "the naive counterpart" / "naive p90" / "flow-mask" / "the counterpart" across Sec. 5.4 and Fig. 4. Fix one name each.

**M6. Table 1's bolding rule is stated but not applied, and it fights S6.** The caption says "**Bold** = best per column", yet neither the Avg column (WildGS 2.1 is lowest, unbolded) nor the GPU column (MonoGS 0.5 is lowest, unbolded) carries any bold. Applied to the four ATE columns, the rule bolds a *monocular* system (WildGS-SLAM) across a table dominated by RGB-D rows — which is precisely the cross-protocol comparison S6 exists to warn against ("They differ in input modality (WildGS-SLAM is monocular RGB; the rest are RGB-D)"). Either bold within group, or drop the bold and say why.

**M7.** Sec. 5.1, p9: "so it is quotable wherever both arms ran (**full table in S3**)." S3 contains no table of N; it describes a script that generates a table into an external repository file. The values *are* reconstructible from S12 (e.g. balloon 12.11/3.06 = 3.96 ✓, pt2 9.30/10.44 = 0.89 ✓), so this is a wrong pointer rather than missing data — but it should point at S12, or S3 should actually carry the N column.

**M8. Cross-campaign anchors quoted without a note.** Sec. 5.4 gives vanilla on pt2 as **45.37** cm; S12 gives **43.85 ± 8.55**. Sec. 5.3 gives combined on crowd2 as **2.11** cm; S12 gives **2.19 ± 0.09** and Table 1 gives **2.2 ± 0.1**. The SI discloses the underlying reason in S2.3 ("the ladder spans four campaigns, so the ~30% cross-campaign drift discipline applies"), but a body reader comparing Sec. 5.3/5.4 against Table 1 will see two values for one quantity with no explanation. One footnote in the body resolves it.

**M9. Fig. 1 defects (p4).** (a) The "optional semantic mask" box has **no arrows to any consumer**, in a figure captioned "Where the components attach" — its two named paths exist only as text inside the box. (b) The caption's legend says "Grey is the backbone", but the mask box is also grey (dashed) and is not backbone. (c) The caption says "each **blue** box modifies the stage above it", but the reliability signal box is orange and the mask box is grey, so the stated rule covers only two of the five non-backbone boxes.

**M10. Two SI sections are never cited from the main text: S4 and S9.** S4 is the mask × coverage 2×2 and contains the single most title-relevant sentence in the whole submission ("which is why we do not describe coverage as the kernel" — see C1). Leaving it unreferenced means the body's strongest self-qualification is unreachable by a reader following cross-references.

**M11. Internal campaign codenames leak into the SI.** EXP53/55/56/57/58/59 and P11 appear 18 times across S2.2, S2.3 and S8 with no key. S2.3's table row "P11 (simpler)" is the only place the internal code and the paper's own term "simpler" are connected, and the main text (Sec. 3.6) introduces "simpler" without ever mentioning P11. Either define the codes once or replace them with descriptive arm names.

**M12. Fig. 1 omits the path contribution 3 intervenes on.** Sec. 3.6 says the mask "reaches **three** consumers: the mapping loss, the keyframe-insertion gate, and the tracking residual"; Fig. 1's box lists two, and the caption states the third is "omitted from the drawing". The omitted path is exactly the one Sec. 5.6 extends from 10 to 100 iterations to produce contribution 3. Draw it, at least as a dashed warm-up-only edge.

**M13. Table 1 presentation.** Row labels wrap mid-parenthetical ("NGD-SLAM (no / GPU)", "RoGS-SLAM / combined (ours)"), and the WildGS row carries three significant figures (1.52 ± 0.05) while every other row carries two (2.3 ± 0.0). Several cells read "± 0.0", which for DynaGSLAM is all four cells — see Q2.

**M14.** Sec. 5.4/Fig. 4b mismatch: the caption says "the naive threshold crosses it [parity] on pt2", but individual orange seed markers visibly cross parity on mv_no_box2 and balloon2 as well. The body's "all-seeds-same-sign rule" explains this (which is why the count is 2 of 4, not 3 of 4), but the caption's singular "on pt2" describes only the means and will be read as contradicting the plot.

---

## Questions to Authors

**Q1.** S10 reports, on balloon, reliability **off** = 13.78 ± 5.97 and **both** (the shipped default) = 13.85 ± 0.58 — the off arm's mean is nominally *lower*. Fig. 3 reports ΔL = +0.29 ± 0.20 on balloon (removing L hurts). Are these reconcilable? If the answer is the stability difference that S10 alludes to ("the off arm's large sd ... marks bistability of the unreliability-weighted backbone"), why is *stabilisation rather than mean improvement* not the main-text statement of what the reliability signal buys? That framing would be both more defensible and more interesting than the current one.

**Q2.** DynaGSLAM is reported as ± 0.0 on all four columns of Table 1 (23.8, 13.7, 12.1, 13.7). The caption says 3 seeds. Is DynaGSLAM deterministic under your reproduction, or was it run once and the sd left as a placeholder?

**Q3.** What is the definition and the unit of the per-frame dynamic penalty (the +0.0806 endpoint of Fig. 5)? See C3.

**Q4.** S12's ‡ footnote says f3_st_hf is "recoverable to 2.67 ± 0.27 cm at async50 but degrading balloon to 13.96 cm". Was async50 considered as the shipped operating point, and what is the principled basis for preferring the current setting? This trade seems more informative than its footnote placement suggests — it is a second instance of the paper's own "necessity is regime-dependent" thesis, this time about a training budget rather than a component.

**Q5.** Fig. 4c marks f3_st_hf as the one "ambiguous, excluded" sequence, yet Sec. 5.5 uses it as the illustrative case for the RPE/ATE dissociation. Does the illustration survive if an *included* sequence is substituted? If yes, please substitute; if no, please say what the reliance on the excluded point implies for the claim.

**Q6.** Given S4's "we do not describe coverage as the kernel", what is the argument for keeping "Coverage Sampling" in the title?

**Q7.** For MMM specifically: what is the intended multimedia application of this system, and is there a downstream media task (novel-view synthesis for the static scene, dynamic-object removal for video re-rendering, map reuse across a session) on which the trajectory gains could be shown to matter perceptually? See below.

---

## Multimedia Relevance

**Rating: WEAK.**

**Evidence.** "Multimedia" appears **zero times** in the main paper and zero times in the supplementary. "Video" appears twice in the main paper: once in the keyword line ("RGB-D video") and once inside a cited reference title. There is no mention of video streaming, AR/VR, telepresence, content creation, media production, perceptual quality, or any user-facing scenario. The Introduction motivates the work entirely as an estimation problem ("A moving object supplies photometric and geometric residuals that a rigid-world estimator resolves by moving the camera"), and the Conclusion closes on the same terms.

**Why this is worse than it looks.** The natural bridge to this community is rendering quality — a dynamic-scene SLAM system that reconstructs a clean static map from contaminated RGB-D video is a media-reconstruction result. The paper deliberately closes that bridge:

- Sec. 5.7 (p12) reports rendering primarily as a *negative*: "post-hoc renders show full-frame PSNR ranking the ghost-carrying backbone above both arms (19.1 vs 18.8/18.6 dB)".
- S11 item 3 declines the axis entirely: "Rendering metrics do not corroborate trajectory claims ... **We decline to use PSNR as evidence for a pose claim in either direction.**"
- Fig. 2, the one genuinely multimedia-legible artifact in the submission, self-disclaims: "illustration, not a benchmark metric."

I want to be clear that each of these decisions is *methodologically correct* — the authors' diagnosis that full-frame PSNR scores "how well a map explains the drifted training views it was built from" (S5) is right, and refusing to launder a pose claim through PSNR is exactly the discipline the field needs. But the cumulative effect is a submission to a multimedia conference whose only media-facing evidence is explicitly labelled non-evidence, and which never tells a multimedia reader why they should care.

**What would move this to Medium, without weakening any claim.** (a) One motivating paragraph in Sec. 1 grounding the work in a media scenario — casual capture, AR overlay stability, video-to-3D reconstruction from handheld RGB-D — since the movers the paper handles (balloons, carried boxes, objects placed and removed) are exactly the uncontrolled content that user-generated capture contains, and the paper's closed-set argument against class-conditioned detectors is *strongest* in that setting. (b) Promote the depth-L1 result, which the paper's own corroboration rule endorses ("only depth-L1 against ground-truth depth is co-ordered with ATE") and which improves 46.9 → 31.4–32.3 cm — a geometry-quality result stated in a form a media reader can use. (c) Report a static-region novel-view comparison with the protocol stated honestly, or state explicitly *why* a sound rendering comparison is unavailable, so that the absence reads as a disclosed limitation rather than a gap. (d) Expand ATE/RPE/MAD and add a symbol table for Sec. 3.4 (e_flow, g, v, s, d, τ, w_rel, w_rob are introduced across two pages with no consolidated definition).

None of this requires new experiments — (a), (b) and (d) are writing, and (c) can be a disclosure.

**On new-reader friendliness more broadly** (the fifth item in the review brief): the *motivation* is accessible — a non-SLAM reader will understand Fig. 2 and the "39–147 cm vs 1.5 cm" framing immediately, which is a real achievement. The *conclusions* are not: they require holding the K/R/L factorial, the mask-free/combined/simpler triple, the N ratio, and three undefined pose endpoints simultaneously. The SI/main division is otherwise well judged — S1 (protocol), S2 (constants), S7 (the coherent-amplitude measurement) are correctly placed — with the two exceptions noted in C1 (S4 and S10 carry title-critical qualifications that belong in the body) and C3 (S7 carries a definition the body cannot do without).

---

## Overall Recommendation

**Weak reject.** **Confidence: 4 / 5.**

This is an honest, carefully instrumented piece of empirical work, and I would rather see it published than not. The pre-registration, the fixed denominator, the completion gate, the single-protocol reproduction of every competitor row, and above all the flow-budget control (S1, C-strength S1) put it ahead of most submissions in this area on rigour. The self-applied standard in Sec. 2.2 and the disclosed errors in S2 are the marks of authors doing science rather than marketing.

I nonetheless cannot recommend acceptance at MMM in this form, for three reasons that are not copy-editing:

1. **Venue fit is weak and unargued** (C4, Multimedia Relevance). At a ~30%-acceptance multimedia conference, a paper that never uses the word "multimedia", whose only media-facing evidence is self-labelled "not a benchmark metric", and which explicitly declines the rendering axis, is asking the committee to supply the relevance argument on its behalf.

2. **The title asserts what the paper's own measurements qualify** (C1). "via Reliability-Guided Weighting and Coverage Sampling" against S4's "we do not describe coverage as the kernel" and S10's geometry-only result is not a nuance — it is the first thing a reviewer will quote back, and it undercuts the credibility the rest of the paper works hard to build.

3. **The main text under-discloses in-denominator regressions while claiming non-selectivity** (C2). Sec. 1's "the full 18-sequence table is given without selective highlighting" cannot stand while the body never mentions that f3_st_hf regresses ~10× against doing nothing, and while that same sequence is used as a positive illustration in Sec. 5.5. Of all my concerns this is the one I weigh most heavily, precisely *because* the paper's central rhetorical asset is its honesty. A reader who discovers the f3_st_hf row in the SI after reading Sec. 6 will re-read the rest of the paper suspiciously, which the work does not deserve.

Alongside these, C3 (an undefined, unitless headline quantity), C5 (a caption rule that contradicts its own figure, propagating to the abstract's "0 of 5") and C6 (four verified text-over-data collisions plus an inverted sign convention on the figure carrying contribution 3) mean the submission is not currently camera-ready in its presentation either.

**What would move this to accept.** All seven Major concerns are addressable without a single new GPU run. C2, C3, C5, C6, C7 are pure writing-and-figure work. C1 requires a retitle and promoting two SI paragraphs into the body — which would make the paper *more* accurate, not less ambitious. C4 requires one motivating paragraph and a reframing of the depth-L1 result the authors already have. A revision that (a) retitles to what the measurements establish, (b) names the in-denominator regressions in Sec. 6, (c) defines both pose endpoints with units, (d) repairs Figs. 3–5, and (e) argues multimedia relevance in Sec. 1 would in my judgment be a clear accept, and a genuinely useful paper for how this subfield argues about attribution. I would be glad to see it back.

**Confidence rationale (4, not 5):** I read both documents in full, verified every numerical claim I cite against the main text and the SI tables, and inspected all five figures and Table 1 as rendered images at 300–400 dpi. I have not independently surveyed the current state of the art in dynamic 3DGS SLAM closely enough to adjudicate the paper's positioning against very recent systems (BDGS-SLAM, DAGS-SLAM, DynaGSLAM), so my assessment of novelty relative to that line is held at lower confidence than my assessment of the paper's internal consistency, figures, and venue fit — which is where this review is concentrated.
