# TABLES — 论文表格数据处理规范（2026-08-29 定稿）

> 本文档回答一个问题：**论文四张表里的每个数字是怎么来的、怎么重新生成、怎么验证。**
> 适用范围：`papers/maskfree_bundle/manuscript.md` 的 Table 1–4 及其配套
> `tables/*.md|csv`。后续新增表格（如 EXP55 kernel 消融 → Table 5）必须遵守同一套约定。
>
> **核心纪律（不可协商）**：表格数字一律由 `scripts/build_paper_tables.py` 从 run
> 产物（`tracking_raw.csv`）直接计算生成，**禁止手写/手抄数字进 manuscript**。
> verdict/evidence 文件里的数字必须能被本脚本从 run 目录复现——EXP54 勘误
> （2026-08-28，4 个无源值）就是没有这道闸的结果。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 1. 工具与日常工作流

```bash
# ① 同步远程 run 的 CSV 到本地缓存（只需 tables/tracking_raw.csv，小文件）
rsync -av --include='*/' --include='tracking_raw.csv' --exclude='*' \
    jiangwenheng@172.16.227.24:/home/jiangwenheng/cron/monogs-ours/results/runs/ \
    results/runs_remote_cache/
# （results/runs_remote_cache/ 已 gitignore；本地 results/runs/ 亦 gitignored）

# ② 生成四张表的 md + csv + PROVENANCE.md
python scripts/build_paper_tables.py

# ③ 验证 manuscript 四张表与 run 数据逐 cell 一致（不一致 exit 1，打印每个差异 cell）
python scripts/build_paper_tables.py --check

# ④ 若 check 报差异：先查 run 数据是否变了（重同步），再决定改正文还是改脚本；
#    改完后重跑 ②③ 至 CHECK OK，再走 md2latex + compile_v2.sh 重建 PDF。
```

**改动顺序铁律**：run 数据 → 脚本 → tables/ → manuscript → PDF。
不许反向（从 manuscript 抄数字回任何地方）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 2. 四张表的契约（口径、加粗、标注）

| 表 | 内容 | 统计口径 | 加粗规则 |
|---|---|---|---|
| **Table 1** | 18 序列 × 4 臂 ATE | mean±**sd** (ddof=1)，3 seed | 四臂（vanilla/mask-free/combined/RGD）取均值最小者加粗 |
| **Table 2** | mask 必要性 N（六序列，两臂） | mean±sd；N = mask-free ÷ combined | 无加粗；reading 按阈值：N≤1.2 redundant / N≥1.5 dominant / 其间 ambiguous；N<1.0 追加 "(mask-free marginally better)" |
| **Table 3** | EXP53/54 单变量归因 | mean±sd；floor = max(0.43, 6%×max(两臂))。**v3 起（2026-08-30）floor 不再作表列**（两行同为 0.43 的常数列）：移入 caption（"0.43 cm, fixed before dispatch"），csv 仍保留 floor 列 | 介入臂（+coverage/+reliability）均值落入 full 臂**地板内**即加粗（= 单变量即可恢复）；crowd2 无臂达标故无加粗。**v3 起 caption 必须写明加粗含义**（bold = 落入 full 臂地板内），否则读者会按"加粗=最优"误读 |
| **Table 4** | WP-B 受控对照 | mean±**half-range**（(max−min)/2，caption 契约，**不是 sd**）；LaTeX `$\pm$` 格式 | 三臂取均值最小者加粗 |

行内标注：
- `†` = vanilla CV > 20%，单倍数引用不合法（集合：f3_st_hf, f3_st_rpy, f3_wk_hf,
  crowd, crowd2, mv_no_box, mv_no_box2, pt1）。
- `‡` = f3_st_hf 专属：async10 已知失败案例（29.43±8.00），脚注说明 async50 可救此序列
  （EXP51 A2, 2.67±0.27）但伤 balloon（EXP52 M50B, 3.06→13.96）——训练预算本身
  regime-dependent。**全表统一 async10，不许混配置。**

**⚠️ 编号映射（v3 编译版 ≠ 本文档编号）**：v3 正文实际只有三张表，编译编号为
Table 1 = master comparison（内部 `table_master`）、**Table 2 = 单变量归因（本文档 Table 3 /
`table3_attribution`）**、Table 3 = efficiency（本文档 Table 5 / `table5_efficiency`）。
本文档 Table 1（18 序列）在 v3 移入 S12，Table 2（mask 必要性 N）降为正文比值句 + 补充材料
S3，Table 4（WP-B）移到 Fig. 4 + SI。改"论文表二"时改的是 `table3_attribution`，别改错文件。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 3. 数据源映射（每个数字从哪个目录读）

脚本内 `combined_dir(seq)` / `maskfree_dirs(seq)` / `combined_pattern(seq)` 实现此映射。
**没有单一根目录**——三段历史 campaign 各管一部分，分流如下：

### 3.1 我方两臂（Table 1/2）

| 序列 | mask-free 臂 | combined 臂 | 目录命名 |
|---|---|---|---|
| FULLKERN 11 序列（crowd, crowd2, f1_desk, f2_person, f2_xyz, f3_office, f3_st_hf, f3_st_rpy, f3_st_xyz, f3_wk_hf, f3_wk_rpy） | `P6/P6-FULLKERN-MASKFREE` | `P6/P6-FULLKERN` | `{seq}_maskoff_seed*` / `{seq}_combined_seed*` |
| f3_wk_xyz（原 flow 完好） | `P6/P6-18SEQ` | `P6/P6-MASON` | 同上 |
| balloon, balloon2, mv_no_box, mv_no_box2, pt2（动态 6 之 5） | `P6/P6-MASKOFF`(seed0) **+** `P6/P6-MASKOFF-3SEED`(seeds1/2) —— 两目录并集 | `P2/P2-T_3090` | `{seq}_maskoff_seed*` / **`{seq}_prune_seed*`**（注意 combined 在此目录下叫 prune！） |
| pt1 | 同上两目录并集 | `P6/P6-MASON` | `{seq}_maskoff_seed*` / `{seq}_combined_seed*` |

易错点：
- **combined 臂的目录命名不统一**：P2-T_3090 下叫 `*_prune_seed*`，其余叫
  `*_combined_seed*`（`combined_pattern()` 处理）。
- **mask-free 的 seed 分散两个目录**：P6-MASKOFF 只有 seed0，seeds1/2 在
  P6-MASKOFF-3SEED；必须并集后再算 mean±sd（`seeds_ate_multi()`）。
- FULLKERN 11 序列是 exp23/24 静默 no-op 事故后的重跑；旧根（P6-18SEQ/P6-MASON）
  对这些序列**被代码层拒绝**，不得回落。

### 3.2 baseline 两列（Table 1）

来源 = `resources/02-baselines/baselines_result/`（用户维护的 baseline 结果目录）：

- vanilla：`MonoGS/tracking_raw.csv`（单文件含 18 序列 × 3 seed）
- RGD：`RGD-SLAM/tracking_raw.csv`（3-seed 重现，同协议）
- **别名**：两 CSV 用数据集原名——`person_t` = pt1，`person_t2` = pt2
  （`VANILLA_ALIAS` 字典）；RGD CSV 带 BOM，读时用 `utf-8-sig`。

### 3.3 Table 3（归因）与 Table 4（受控对照）

- Table 3：simpler/full = `EXP53/p11phase2/{seqp}_P11_ | _C_seed*`；
  介入臂 = `EXP54/component_attribution/{seqp}_dynkf_ | _reliability_seed*`。
  **注意 seqp 命名无下划线**：`mvnobox`、`f2xyz`（与主表的 `mv_no_box` 不同）。
- Table 4：`WPB/WPB-CONFIRM/{vanilla|flowmask|MRCS}_{seq}_{0,1,2}`（held-out 4 序列）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 4. 读数规则（脚本内实现，勿在别处重造）

1. **每 cell = 3 seed**；seed 目录下 `tables/tracking_raw.csv` 取**最后一行**的
   `ate_rmse_cm`（= latest-run 规则；rollup 若有多行，最后一行即最新 run）。
2. mean = 算术平均；sd = **样本 sd（ddof=1）**；单 seed 时 sd 记 0。
3. Table 4 例外：报 mean±half-range（见 §2）。
4. 完成门：轨迹帧数 ≥95% 数据集帧数（由 runner 保证，脚本不重复检查）。
5. 一个 (seq, arm, seed) 只允许一个 run；re-run 时新 run 覆盖旧 rollup（latest 规则），
   不得平均。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 5. 事故史与教训（为什么有这些闸）

| 日期 | 事故 | 后果 | 现在的闸 |
|---|---|---|---|
| exp23/24 | 11 序列未预计算 flow，ReliabilitySignal **静默跳过**（K1R1L0 冒名 K1R1L1） | 整批 run 臂标错误，FULLKERN 66-run 重跑 | 运行时硬闸 `assert_reliability_flow_available`（缺 flow 即 abort）+ 脚本层旧根拒绝 |
| 2026-08-28 | EXP54 verdict 的 mv_no_box seed1/2 **四个数字无 run 产物来源**（转录错误；sd 被压小 5–8×） | verdict/manuscript/registry 全部勘误；主判决侥幸不变 | `--check` 模式：verdict/正文数字必须能从 run 目录复现 |
| 2026-08-28 | Table 2 balloon 行混入 **P-B campaign** 数字（±1.90/0.11），与主表口径（±2.33/0.14）不一致 | 同一量在正文出现两套 sd | `--check` + 本文档 §3.1 的源映射 |
| 2026-08-28 | 旧生成链**末位舍入误差** 11 处（如 10.4450 → 印 10.45） | 正文与 run 数据末位不符 | `--check` 逐 cell 比对 |
| （代码层） | `_robust_irls_weight` 未知 kernel **静默返回全 1 权重** | kernel 消融会变 null-vs-null | EXP55 runner E0 双重断言（resolved config.yml 必含预期 kernel） |

通用教训：**静默降级 = 数据事故**。任何"读不到就跳过/给默认值"的路径都必须配硬门。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 6. 新增表格的操作程序（以 EXP55 kernel 消融 → Table 5 为例）

1. `scripts/build_paper_tables.py` 新增 `table5()`：读
   `results/runs_remote_cache/EXP55/kernel_ablation/{balloon,pt2}_{cauchy,gm}_seed{0,1,2}`；
   Huber 锚引用主表值（不重跑），报告 Δ 与地板判读（预注册 §6 冻结口径）。
2. `main()` 注册 `write_pair("table5_kernel_ablation", …)`；`TABLE_MARKERS` 加对应
   header 前缀。
3. manuscript 加 `**Table 5.**` caption + 表体；跑 `--check` 至 OK。
4. PROVENANCE 自动获得 cell 级映射。
5. 判决写 `results/evidence/exp55_kernel_ablation_verdict.md`；verdict 里的数字必须
   与脚本输出一致（EXP54 教训）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 7. 快速排查清单（check 失败时按序过）

1. `--check` 报的 diff 是哪张表哪列？→ 对照 §2 的口径表（先排除"口径不同"类，如
   half-range vs sd）。
2. run 数据变了吗？→ 重跑 §1① 的 rsync，再生成一次。
3. 序列在哪个根目录？→ 对照 §3.1 映射（命名陷阱：prune vs combined；mvnobox 无下划线；
   两目录并集）。
4. 是舍入边界吗？→ 打印未舍入 mean/sd（4 位小数）判断；脚本用 Python f-string
   `:.2f`（银行家舍入），10.445 → "10.44" 是正确行为。
5. 都不是 → 大概率正文手滑或 verdict 无源；以脚本输出为准改正文，并在 evidence 里
   追加勘误注。
