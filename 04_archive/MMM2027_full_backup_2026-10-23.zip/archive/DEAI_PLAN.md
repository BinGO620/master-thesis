# 降 AI 率改写计划(DE-AI pass)

状态:**已执行完毕(2026-08-31)**。源文件、md 镜像、两份投稿 PDF 均已同步;**未 commit**,等用户确认。
范围:`latex/body_v3.tex` + `latex/main_v3.tex`(摘要)+ `latex_si/si_body_v3.tex`,
镜像 `manuscript_v3.md`、`supplementary.md`,重建后同步 `MMM2026_submission/`。

编译链:`/data/conda_envs/tex/bin/tectonic`(0.17.0,本机 PATH 上无 latex,须走此绝对路径)。

---

## 1. 诊断结论(两次独立全文扫描互相印证)

| 特征 | 主文 | SI | 判定 |
|---|---|---|---|
| 破折号 `---`(散文) | **49**(body 46 + 摘要 3) | **43** | **主要 AI 指纹**,已处理 |
| 表格空 cell `---` | 3(Table 1) | 1 | 占位符,**未动** |
| 被引用的 `` ``---'' `` 字形 | — | 1(S1.5,指代表中"未跑"标记) | **不可动**,已排除 |
| AI 高频词(crucial/pivotal/notably/furthermore/delve/leverage 等) | 0 | 0 | 干净,**不换词** |
| 分号 / 冒号密度 | 73 / 59 | — | 基线已偏高,见 §7 残留项 |
| 句长节奏 | 中位 23 词、sd 16、短句 16%、长句 17% | — | **像人写的,不动** |

结论:AI 化不在词表,在标点结构。主战场是把破折号改写成多样化的人类标点,而不是换词。

## 2. 执行原则(实际遵守情况)

1. **不动任何数值、立场、加粗格式**。已用数字令牌全比对验证:
   `body_v3.tex` 518→518、`main_v3.tex` 43→43、`si_body_v3.tex` 1305→1305,**逐个 token 相同**。
2. 改写方式按语境分配,避免机械单一代换(机械单一代换本身也是 AI 痕迹)。实测分配:
   46 处主文破折号 → 逗号约 24、分号 +8、括号 +5、冒号 +4、拆句 +5。
3. SI 在作用最佳处**保留 6 处**(见 §4),主文正文清零。
4. 每条规则执行前 `assert` 在源文件中**恰好命中 1 次**,不命中即整体中止。69 条 tex 规则全部通过。

## 3. 主文执行结果(body_v3.tex 40 条 + 摘要 2 条)

原计划 29 条(P01–P29)全部保留并执行,另补 13 条:

| 类别 | 编号 | 条数 | 说明 |
|---|---|---|---|
| 原计划规则 | P01–P25、P27–P29 | 28 | P26 被 F04 吸收(同一句同时改破折号与警句式小标题) |
| **补:计划漏掉的破折号** | U01–U07 | 7 条 / 覆盖 10 处 | 原清单只覆盖 35/46,漏 11 处,其中 4 处在 Introduction |
| **补:"X, not Y" 收尾节奏** | N01–N02 | 2 | 全文 7 处,改写 3 处(含 F04 内 1 处)、保留 4 处 |
| **补:重复修辞框架 / 警句式小标题** | F01–F04 | 4 | 见下 |
| **补:陈旧手改引入的重复短语** | X01 | 1 | Limitations §2 "on the walking and person sequences" 出现两次 |

漏掉的 11 处(现已全部处理):Intro¶1 成对同位语 ×2、Intro¶2 `on which sequences ---`、
Intro 条3 `--- on one sequence`、§2.2 `class priors ---`、Fig.2 图注 `static office ---`、
§4 `run directory ---`、§5.2 `supported --- 0 of 5 --- so` ×2、§5.5 `agree in direction --- … ---` ×2。
其中 §5.2 那处与 Intro 条1 是同一句式的复述,原计划只修了 Intro 一处,会造成一改一不改。

F 类四条:
- **F01** Intro¶2 `What is missing is evidence for two questions:` → `Evidence is missing on two questions:`
  (全文该框架出现 2 次且都在段末转贡献;改后只剩 §2.3 一处)
- **F02** `**Two flows, one disagreement.**` → `**Observed and rigid flow.**`
- **F03** `**A limitation the estimator creates.**` → `**Limitation of the robust knee.**`
- **F04** `**What this is.**` → `**Scope of the interval.**`(并去掉同句破折号与 "not a selector" 节奏)
- 另 U02 把 Intro 条3 结尾的裸祈使句 `\textbf{name the endpoint}` 改为
  `a pose-side claim must \textbf{name its endpoint}`,加粗保留,与 Conclusion 措辞一致。

**主文散文破折号:49 → 0**(仅余 Table 1 的 3 个占位符)。

## 4. SI 执行结果(si_body_v3.tex,27 条 S01–S27)

**43 → 6**(目标 ≤10)。刻意保留的 6 处,均为"内含逗号的插入语,破折号是最清楚的标记":

- L143 lifecycle 负结果变体定义(2)
- L315 跨系统协议差异三段枚举(2)
- L459 reliability 四臂列表 `off, both(…), flow-only, geometry-only`(2)

另**未动**:L59 被引号包住的 `` ``---'' ``(它指代表格里"未跑"的那个字形,改了会说不通)、
表格占位符 1 处。

## 5. 镜像同步结果

- `manuscript_v3.md`:40 条中 39 条自动映射成功,U07 手工处理(md 侧措辞较旧),
  X01 跳过(md 本来就是正确写法)。正文 `—` 仅余 3 个 Table 1 占位符。
- `supplementary.md`:27 条中 21 条自动 + 5 条手工 = 26 条;S11 无对应(见 §6)。
  余 10 个 `—` = 标题 1 + 引用字形 1 + 表格占位符 1 + 刻意保留 6 + 陈旧处 1。

## 6. md 镜像陈旧修复(**已完成**,方向一律 tex → md)

破折号 pass 之后做了一轮 tex↔md 全文漂移排查(脚本 `deai_scripts/find_drift.py`:
两侧都剥掉数学、`\cite`、latex/markdown 标记,只按**字母词序列**比对,数字另行逐句核对)。
共查出 **15 处真实漂移**(主文 2、SI 13),已全部按投稿 tex 对齐:

**主文 `manuscript_v3.md`(2 处,纯措辞,数值一致)**
- §5.5 `lands inside the N-ambiguity band and is undecidable` → tex 的 `lands in the N-ambiguity band, undecidable`
- Limitations §2 竞品归属写法对齐 tex

**SI `supplementary.md`(13 处)**
- **陈旧交叉引用 4 处**:`completion gate in Sec. 4.4` → `of S1.4`;`hence Sec. 4.4` → `hence the
  completion gate of S1.4`;`protocol table (Sec. 2.4)` → `(S6)`;`ratios in Sec. 5.1` → `in S3.2`。
  (根源:commit ce8093ba 只清了 tex 侧的 Sec.x.y 陈旧引用,md 没跟)
- **陈旧主张 2 处(重要)**:md 两处都写"效率数字**绝不**与竞品并列",而 Table 1 事实上做了
  同硬件的 RGD-SLAM 对比 ⇒ md 与主文自相矛盾。已改为 tex 的写法(同硬件下可比 RGD-SLAM,
  其余机器的数字只报不比),并顺带修正 `Sec. 2.4` → `Sec. 2.1`。
- **陈旧数值 2 处**:
  - Huber 核合并判决 `9 of 10` → `Outside pt2, 8 of the 10`,并补回 md 缺失的**边缘案例披露**
   (`Geman–McClure on balloon, +0.46 against a 0.43 floor`);
  - S12 `Table 1 shows **five** selected BONN dynamic scenes` → `**four**`(Table 1 实为
    crowd / crowd2 / mv_no_box / pt2 四列)。
- **md 缺失的整句 2 处**:S10 开头的 Scope 说明句;S12 的 `Body ratios are computed from
  full-precision per-run values…`。
- **S10 标题** `(Limitation 8)` → `(Limitations, Scope)`。

修复后重跑漂移检测:**真实漂移 0**,残留 11 条全部是解析残渣
(`\begin{enumerate}` 留下的 "enumerate" 字样、tex 章节号、md 有序列表的 "2." "3." 编号),
两侧句子逐词相同。

> ⚠ 结构性提醒:`body_v3.tex` 早已被手工改过(图宽、`\needspace`、`[b]` 浮动、`Fig.~4c`),
> **不能再用 `md2latex_manuscript.py` 从 md 重新生成**,否则 12 页版面工作全废。
> 现状是 **tex 为准、md 为镜像**,方向不可反。

## 7. 残留项:分号密度(**用户已决定不改**)

主文分号密度 **0.437 → 0.471 / 句**(73 → 81)。破折号让位后分号略升,但
"破折号+分号+冒号"总量 **178 → 144(−19%)**,指纹没有整体搬家。
要再降必须动 73 个**原有**分号所在的句子,而那些措辞是三轮审稿定下来的
⇒ **2026-08-31 用户裁决:风险与收益不对等,不改。** 此项关闭,不再列为待办。

## 8. 重建与验收(实测)

| 项 | 基线 | 改写后 | 判定 |
|---|---|---|---|
| 主文页数 | 14 | **14** | ✅ 12 正文 + 2 引用 |
| Conclusion 收尾页 | p12 | **p12**(整段完整) | ✅ |
| References 起止 | p13–14 | **p13–14** | ✅ |
| 主文 overfull | 0 | **0** | ✅ |
| SI 页数 | 9 | **9** | ✅ |
| SI overfull | 0 | **0** | ✅ |
| SI S12 表 | p9 内 | **p9 内** | ✅ |
| 数字令牌 | — | **三文件逐 token 相同** | ✅ |
| 非 ASCII | 0 | **0**(脚本硬门) | ✅ |

`MMM2026_submission/` 两份 PDF 已用重建产物覆盖,`cmp` 校验一致
(Main 366,894 B / 14 页;Supplementary 123,969 B / 9 页)。

## 9. 明确不做的事(已遵守)

- 不换同义词——词表本就干净,乱换反而引入生硬表达。
- 不动数值、加粗格式、已审定立场句、图表内容。
- 不用同义词轮换/改写工具批量处理。
- 不动 Table 1 的 `---` 占位符、`--`(数值范围 en-dash)、`variance--bias` 类复合词。
- 不自动 commit。

## 10. 复现方式

脚本已入库到 `papers/maskfree_bundle/deai_scripts/`:
- `deai_main.py`(主文 42 条 assert 规则)、`deai_si.py`(SI 27 条)——破折号/节奏改写;
- `mirror_md.py`——把 tex 改动映射回 md 镜像;
- `find_drift.py`——tex↔md 真实漂移检测(只比字母词序列 + 逐句数字核对),**可重复运行**,
  是本次唯一的幂等工具,以后每轮改完 tex 都该跑一次;
- `sync_stale_md.py`(15 条)——本次 §6 的陈旧对齐记录。
三个脚本都是 assert-恰好命中一次 + ASCII 硬门,**对已改写过的文件重跑会直接失败**
(规则不再命中),因此不可重复执行;它们是执行记录,不是幂等工具。
