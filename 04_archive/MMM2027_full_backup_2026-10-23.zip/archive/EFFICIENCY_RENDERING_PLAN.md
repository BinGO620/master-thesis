# 效率与渲染指标——论文设计方案（2026-08-29）

> 本文档基于 `resources/02-baselines/baselines_result/`（统一指标字段，正式引用源）
> 和用户上传的 `01-baselines_experimental_result_v2.xlsx`（原始实验记录，可比性分析源）
> 两份资产的完整盘点。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 一、数据资产盘点

### 1.1 竞品三类指标覆盖率

| 方法 | ATE | PSNR/SSIM/LPIPS/DptL1 | FPS | GPU (GB) | 数据完整度 |
|---|:---:|:---:|:---:|:---:|---|
| **MonoGS** (backbone) | 18/18 | 18/18 | 18/18 | 18/18 | ★★★ 完整，baseline 自评 |
| **RGD-SLAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★★ 完整，3090 同硬件 |
| **WildGS-SLAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★★ 完整 |
| **DG-SLAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★ 有注释的不可比 |
| **Co-SLAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★ 可能非 3090 |
| **SplaTAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★ GPU sd=5.6（硬件混杂） |
| **DynaGSLAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★ GPU sd=0.75（硬件混杂） |
| **RoDyn-SLAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★ GPU sd=0.1（可能非 3090） |
| **DynaSLAM** | 18/18 | **0/18** | 18/18 | **0/18** | ★ 纯 CPU，无渲染/GPU |
| **NGD-SLAM** | 18/18 | **0/18** | 18/18 | 1/18 | ★ 缺渲染/GPU |
| **ORB-SLAM3** | 18/18 | **0/18** | 18/18 | **0/18** | ★ 纯 CPU，非 3DGS |
| **DROID-SLAM** | 18/18 | 18/18 | 18/18 | 18/18 | ★★★ 完整 |

### 1.2 我方两臂效率数据

| 臂 | online FPS | 峰值 GPU (GB) | 高斯数 | n sequences | 来源目录 |
|---|---:|---:|---:|---:|---|
| combined (3090) | 0.74±0.09 | 4.5±1.1 | 62,542 | 11 | P6-FULLKERN/P2-T_3090 |
| mask-free (3090) | 0.57±0.17 | 2.7±0.4 | 46,245 | 6 | P6-MASKOFF-3SEED |

### 1.3 我方渲染数据

S3.3 supplementary 已有全 18 序列 × 2 臂 × 4 指标（PSNR/SSIM/LPIPS/depth-L1），3-seed mean±sd，离线重渲 final map。

### 1.4 你上传的 Excel 的附加价值

- **DG-SLAM 注释**：明确指出 DROID-SLAM 前端驱动关键帧、fr2_xyz 关键帧占比仅 2.2%、无 3DGS 渲染指标、ATE 用 terminate_woBA 插值——完整记录了不可比原因
- **RODYN-SLAM**：FPS 4.3–4.6 正常（YOLO + depth，不做 full 3DGS 优化），不能与 3DGS 方法比速度
- **RGD-SLAM PSNR Before/After**：Before = tracking 后的地图渲染，After = refinement 后——差值反映 3DGS 后处理效果（5 dB 提升典型），与我们"tracking only"口径不同

---

## 二、硬约束（论文必须遵守的比对边界）

### 2.1 FPS 不能跨硬件并列

| 方法 | GPU 推断 | 能否与我方（3090）直接比 FPS |
|---|---|---|
| RGD-SLAM | 3090（7.37±0.95 GB） | ✅ **可比**——最合适的 FPS 对照对象 |
| WildGS-SLAM | 3090/V100（12.13 GB） | ⚠ 条件可比——硬件不同但显存用量可比较 |
| DG-SLAM | 3090（7.33 GB） | ❌ **不可比**——DROID-SLAM 初始化 + 关键帧极稀疏 + 无渲染 |
| Co-SLAM | 可能 2060（1.12 GB） | ❌ 不可比——硬件不同 |
| SplaTAM | 混杂（sd=5.63 GB） | ❌ 不可比——同一方法在不同硬件上跑 |
| DynaSLAM/ORB-SLAM3 | CPU-only | ❌ 不可比——架构不同 |
| RoDyn-SLAM | 小卡（1.0 GB） | ❌ 不可比——架构不同（不做 full 3DGS 优化） |

### 2.2 渲染比对不能跨口径

| 口径 | 涉及方法 | 问题 |
|---|---|---|
| tracking-only 后渲染 | 我方 | final map re-render，无后处理 |
| refinement 后渲染 | RGD-SLAM (Before/After 差 5 dB) | "After" 口径含 3DGS color refinement |
| 无渲染 | DynaSLAM, NGD-SLAM | 不是 3DGS 方法 |
| **depth-L1 是唯一 co-ordered 指标** | 所有 3DGS 方法 | PSNR 反直觉（漂移轨迹反而 PSNR 高） |

### 2.3 显存是跨硬件可比的

显存是绝对值（不依赖运行时调度），且我方的 2.7–4.5 GB 在所有 3DGS 方法中**最小**：
- RGD 7.37 GB → 我方 combined 仅 61%
- WildGS 12.13 GB → 我方 combined 仅 37%
- SplaTAM 6.92 GB → 我方 combined 仅 65%
- **我方是唯一所有序列 < 6 GB 的 3DGS SLAM 方法**

---

## 三、论文怎么放

### 3.1 正文效率表（建议新增，0.2–0.3 页）

**方案：只报"同硬件硬对比" + "显存跨硬件硬对比"两类，不报 FPS 跨硬件。**

| | Ours combined | Ours mask-free | RGD-SLAM | 注释 |
|---|---:|---:|---:|---|
| online FPS | 0.74±0.09 | 0.57±0.17 | 0.67±0.00 | 全部 RTX 3090；我方含 seg+track+map，不含 RAFT（离线 18.6 fps） |
| GPU 峰值 (GB) | **4.5±1.1** | **2.7±0.4** | 7.37±0.95 | 显存跨硬件可比；我方是 3DGS SLAM 中最轻量 |
| Gaussians | 62,542 | 46,245 | — | map size 指标 |

**脚注**：
- RAFT 离线 54 ms/帧对（18.6 fps，不含在 online FPS 中）
- "其余竞品效率见 supplementary。DG-SLAM 使用 DROID-SLAM 前端初始化和不同的关键帧策略（关键帧数 50–267 vs 我方 88–680），不宜直接比较 FPS（详见 SI §S6）。"
- "WildGS-SLAM/SplaTAM 运行在不同硬件配置下，FPS 不直接可比。"

**不放什么**：
- ❌ 不做"我方 FPS vs 全部竞品"的大表——不诚实
- ❌ 不报 DynaSLAM/ORB-SLAM3/DROID-SLAM FPS——纯 CPU/不同架构
- ❌ 不报 Co-SLAM/DynaGSLAM/RoDyn-SLAM FPS——硬件不可比

### 3.2 渲染结论（散文 + S3.3 引用，不加正文表）

正文 §5.7 保持现有散文格式（1 段，3 行），补充一句竞品视角：

> **渲染。** Full rendering metrics for all our configurations (18 sequences × 2 arms × 4 metrics,
> 3-seed mean ± sd) are in S3.3. Of the four metrics, only **depth-L1 against ground-truth depth**
> is co-ordered with ATE; full-frame PSNR rewards the arm with the worse trajectory because the
> training views are captured from the drifted poses (Sec. 5.7). RGD-SLAM reports a Before/After
> pair: its "Before" PSNR (tracking-only map) ranges 14.9–23.3 dB, consistent with our range;
> its "After" PSNR (post-refinement) is 4–5 dB higher but corresponds to a different pipeline
> stage. The combined configuration does not improve PSNR over mask-free on any sequence,
> confirming that the trajectory-quality advantage is orthogonal to the rendering-quality metric.

### 3.3 显存优势（可加到效率表脚注或正文 1 句）

这是一个**可用的卖点**，且不需要跑新实验：
> "The combined configuration's peak GPU memory (4.5 GB) is 61% of RGD-SLAM and 37% of
> WildGS-SLAM on the same benchmark, and the mask-free variant (2.7 GB) fits within 6 GB —
> confirming feasibility for resource-constrained deployment."

### 3.4 各竞品在论文中的处理方式

| 方法 | 正文主表 | 效率表 | 渲染引用 | 正文散文说明 |
|---|---|---|---|---|
| **RGD-SLAM** | ✅ ATE 列 | ✅ FPS+GPU 列 | depth-L1 有值 | 同硬件最佳对照 |
| **MonoGS** | ✅ ATE 列 | —（baseline） | S3.3 有值 | backbone 自身 |
| **WildGS-SLAM** | ❌ 不入主表 | ❌ 不入效率表 | S3.3/dptL1 可引用 | 一句话：monocular，硬件不同 |
| **DG-SLAM** | ❌ 不入主表 | ❌ 不入效率表 | 无渲染 | 1 句脚注（DROID 初始化+关键帧差异，详见 SI） |
| **Co-SLAM** | ❌ 不入主表 | ❌ 不入效率表 | S3.3/dptL1 可引用 | 一句话：硬件不同（可能 2060） |
| **DynaSLAM** | ❌ | ❌ | 无渲染 | 纯 CPU，架构不同 |
| **ORB-SLAM3** | ❌ | ❌ | 无渲染 | 非 3DGS，经典参考 |
| **DROID-SLAM** | ❌ | ❌ | S3.3/dptL1 可引用 | 纯跟踪，无建图 |

---

## 四、实施路径（如果同意这个方案）

### 需要做的工作（全部零 GPU）

1. **`build_paper_tables.py` 新增 `table5_efficiency()`**：读 P6-FULLKERN + MASKOFF-3SEED + RGD-SLAM 的 efficiency_raw.csv，生成正文效率表；加 `--check`
2. **正文 §5.7 散文微调**：加入 RGD Before/After 渲染对比 + 显存优势 1 句
3. **SI §S6 扩写**：DG-SLAM 的不可比性说明（来自 Excel 注释）+ GPU 口径矩阵
4. **`VISUAL_AUDIT.md` 更新**：记录本轮设计决策

### 不需要做的工作

- ❌ 不需要新跑任何 GPU 实验
- ❌ 不需要重做 S3.3（已有完整渲染表）
- ❌ 不需要重做 Table 1（ATE 主表不动）

---

## 五、需要你确认的两个决策点

**决策 1**：效率表是独立 Table 5（放在 §5.7 位置），还是合并到 Table 1（加列）？
- **我的建议：独立 Table 5**——Table 1 已经 6 列 18 行很拥挤；效率指标口径不同（online FPS 不含 RAFT），放一起反而混乱

**决策 2**：RGD-SLAM 的渲染 Before/After 差异（5 dB）是否值得在正文提及？
- **我的建议：值得**——它解释了为什么不同论文的 PSNR 数字不能直接比较（同一方法不同 pipeline 阶段差 5 dB），堵住一个可预见的审稿问题
