# Re-review (Round 2) — MMM 2026 submission

**Reviewer:** Claude (Opus 5), acting as independent peer reviewer
**Date:** 2026-08-30
**Material:** `papers/maskfree_bundle/latex/main_v3.pdf`, rebuilt 2026-08-30 17:51 (14 pp.). Supplement S1–S12 still **not** available.
**Prior report:** `review_mmm2026_claude.md` (Round 1, Weak Reject / Confidence 3)
**Scope note:** at the author's request this round audits **text, captions and tables**; figure rendering/layout defects were not re-audited except where a caption disagrees with the body.

---

**Overall recommendation:** Borderline *(up from Weak Reject)*
**Confidence:** 3 / 5

**Revised dimension scores** — (a) MMM relevance **2** (unchanged); (b) novelty **3**; (c) technical soundness **3**; (d) presentation **3**; (e) experimental rigor **4** (unchanged, still the paper's strength).

---

## 1. Disposition of Round-1 concerns

### Resolved

| ID | Status | Evidence in revision |
|---|---|---|
| **R1-M1** *(was blocking)* | **Resolved** | Sec. 5.2 now poses the two questions separately — "Is any single component globally necessary (∆f(s) ≥ 0 ∀s)? Does any sequence reward the full bundle (∆f(s) ≥ 0 ∀f)?" — states the decision rule ("For significant cells only — \|mean\| ≥ 1 sd, the same bolding rule as Fig. 3"), and discloses that ∆L is positive on 5/5 "though 3 of the 5 cells are directional". The headline is reworded to "the full bundle is nowhere strictly necessary in this design". Fig. 3's strip is relabelled to the significance criterion and its caption now matches. The `mv_no_box` "no" is now consistent with the stated rule. The self-contradiction is gone. |
| **R1-M2** | **Largely resolved** | Abstract now reads "our combined **(masked)** configuration leads the RGB-D 3DGS class **we reproduce under one protocol** … against 7.4 for the strongest **such** system, RGD-SLAM." Sec. 5.1 adds the concession outright: "Two CPU-side dynamic systems average better (NGD-SLAM 3.2, DynaSLAM 4.0)". Both the unqualified superlative and the un-flagged masking are fixed. (See **N4** for a new overstatement in the replacement sentence.) |
| **R1-M3** | **Resolved on the key point** | Sec. 5.7: "Its Mask R-CNN runs online (per keyframe, cached, included in rate and memory); only the RAFT flow (54 ms/frame) is precomputed and outside the online rate." The FPS claim is downgraded to "statistically indistinguishable from our RGD-SLAM reproduction (0.75±0.09 vs 0.67±0.16, within one sd)". Exactly what was asked. (But see **N1** — the disclosure breaks a nearby inference.) |
| **R1-M6** | **Resolved** | Contribution 3's verb changes from "confirmed by" to "measured on"; "the coherent … component **moves the way the trade predicts** … — on one sequence, with two legs near their floors". Sec. 5.6 adds "the measurement is consistent with it — on one sequence, with two of the three legs within 1.4× of their floors" and "The sign flip rests on the comfortable leg (ATE, 4.0× floor)". Fully addressed. |
| **R1-M4** | **Claim narrowed** | Sec. 5.4 now states the confound itself: "The counterpart differs from our mechanism in more than the weighting form (no MAD normaliser, no geometric cue, hard removal), so this control rules out the information alone — what it shows is that a reasonable single-threshold use of the same flow does not reproduce the result." The stronger control is still not run, but the claim no longer overreaches. Acceptable. |
| **R1-m1** | Fixed | "(`balloon`)" named; "(full 18-sequence table: S12)" added. |
| **R1-m2** | Fixed | "On Replica **[16]** (**outside the pre-registered denominator**)"; Straub et al. added as ref [16]. |
| **R1-m3** | Fixed | "(full table S12)" pointer added to Limitation 2. |
| **R1-m4** | Fixed | Limitation 5 now reads "The crowd-regime gain **is attributable to the bundle** — no single component recovers it", matching Sec. 5.3. |
| **R1-m5** | Fixed | Fig. 4 caption: "the grey one lands in the **N-ambiguity interval**". |
| **R1-m6** | Fixed | "(5 + 6, **all outside the 18-sequence denominator**): **8 of the 10 decidable** agree in direction". |
| **R1-m9** | Fixed, with a side effect | WildGS-SLAM `crowd2` now 2.16 ± 0.04. See **N7**. |
| **R1-m10** | Fixed, strongly | Table 1 caption: "**Every row, competitors included, is our own reproduction** under one protocol (per-seed artifacts: S1)"; GPU column now "other rows were measured on other hardware and are not comparable across rows." |
| **R1-m12** | Fixed | "when L is off, **both of its consumption sites go off with it (site 2 reverts to integer counts)**". |
| **R1-m14** | Fixed | arXiv identifiers added to [9] and [26]. |
| **R1-m16** | Fixed | "the mover **shows up in** that disagreement, though so can occlusion boundaries and flow error; the robust normaliser of the next step is what absorbs those." |

### Not addressed

- **R1-M5 — the reliability map is computed from the pose it is meant to protect.** Sec. 3.4 is unchanged on this point: f_static comes "from reprojection through the current depth and ego-motion", and the map is "computed once per frame after `warmup_iters` = 10 tracking iterations, then frozen". The only failure mode named for this component is still the τ-majority-statistic one, and the crowd-regime failure is still attributed to it alone. The two candidate explanations remain unseparated. **Carried forward as a major concern.**
- **R1-M7 — the missing prior-free residual/geometric related-work line.** Sec. 2 is unchanged apart from renumbering; ReFusion still appears only as [14], the BONN dataset citation, never as a method. **Carried forward.**
- **R1-m11 — "each cell is exactly one run directory (latest run per seed)"** (Sec. 4) is unchanged and still unexplained, which sits awkwardly beside the strengthened pre-registration framing.
- **R1-m13 — Sec. 2.2's "Hence our label: mask-free, never prior-free"** is unchanged: whose label this is remains ambiguous, and the authors' own frozen-RAFT dependence is still not named at the point where WildGS-SLAM's retained learned prior is criticised.
- **R1-m15** — the PDF is still typeset on US Letter (612 × 792 pt) rather than the LNCS/A4 trim.

## 2. New concerns

### N1 (Major) — the newly-disclosed online Mask R-CNN contradicts the memory attribution two sentences later.
**Location:** Sec. 5.7 and Table 3 (p. 12).

Sec. 5.7 now states that combined's Mask R-CNN "runs online … included in rate and memory". Table 3 then gives: combined 4.02 GB / 61,371 Gaussians; mask-free 3.43 GB / 67,600 Gaussians. So the arm with **10 % more Gaussians uses 0.59 GB less memory**, and the one structural difference newly disclosed between them is an online segmentation network. The section nevertheless closes: "Since the Gaussian counts differ by only 10 % between arms, the memory gap is the lifecycle, not map size."

That inference fails on either reading of "the memory gap":
- If it is combined − mask-free (0.59 GB): the **lifecycle is identical in both arms**. Sec. 3.6 says the mask switch "opens exactly two code paths — the mapping loss and the keyframe-insertion gate, **both in this component**", and the lifecycle (D) is not among them; Sec. 5.2 confirms D is "pinned identically in all cells". So the lifecycle cannot explain a difference between two arms that share it — whereas the newly-disclosed Mask R-CNN can.
- If it is ours − RGD-SLAM (3.35 GB): RGD-SLAM's Gaussian count is "—", so "counts differ by only 10 % between arms" gives no purchase on that comparison at all.

*Why it matters:* the memory figure is one of the two quantitative claims in the abstract, and this is its only mechanistic explanation. As written the explanation is contradicted by the very disclosure that was added to fix R1-M3.

*What would resolve it:* report the Mask R-CNN's memory footprint separately, and re-attribute the gap — or drop the causal sentence and state the numbers without one.

---

### N2 (Major) — Sec. 3.6 contradicts itself about how many sites the mask touches, and the revision has made that contradiction load-bearing.
**Location:** Sec. 3.6 (p. 7), Fig. 1 caption (p. 4), Sec. 5.6 (p. 11).

Sec. 3.6, in consecutive sentences: the mask "is applied at the mapping loss and the keyframe-insertion gate, **and for the first `warmup_iters` tracking iterations as a hard mask on the tracking residual**, after which the soft weight of Sec. 3.4 takes over. The switch opens **exactly two** code paths — the mapping loss and the keyframe-insertion gate." Three sites are listed, then two are claimed. Fig. 1's caption propagates the two-site version ("the optional semantic mask (combined configuration only; mapping loss + keyframe-insertion gate, never through L)").

In Round 1 this was a wording slip. It is no longer, because Sec. 5.6's single-variable intervention was rewritten to make its identity explicit: "**extending the hard tracking mask from the first 10 to all 100 tracking iterations**". Contribution 3 therefore intervenes on precisely the third site — the one Sec. 3.6 and Fig. 1 both say is not part of the switch.

*Why it matters:* a reader who trusts Fig. 1 and Sec. 3.6 cannot locate the quantity Sec. 5.6 manipulates. It also relocates Contribution 3: the measurement is on the **masked** configuration's mask schedule, not on the mask-free reliability core the paper is named for. That should be stated where the contribution is claimed (Sec. 1), not left to be inferred.

*What would resolve it:* delete "exactly two", list all three sites in Sec. 3.6 and in Fig. 1's caption, and say in Sec. 1 contribution 3 that the intervention is on the semantic mask's tracking schedule.

---

### N3 (Major / question) — read plainly, Sec. 5.6's most solid number says the hard mask beats the soft reliability weight on ATE.
**Location:** Sec. 5.6, Sec. 3.4, Sec. 3.6.

Sec. 3.6 says the hard mask runs "for the first `warmup_iters` tracking iterations … **after which the soft weight of Sec. 3.4 takes over**", and Sec. 3.4 says the reliability map is computed "once per frame **after** `warmup_iters` = 10 tracking iterations". The two appear to be sequential and mutually exclusive. If so, then in Sec. 5.6's 100/100 arm the hard mask covers every tracking iteration and the soft reliability weight **never applies to tracking at all** — and that arm is the one reported better on full-trajectory ATE by −1.42 cm at 4.0× its floor, the one leg Sec. 5.6 itself calls "the comfortable leg".

Taken at face value, the paper's cleanest pose-side measurement shows that on `balloon`, replacing its own bounded soft weight with the hard semantic mask throughout tracking **improves** the endpoint the paper treats as authoritative. That is in tension with Sec. 3.4 ("a pixel is attenuated by at most 10× and never removed — the sharpest difference from a mask, and the comparison Sec. 5.4 leans on") and with the framing of Sec. 5.4.

I flag this as a question rather than a finding because the paper never states whether the soft weight is *additionally* applied in the 100/100 arm. But as the text currently reads, the implication is there, and a reviewer will draw it.

*What would resolve it:* state explicitly whether w_rel is active in the 100/100 arm; if it is not, discuss the result's implication for the soft-vs-hard argument rather than presenting the arm only as a variance–bias illustration.

---

### N4 (Moderate) — the sentence that replaced the old overstatement contains a new one.
**Location:** Sec. 5.1 (p. 8).

The new text reads: "Two CPU-side dynamic systems average better (NGD-SLAM 3.2, DynaSLAM 4.0) but produce no dense map; a reader who needs a reconstructable 3DGS scene (Fig. 2) **has no alternative in this table**, and combined is the most memory-efficient arm in its class that provides one."

Table 1 contains RGD-SLAM (Avg 7.6), DG-SLAM (5.3), SplaTAM, Co-SLAM, RoDyn-SLAM, DynaGSLAM and WildGS-SLAM — all dense-map systems. There are alternatives; they are simply worse on this table's metrics. The concession is welcome and the argument is sound, but "no alternative" is false as written and is the kind of sentence a reviewer marks twice.

*What would resolve it:* "no *more accurate or more memory-efficient* alternative in this table", or name the class explicitly.

---

### N5 (Moderate) — "directional cells count as no support" converts uninformative cells into evidence of absence.
**Location:** Sec. 5.2 and Fig. 3 caption (p. 9).

The new rule is stated cleanly and applied consistently, which resolves R1-M1. But the conclusion drawn from it — "**both answers are negative**" — is stronger than the rule licenses. A cell such as ∆L on `mv_no_box` (+0.16 ± 0.42) does not fail to support necessity; it fails to *decide*. With n = 3 the design is underpowered by construction, so "no support" is absence of evidence, and reading it as a negative answer is the classic inversion. The same applies to the "0 of 5" count, three of whose exclusions rest on cells that cannot decide either way.

The paper's own "With 3 seeds per cell, every statement is descriptive" partly covers this, but the headline sentence does not inherit that qualifier.

*What would resolve it:* "neither is established across the five measured sequences" rather than "both answers are negative"; and in Sec. 1, "no sequence *demonstrably* rewards all three".

---

### N6 (Major, venue compliance — not science) — Secs. 4–7 are typeset at a reduced size.
**Location:** p. 7 onward.

Measured on the rendered PDF at 300 dpi with identical text-block width throughout (622 px at 130 dpi on every page): body line pitch is **50 px above the "4 Experimental Protocol" heading and 46 px below it, on the same page** — an ~8 % reduction, matching the LNCS `\small` step (12 pt → 11 pt leading). Pages 1–6 (Secs. 1–3) are at full size; pages 7–12 (Secs. 4–7) are not. The transition is visible mid-page.

*Why it matters:* the 12-page body limit is then met at a type size the venue does not permit, which is a routine desk-check item at Springer LNCS venues. It also produces a paper whose second half reads noticeably denser than its first.

*Additional note:* the compression looks avoidable. Pages 6, 10 and 12 each carry substantial unused vertical space from float placement — p. 10 in particular has roughly a quarter-page blank below Table 2 while §5.5's paragraph breaks mid-sentence across the figure. Reclaiming that space would likely recover more than the ~8 % the type shrink buys.

*What would resolve it:* restore uniform body size and recover the space from float placement, or cut text.

## 3. Minor comments (new)

- **R2-m1** — Table 1: WildGS-SLAM's `crowd2` is printed as 2.16 ± 0.04 (two decimals) while every other cell, including the authors' own tied 2.2 ± 0.1 in the same column, keeps one. The extra digit is exactly what decides the bold in that column. Print both at the same precision, or neither.
- **R2-m2** — Table 1 caption: if "every row, competitors included, is our own reproduction", then DynaGSLAM's ± 0.0 on all four columns and WildGS-SLAM's ± 0.0 on two are worth a word — exact-zero seed spread across three runs reads as deterministic or as a single run. Also, "other rows **were measured** on other hardware" leaves the measurer unspecified; the previous wording ("as reported by their authors") was clearer on provenance even though it was inconsistent with the new reproduction claim.
- **R2-m3** — Table 3 caption still says only "online phase only; RAFT excluded". It should also say that combined's Mask R-CNN **is** included, since that is now the section's key disclosure and a reader of the table alone cannot infer it.
- **R2-m4** — Fig. 4c caption and Sec. 5.5: the held-out rounds are now stated to be "all outside the 18-sequence denominator", but the caption does not say that the five plotted squares are outside it, and the legend's category counts (9 + 8 + 1 = 18) invite reading the squares as part of the 18. One clause in the caption fixes this.
- **R2-m5** — Sec. 5.4: "The naive counterpart beats vanilla on only 2 of 4" uses an unstated criterion. By mean log-ratio the counterpart is below parity on three of the four (`pt1`, `mv_no_box2`, `balloon2`); the count of 2 holds only under the all-seeds-agree rule, which the same sentence applies explicitly to the authors' own arm ("with all seeds agreeing") but not to the counterpart. State the rule once, for both.
- **R2-m6** — Sec. 2.3: "What is missing is not another robust kernel but **the two measurements** Sec. 1 named" — Sec. 1 numbers **three** contributions. This tracks Sec. 1's earlier "evidence for two questions", but the counts now disagree on the page. Reconcile.
- **R2-m7** — Sec. 5.2's parenthesis "(the crowd regime is absent from this factorial; its attribution evidence is the single-sequence study of Sec. 5.3)" is a good addition, but Sec. 5.3 covers **two** sequences (`mv_no_box` and `crowd2`); "single-sequence" presumably means the crowd regime is represented by `crowd2` alone. Rephrase to avoid the apparent conflict with Table 2.
- **R2-m8** — Sec. 4 retains "each cell is exactly one run directory (latest run per seed)" (R1-m11, unaddressed). Given that Table 1 now claims every competitor row as the authors' own reproduction, this selection rule applies to competitors too and should be justified.

## 4. Questions to authors (Round 2)

1. **(Sec. 5.7 / Table 3)** Now that the Mask R-CNN is stated to run online and be included in rate and memory, how is the 0.59 GB combined − mask-free gap attributable to "the lifecycle", given that the lifecycle is pinned identically in both arms and mask-free carries 10 % *more* Gaussians?
2. **(Sec. 5.6 / Sec. 3.6)** In the 100/100 arm, is the soft reliability weight w_rel applied to the tracking residual at all, or does the hard mask fully replace it? If the latter, how does the −1.42 cm ATE improvement bear on the soft-vs-hard argument in Sec. 3.4?
3. **(Sec. 3.6 / Fig. 1)** Does the mask switch open two code paths or three? Sec. 3.6 lists three and then says two; Fig. 1's caption says two; Sec. 5.6 intervenes on the third.
4. **(Sec. 3.4)** Since f_static is built from the pose after 10 warm-up iterations and then frozen, how much does the reliability map degrade when that pose is already dragged by movers — and can that be separated from the τ-majority-statistic explanation for the crowd-regime failure? *(Carried from Round 1, unanswered.)*
5. **(Sec. 5.2)** With three of the five ∆L cells inside 1 sd, is the intended claim that no single component is globally necessary, or that the design could not determine whether one is?

## 5. MMM fit assessment

Unchanged from Round 1, with one small movement in the right direction. The revision adds the first sentence in the paper that argues from what a *reader of the media artifact* needs — "a reader who needs a reconstructable 3DGS scene (Fig. 2)" (Sec. 5.1) — which is the beginning of a multimedia case. It remains a single clause. Everything else is unchanged: no media application, no discussion of the reconstruction as a deliverable, and Sec. 5.7 still reports that full-frame PSNR ranks the unmodified backbone above both of the paper's arms. This is still a robotics/SLAM paper submitted to a multimedia venue; the honest verdict is that fit is weak and would need the dense-map argument developed into an actual contribution — per-sequence rendering results in the main text and a stated use for the map — rather than one sentence.

## 6. Overall assessment of the revision

The blocking defect from Round 1 is gone, and it was fixed properly — not by deleting the claim but by stating the decision rule and letting the weaker conclusion stand. Three further majors (positioning, efficiency accounting, Contribution 3's overclaim) and eleven of sixteen minors are resolved, several of them by adding statements *against* the paper's own interest. That is a good-faith revision and it raises my recommendation.

It does not yet reach acceptance. Two Round-1 majors were left untouched (the reliability map's dependence on the pose it protects; the missing prior-free residual/geometric related-work line), and the revision has exposed a new cluster around the semantic mask: how many sites it touches (**N2**), what Contribution 3 therefore measures (**N2**, **N3**), and whether the memory story survives the disclosure that fixed the efficiency concern (**N1**). None of these needs new GPU runs — N1, N2 and N4 are corrections, N3 is a clarification the authors already know the answer to, and N5 is a rewording. The typesetting issue (**N6**) is mechanical but should be fixed before submission.

If N1–N3 are corrected, R1-M5 is at least acknowledged as a second candidate explanation, and the type size is restored, I would move to **Weak Accept** on the science — with MMM fit remaining the standing reservation, and one I do not expect the authors to overcome without changing what the paper is about.

---

## Note for the project record (not part of the referee text)

This is a **simulated** referee report, produced from the PDF alone; it is not an actual MMM 2026 review, and contains no rebuttal or revision drafting. Per the author's instruction this round, figure *rendering* was not audited; caption *text* was. Round-1 items R1-m7 and R1-m8 (figure composition/annotation defects) are therefore not re-assessed here, though R1-m7 (Fig. 2 overlap) was observed to be fixed before that instruction was given.

**Method note on N6:** the type-size finding is measured, not impressionistic — line pitch on p. 7 is 50 px above and 46 px below the "4 Experimental Protocol" heading at 300 dpi, and the pitch is 22 px on pp. 3/5 versus 20 px on pp. 7/8/10/12 at 130 dpi, with the ink x-range identical (244–866 px) on every page measured.

**On R2-m5:** in Round 1 I checked and dropped a "3 of 4, not 2 of 4" concern about Sec. 5.4 after confirming from Fig. 4a that `balloon2`'s naive mean sits near parity. At higher resolution the naive mean on `balloon2` is visibly below parity (≈ −0.12 in log ratio, ~1.13× better), so the count of 2 depends on the all-seeds-agree criterion. The claim is still defensible; what is missing is the stated rule. This is now raised as a minor, not as a correction to the paper's arithmetic.
