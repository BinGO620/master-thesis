# Review — MMM 2026 Round 3 (Independent)

**Paper:** RoGS-SLAM: Robust Dynamic-Scene Gaussian Splatting SLAM via Reliability-Guided Weighting and Coverage Sampling
**Reviewer expertise:** SLAM / 3D vision; experimental methodology
**Materials reviewed:** Main paper (14 pp: 12 pp body + 2 pp references) and Supplementary (9 pp), both read in full; all quantitative spot-checks below were recomputed by this reviewer from the extracted text.

---

## Summary

The paper presents RoGS-SLAM, a modification of the MonoGS 3D-Gaussian-splatting SLAM backbone for dynamic RGB-D scenes. Instead of detecting movers with an external class-conditioned segmentation network and removing them, the method decides per-pixel trust from *consistency*: the disagreement between observed optical flow (frozen RAFT) and the rigid flow implied by the current depth and ego-motion, combined with a geometric depth-residual cue, is turned into a soft static-confidence weight that down-weights (never removes) pixels in the tracking residual. Four components are attached at four named sites: uniform temporal keyframe coverage (K), Huber IRLS robust reweighting (R), the flow-consistency reliability signal (L, consumed at exactly two sites: the tracking residual and candidate confirmation in a lineage-based density lifecycle), and the density lifecycle (D, held fixed throughout). An optional semantic person mask yields a "combined" configuration; the mask-free configuration is the paper's core.

The paper's stated contributions are explicitly *measurements*, not a new primitive: (1) a pre-registered 120-run factorial over K, R, L finding that component necessity is regime-dependent — no sequence demonstrably rewards all three, so the full bundle is nowhere strictly necessary; (2) an equal-information control showing that a naive p90 hard threshold on the byte-identical frozen flow is worse than vanilla on pt2 while the proposed weighting improves all four sequences, ruling out "the gain is just the extra information"; (3) a single-variable intervention (hard tracking mask from 10 to 100 iterations) exposing a variance–bias trade across three pose-side endpoints, leading to the methodological injunction that pose-side claims must name their endpoint. The paper further gives a per-frame observable (mask-free RPE) that separates mask-necessary from mask-redundant sequences, claims no state-of-the-art accuracy, and reports its own failure regimes (crowd, pt1, static Replica).

---

## Strengths

**S1. Exceptional main-text numerical consistency; claims survive independent recomputation.** I recomputed every checkable main-text number and all of them reproduce: all 13 row averages of Table 1 from its per-cell entries; the mask-necessity classification N = ATE_mask-free/ATE_combined over all 18 sequences from S12 yields exactly the claimed 9 redundant / 8 necessary / 1 ambiguous split of Fig. 4c; the "N differing 12.6-fold" claim for f3_st_hf vs crowd recomputes to 12.60; the "costing 1.19–1.34×" for ∆L on pt2 and balloon follows exactly from exp(0.17), exp(0.29); the 18-sequence rendering means in §5.7 (18.8/18.6 dB PSNR; 31.4/32.3 cm depth-L1) reproduce to the stated digit from the S3.3 per-sequence table; the held-out tallies (4/5 and 4/6, two conservative misses, no RPE inside the band) are consistent with the per-seed S8 tables, including the N ≈ 1.42 in-band case (moving_obstructing_box). This level of internal consistency is rare.

**S2. The equal-information control of §5.4 is a genuinely well-designed attribution experiment.** Giving the naive counterpart the *byte-identical* frozen flow and comparing under a strict causal budget isolates the mechanism from the information — exactly the confound most ablation studies in dynamic SLAM leave open. The scoping is honest: "this control rules out the information alone; it does not rule out every flow-consuming treatment" (§5.4, p. 10).

**S3. Unusual honesty about negative results and measurement limits.** The paper reports its own static-scene degradation (Replica office0 3.82±4.58 vs 0.368±0.012 cm, §6 item 3), discloses that full-frame PSNR anti-corroborates trajectory quality (§5.7, S5), quantifies same-seed run-to-run nondeterminism (1.36× on balloon, S1.3/S5), flags 8/18 baseline CV > 20% (S3.1), and includes closed negative results (temporal aggregation, residual-derived map weights in S11). The S2 audit that "corrected three errors in an earlier draft of the body" is the kind of self-scrutiny one wants to see.

**S4. Clean component-to-attachment-point formalization.** §3, Fig. 1, and S2 define each component's intervention site, constants, and lifecycle unambiguously enough that the ablations read as interventions on named quantities (e.g., L consumed at exactly two sites, both removed together; the mask never routed through L). The disclosure of the inert `occ_tighten_thresh` and the parameter-block wart (S2) adds credibility.

**S5. Page compliance is satisfied.** Pages 13–14 contain only the reference list (29 entries); the body ends with §7 on p. 12. The 12 + 2 format rule is met.

---

## Major Concerns

**C1. Four of eight improvement ratios in SI S3.2 cannot be reproduced from the paper's own S12 table, by margins far exceeding the paper's stated tolerance.**
Location: SI S3.2 ("Per-sequence improvement, with pairing ranges") vs. S12, cross-checked against Table 1.
Evidence: S3.2 states "Combined: f3_wk_rpy 17.13×, balloon 12.85× (conservative 11.97×), f3_wk_xyz 9.20×, balloon2 4.18×, pt2 4.20×" and "crowd2 60.93× against a baseline of 147.46±39.03, crowd 37.11× against 86.47±18.34, f3_wk_hf 14.67× against 44.45±11.06". Recomputing from S12's own cells: f3_wk_rpy 62.89/4.29 = **14.66×** (claimed 17.13×, −14.4%); crowd2 147.46/2.19 = **67.33×** (claimed 60.93×, +10.5%); f3_wk_hf 44.45/3.29 = **13.51×** (claimed 14.67×, −7.9%); crowd 86.47/2.29 = **37.76×** (claimed 37.11×, +1.8%). Meanwhile balloon, f3_wk_xyz, balloon2, and pt2 match mean/mean *exactly*, so the computation rule is demonstrably mean/mean for those cells. The paper's own reconciliation note ("Body ratios are computed from full-precision per-run values, so they can differ in the last digit from quotients of the rounded values here", S12) covers at most a ±0.01-level effect, not 8–14%. S3.2 also states "The improvement ratios in S3.2 divide by the 3-seed rerun of the unmodified backbone" — which is what S12's MonoGS column is.
Why this is a problem: the paper's central selling point is measurement discipline ("every reported cell is traceable to a single run directory", S1; refusal gates in S3). Four unreproducible ratios inside the evidence apparatus directly undercut that claim, and suggest stale values from an earlier data version survived into the SI.
Minimum fix: recompute all S3.2 ratios from the final per-run values, or state the exact alternative computation rule (e.g., per-seed pairing) if one was used, and reconcile every cell against S12. No new experiments needed.

**C2. "Consistent with zero" language contradicts the paper's own no-equivalence disclaimer, and the descriptive support rule's error rate is never quantified.**
Location: §1, contribution 1 (p. 2) and §5.2 (p. 9) vs. S11.1.
Evidence: §1 claims "robust reweighting is consistent with zero within the seed spread on 3 of 5 sequences"; §5.2 states "∆R is consistent with zero on the three easier sequences". But S11.1 states "No claim of statistical significance or equivalence is made anywhere", and §5.2 itself defines the same three R cells (+0.03±0.19, −0.01±0.18, −0.01±0.15 in Fig. 3) as "directional, i.e. **undetermined** rather than negative". "Consistent with zero" inverts the epistemic status of an underpowered cell: with 3 seeds, nearly any effect small or moderate is "consistent with zero". Relatedly, the support rule "|mean| ≥ 1 sd" corresponds to |t| ≥ √3 ≈ 1.73 at df = 2, i.e., a ~23% two-sided false-positive rate per cell under the null; across the 15-cell matrix of Fig. 3 one would expect ~3 spurious "supported" cells by chance, yet the paper never states this, and bold cells are used to assert directionality as measured fact (e.g., "∆K < 0 on balloon and pt1", §5.2).
Why this is a problem: this is precisely the class of overreach the paper polices in others; a reader of §1 alone would take "consistent with zero" as an established null.
Minimum fix: replace "consistent with zero" with "not distinguishable from zero at this seed count" in §1 and §5.2, and add one sentence in §5.2/S11.1 quantifying the per-cell false-positive rate of the bolding rule and the multiplicity caveat for the 15-cell matrix.

**C3. Two of the three pose-side endpoints in §5.6/Fig. 5 have no per-run documentation or noise-floor construction in the SI, and the cited cross-check is absent from its cited location.**
Location: §5.6 and Fig. 5 (pp. 11–12) vs. S7.
Evidence: Fig. 5's caption attributes the f3_wk_xyz cross-check to S7 ("the f3_wk_xyz cross-check stays below its floor (S7)"), and §5.6 repeats "the cross-sequence check is below floor (S7)". S7 contains **no** f3_wk_xyz data anywhere; moreover S7 states the per-frame dynamic annotation is "available only on balloon", which makes it unclear what quantity the cross-check even measures on f3_wk_xyz. S7 documents in full only the middle endpoint (coherent amplitude, per-run table, gates, F−E = −0.0248 vs floor 0.0180 = 1.38×); the other two bars of Fig. 5 — "per-frame penalty worse (+0.0806, 1.22× floor)" and "full-trajectory ATE better (−1.42 cm, 4.0×)" — appear nowhere in the SI with per-run values, floor definition, or number of re-runs. The "variance-matched re-run floor of 0.0180" itself is under-specified: the S7 decomposition gives within-config noise E = 0.0113 and F = 0.0180, and it is not stated how the floor for the *difference* F−E is derived from these (using E's 0.0113 would give 2.19×, a pooled estimate 1.64×, and F's 0.0180 gives the reported 1.38×).
Why this is a problem: contribution 3 rests entirely on this three-endpoint chain; two of its three legs are currently unverifiable, and the strongest-sounding leg's floor construction is ambiguous in a direction that changes the reported margin by up to 1.7×.
Minimum fix: extend S7 with (i) per-run values and floor construction for the per-frame penalty and ATE endpoints, (ii) an explicit definition of "variance-matched re-run floor" (which arm's noise, how many re-runs, how combined), and (iii) the actual f3_wk_xyz cross-check values and the quantity measured there, or delete the cross-check claim.

**C4. The pre-registration claims are unverifiable by a reviewer, and the paper switches between at least four different descriptive decision rules without stating how they relate.**
Location: §4 (p. 7), §5.2, §5.4, §5.5, S1, S2.2, S2.3, S7.
Evidence: §4: "Decisions below were frozen before the campaigns of Sec. 5 ran; the full protocol is S1." All pre-registration evidence is internal (e.g., "results/evidence/pose_coherent_prereg.md (committed before the analysis script existed)", S7; "EXP55/58/59" files) — none of it is externally timestamped or available to the reviewer. Meanwhile the operative decision rule differs per campaign: |mean| ≥ 1 sd (§5.2, Fig. 3), "all-seeds-same-sign criterion" (§5.4, applied "to both arms"), non-overlapping-group gap with N ≥ 1.5 / N ≤ 1.2 thresholds (§5.5), and a floor "max(0.43 cm, 6% of the larger mean)" (S2.2) whose constants' provenance is not given. Additionally, the "~30% cross-campaign drift discipline" is invoked twice — "the ~30% cross-campaign drift discipline applies" (S2.2) and again in S2.3 — but is **never defined anywhere** in the paper or SI.
Why this is a problem: "pre-registered" is doing real argumentative work in the abstract and contributions; if it cannot be checked, its weight depends entirely on trust, and undefined disciplines ("~30%") read as placeholders. The heterogeneity of rules is defensible in principle (each fixed per campaign), but the reader is given no way to compare "supported" verdicts across campaigns.
Minimum fix: (i) define the ~30% cross-campaign drift discipline where it is first used, (ii) state the origin of the 0.43 cm / 6% floor, (iii) add one paragraph in S1 enumerating the per-campaign decision rules side by side, and (iv) either provide an anonymized verifiable timestamp for the pre-registrations (e.g., anonymized commit hashes or a registry DOI) or soften "pre-registered" to "fixed before the campaign per our internal logs".

**C5. The same configuration–sequence cell is quoted with different values in different sections, without reconciliation at the point of quotation.**
Location: §5.3 / S2.3 vs. Table 1 / S12; S10 vs. S12 / S4.
Evidence: (a) §5.3 quotes "full 2.11 cm" for combined on crowd2 (S2.3: "Combined (full) … 2.11 ± 0.08"), while Table 1 and S12 report the same cell as 2.19±0.09. (b) §5.3 quotes the mv_no_box full arm as "2.63±0.09" vs. S12's 2.66±0.12. (c) Most strikingly, S10's cuesplit factorial lists the "both (default)" arm on balloon as 13.85±0.58, while S12/S4 report the mask-free balloon cell as 12.11±2.33 — a 14% mean shift *and* a 4× smaller sd for what should be the same configuration; on mv_no_box S10's "both" reads 2.86±0.27 against 3.09±0.46 (S12/S4, coverage on) and 3.90 (S4, coverage off), matching neither. S2.3 acknowledges the anchor issue obliquely ("the P11 and Combined anchors share the EXP53 campaign") but no section reconciles the actual numbers.
Why this is a problem: the paper itself discloses that same-seed re-runs can differ by 1.36× (S1.3), so cross-campaign divergence is expected — but then each divergence must be surfaced where the number is quoted, otherwise a reader comparing §5.3 to Table 1 sees two values for one cell with no explanation, and cannot tell which is canonical.
Minimum fix: wherever a repeated cell is quoted from a non-main-table campaign, print both values (or the delta) with a one-line pointer to the drift disclosure, and state explicitly which coverage setting S10's factorial ran with.

---

## Minor Issues

**M1. "Held-out" is used with two incompatible meanings.** The abstract claims the naive counterpart "is worse than the baseline on one held-out sequence" and §1 contribution 2 says "2 of 4 held-out sequences", but the four sequences of §5.4 (pt1, pt2, mv_no_box2, balloon2) are inside the fixed 18-sequence denominator and were used in the §5.2 factorial; they are held out only from the p90 threshold-fitting pilot. §5.5 reserves "held-out" for sequences "all outside the 18-sequence denominator". Fix: say "held out from the threshold-fitting pilot" in the abstract and §1.

**M2. Broken/ineffective SI pointer in §5.7, and backbone rendering numbers with no SI backing.** §5.7 (p. 12) cites "(full rendering table: SI S5)", but the 18-sequence rendering table for the two configurations is S3.3; S5 contains no such table. Moreover the backbone rendering figures quoted there (PSNR 19.1 dB, depth-L1 46.9 cm) appear in no SI table — S3.3 explicitly states "Backbone and competitor rendering numbers are not reproduced here". Fix: correct the pointer to S3.3 and either add the backbone column to the SI or mark the two backbone numbers as main-text-only.

**M3. §3.3's "neither is ever better" omits the floor qualifier that makes it true.** Main text: "neither is ever better, on pt2 both degrade clearly (+1.8 and +2.5 cm)". In S2.2's own table the raw means are *lower* for Cauchy on mv_no_box (2.56 vs 2.66), pt1 (11.45 vs 11.89) and f3_wk_hf (3.23 vs 3.29), and for Geman–McClure on f3_wk_hf (2.97 vs 3.29) — all within the pre-registered floor. The main-text sentence is only correct under the floor rule, which is defined solely in S2.2. Fix: add "within the pre-registered floor" to §3.3.

**M4. Functional forms in §3.4 are under-specified for reproduction.** (i) The mapping of the disagreement magnitude to "a cue eﬂow ∈ [0, 1] through a per-frame robust normaliser, max(1.4826·MAD, floor): 0 at or below the frame median, approaching 1 for robust outliers" never states whether the ratio is clipped at 1 or saturates, nor whether the deviation is taken from the frame median. (ii) "fstatic from reprojection through the current depth and ego-motion" does not say whether the depth is the observed RGB-D depth or the rendered depth. (iii) The geometric cue g's normalisation (geo_scale_floor = 0.0, S2) is not given. (iv) ε in Eq. (1) has no value in S2. Fix: one paragraph or a small S2 extension.

**M5. "Load-bearing" overstates what the deletion statistic shows.** §3.5: "The replacement is load-bearing (the deleted fraction of created lineages has median 0.55)". A 55% deletion rate shows the rule is *active*, not that it carries accuracy; D is never ablated on/off anywhere in the paper (deliberately held fixed in the factorial, and no D-off run is reported). Fix: rephrase to "materially active", and ideally acknowledge in §6 that D's contribution is unmeasured by design.

**M6. The f3_st_hf ambiguity classification rests on a highly dispersed input.** §5.5's exemplar "f3_st_hf and crowd have nearly identical mask-free ATE yet N differing 12.6-fold" uses N(f3_st_hf) = 35.59/29.43 = 1.209, i.e., the sequence's ambiguous/undecidable status (the one grey cell of Fig. 4c) is decided by a 0.009 margin in N computed from a combined arm with sd ±8.00 (CV 27%, S12). The CV>20% flagging discipline of S3.1 covers baselines only. Fix: flag the N inputs' dispersion, not just the baseline's.

**M7. Trivially inconsistent rounding for pt1 mask-free sd.** §6 and S12 report "32.41±8.51" while S3.3 reports "32.41±8.52". Immaterial, but in a paper whose appendix advertises single-run traceability, even this should not occur.

---

## Questions to Authors

1. How exactly is the "variance-matched re-run floor of 0.0180" (S7) constructed — which arm's within-config noise, how many re-runs per cell, and how is the floor of a *difference* derived? The same question applies to the ATE (4.0×) and per-frame-penalty (1.22×) floors of Fig. 5.
2. What is the "~30% cross-campaign drift discipline" referenced in S2.2 and S2.3? It is invoked as if defined but never is.
3. Are the dispersion-tier and f3_wk_rpy ratios in S3.2 computed by per-seed pairing rather than mean/mean? If so, why do four cells match mean/mean exactly while four do not?
4. What exactly is the f3_wk_xyz cross-check in Fig. 5, given that S7 says the per-frame dynamic annotation exists only on balloon? What quantity was measured, and where are its values?
5. In §5.4 the vanilla arm on pt2 reads 45.37 cm, while Table 1's MonoGS on pt2 is 43.85±8.55. Is this a separate campaign re-run, and if so, does the cross-campaign drift discipline apply to the 1.63–4.99× ratios?
6. Which coverage setting was in force in S10's cuesplit factorial? Its "both (default)" cell matches neither S4 column on mv_no_box (2.86 vs 3.09 coverage-on / 3.90 coverage-off) nor the mask-free cell on balloon (13.85 vs 12.11).
7. Was the density lifecycle D ever run in the backbone's commit-immediately mode alongside the other components? If not, how do you decompose the RoGS-vs-MonoGS deltas from the D confound beyond the §3.5 disclaimer?

---

## Multimedia Relevance

The relevance to MMM is defensible but under-argued. The inputs are RGB-D *video*; the output representation is a 3D Gaussian map evaluated with multimedia rendering metrics (PSNR/SSIM/LPIPS/depth-L1); and novel-view synthesis from monocular/RGB-D video is a core multimedia topic. The keywords include "RGB-D video". However, the paper never articulates a multimedia-specific motivation or application (e.g., AR/VR scene capture, free-viewpoint video, streaming of dynamic scene representations), and its center of gravity — trajectory estimation under SE(3), robust kernels, keyframe management — is classic SLAM/robotics. The rendering analysis (§5.7, S5) is the strongest multimedia hook and is honestly handled (the PSNR anti-corroboration finding is genuinely useful for the multimedia audience). I would accept the paper in a 3D/multimedia content-analysis track, but a paragraph connecting the system to multimedia application scenarios would materially strengthen the fit.

---

## Overall Recommendation

**Weak accept.**
**Confidence: 4/5.**

One-sentence rationale: the main text is technically sound, unusually honest, and every number in it that I could check reproduces exactly, but the supplementary evidence apparatus — the paper's declared backbone — contains four unreproducible ratios (C1), undocumented noise floors and a dangling cross-reference behind a headline contribution (C3), and unreconciled duplicate cells (C5), all of which are fixable in documentation but must be fixed before the measurements can be trusted as published.
