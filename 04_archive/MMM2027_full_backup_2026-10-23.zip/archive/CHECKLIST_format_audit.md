# 格式与审稿意见修复 — 移交检查清单（2026-08-31）

> 用途：新会话逐项复核。本轮改动分布在 commit `a3a1d818`（r3 审稿修复）、
> `1dd2e926`（标点去 AI + 加粗瘦身 + 表格重排 + 标题修正）、`25b04c4a`（集成可靠性信号图）、
> `f0eaa8d4`（Fig.2 图面修复）。源文件：`latex/body_v3.tex` + `latex/main_v3.tex`（摘要/标题/关键词）、
> `latex_si/si_body_v3.tex`；md 镜像 `manuscript_v3.md` / `supplementary.md` 必须双侧一致。

## 用户提出的问题清单及处置状态

| # | 用户提出 | 处置 | 新会话复核要点 |
|---|---|---|---|
| 1 | §5.2 有问号 | 两个研究问题已改陈述式（"Two questions follow: whether… and whether…"）；§5.5 同步改为 "We test whether…" | 正文散文中不应再有设问句；Fig.3 图内 strip 标签除外 |
| 2 | 加粗太多、不符合规范 | `\textbf` 64→32：仅保留 run-in 小标题、Limitations 编号头、贡献列表句头、组件名定义（K/R/L/D）、Table 1 caption 的 "Bold"、WildGS 行 `\boldmath` | grep `\textbf` 计数 ≈32；不得出现整句加粗 |
| 3 | 冒号多、括号多、分号多（AI 化痕迹） | 标点瘦身：分号 36→约 15、"X: Y" 冒号句式 31→约 12、长括号 18→约 10；破折号 0（仅 Table 1 占位符 3 个） | 重新统计散文密度（每百词分号 ≤0.7）；抽查是否机械单一代换 |
| 4 | 斜体要少用 | 强调性斜体已全部改正体；仅存术语斜体（mask-free/combined/simpler、detect-then-exclude、Prior Free、class、majority、object-only、unresolved） | grep `\emph` 逐个核对是否术语 |
| 5 | 标题 "Dynamic-Scene" 不合领域惯例 | 改为 "RoGS-SLAM: Robust Gaussian Splatting SLAM in Dynamic Environments via Reliability-Guided Weighting"（与 WildGS-SLAM/DGS-SLAM 句式平行） | `\title` 与 `\titlerunning` 一致性；页眉 = "RoGS-SLAM: Robust Gaussian Splatting SLAM in Dynamic Environments" |
| 6 | 大表 Table 1 层次混乱 | 按表示法×动态性重排四组：Ours (dynamic 3DGS) / Dynamic 3DGS / Dynamic, non-3DGS / Static；DynaGSLAM 归入 Dynamic 3DGS；WildGS-SLAM 标 (mono)；Co-SLAM 标 (implicit)；ORB-SLAM3 标 (sparse)；NGD-SLAM 标 (CPU) | 分组与用户的分类一致；方法列 3.3cm 下括号标签全部单行；caption 有 "combined is the full system, mask-free its core…" 读表指引和 "Method citations: Secs. 2.1–2.3" |
| 7 | mask-free 效果差是否只放 combined | 分析后拒绝（与 "including the four sequences where both arms regress" 的反选择性声明冲突、掏空 mask-free 论文身份）——两行都保留 | Table 1 应同时含两行 |
| 8 | 图片要符合领域八股 | 新会话重画 v4：Fig.3 分组消融柱状图（5 序列 × full/−K/−R/−L，log 轴，○ 标 directional，内置 assert directional=6）、Fig.4 (a) 三臂柱状图+数值标签 (b) 去噪边界散点、Fig.5 三面板原始单位+噪声地板 | v4 图与题注数值一致（45.4/51.1/9.1，5.0×=45.4/9.1）；脚本 `make_v4_*.py` |
| 9 | 方法节单调、只有一张图 | 新增 Fig.2 可靠性信号流图（§3.4，三行布局：输入/计算/两个消费点，site 入虚线框）；全局重编号：机制地图→Fig.3、消融→Fig.4、受控→Fig.5、三端点→Fig.6 | 编号连续、正文引用（Fig. 3 shows…/Fig. 4 marks…/Fig. 5a/5b/Fig. 6）与图实际内容一一对应；tex 与 md 双侧一致 |
| 10 | 关键词 RGB-D video 是否可去 | 已去；现四个：Dynamic SLAM · 3D Gaussian splatting · Scene reconstruction · Robust estimation | `\keywords` 渲染检查 |
| 11 | 关键词加 Scene reconstruction（匹配 special session） | 已加 | 同上 |
| 12 | NGD-SLAM (no GPU) 标注 | 改 (CPU)，与 DynaSLAM (CPU) 平行 | Table 1 行标签 |
| 13 | 页眉 "RoGS-SLAM: Reliability-Guided Weighting" 怪 | `\titlerunning` 改为标题主句缩短式 | 奇数页页眉渲染 |
| 14 | 表格里方法要不要引用 | caption 加指针 "Method citations: Secs. 2.1–2.3"（正文已引用，列内加 cite 会撑折行） | caption 渲染 |
| 15 | 主文必须自含（不寄希望于 SI） | 已审计：33 处 SI 指针逐个核对，承重数字全部在正文复述 | 抽查任一 SI 指针，确认正文有数字 |
| 16 | SI 内容也要正确、SI 格式要求 | SI 无官方模板（MMM 只管主文 12+2）；S3.3 24 行×5 指标与权威表零漂移；S5/S8/S12 与证据文件一致；SI 标题块升级为完整论文题 | tests/test_cell_provenance_consistency.py 5 断言全绿 |
| 17 | 参考文献引用对吗 | 29 条逐条核验（16 经典 + 11 条 2024–2026 联网核对：WildGS-SLAM CVPR25、RGD-SLAM PR175'26、DG-SLAM NeurIPS24、BDGS-SLAM Sensors 25(21):6641、DAGS-SLAM arXiv:2602.21644、DynaGSLAM arXiv:2503.11979/WACV26、Gassidy/GARAD/Dy3DGS ICRA25、DGS-SLAM arXiv:2411.10722、RoDyn-SLAM RA-L 9(9)、NGD-SLAM IROS25） | 抽查 2–3 条新系统条目 |
| 18 | 3 处 Overfull | `\emergencystretch` 1.5em + 一处措辞微调，清零 | log 无 Overfull（注意 tectonic 需 --keep-logs 才刷新 .log） |
| 19 | 查重前最终检查 | 匿名（Anonymous Author(s)，元数据无作者）、0 断链、标题/关键词/页数核对通过 | 匿名扫描、`?` 断链扫描 |

## ⚠️ 未决硬伤（新会话最高优先级）

**正文 13 页超出 MMM 2026 special session 官方上限 12 页 + 2 页纯引用。**
官方原文（mmm2026.cz/submissionGuidelines）："Special session paper submissions are limited to
12 content pages, including all figures, tables, and appendices… An additional 2 pages containing
only cited references are allowed." 用户此前指示"不压页数"，但投稿前必须回到 12+2，
否则 desk-reject 风险。压缩手段现成：v4 图高收缩（Fig.3/4/5 各降 10–15%）、
此前验证过的删减清单（git 历史 1dd2e926 之前）、Fig.2 可整图移除（约 0.3 页）。

## 关键事实（新会话直接引用，勿重查）

- MMM 格式 = Springer **LNCS 单栏**（官方指南原文确认），A4 10pt，双盲。
- special session "Reconstruction and Generation of Humans, Objects, and Scenes for Spatial
  Intelligence" 无独立 CFP 放宽页数（默认 12+2 适用）；ICRA 的 "MM-SpatialAI" workshop
  （6 页、单盲）是另一个活动，勿混淆。
- 权威数据表 = `results/evidence/18seq_rendering_main_table.md`（build_18seq_main_table.py 生成）；
  S12/S3.3/Table 1 的 cell 以它为准。
- 统计口径：sd 一律 ddof=1；比率 = 权威表 cell 之商；跨 campaign 比较只用 floor 内/外。
- 风格红线：散文破折号 0、分号/冒号密度低、无 "X, not Y" 警句、无修辞小标题、
  加粗仅结构性、术语斜体少量。数字 token 不可变（provenance 测试会抓）。
- 验证命令：`python3 tests/test_cell_provenance_consistency.py`（5 断言）；
  编译 `/data/conda_envs/tex/bin/tectonic`；页边界 `pdftotext` 查结论末句与 References 起始页。
