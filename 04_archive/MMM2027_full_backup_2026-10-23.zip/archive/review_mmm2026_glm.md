# Review — MMM 2026 Submission (GLM)

**Manuscript:** RoGS-SLAM: Robust Dynamic-Scene Gaussian Splatting SLAM via Reliability-Guided Weighting and Coverage Sampling
**Reviewer emphasis:** experimental methodology and technical soundness
**Reviewed artifact:** `latex/main_v3.pdf` (12 pages + 2 pages references, anonymous). Supplementary S1–S12 referenced but not available to this reviewer; all judgments below are from the PDF alone, with confidence lowered where a claim rests on supplement-only evidence.

## Overall recommendation: **Weak Accept**

## Confidence: **3**

Confidence is capped by the supplement's unavailability: the main text cites S1–S12 for several load-bearing details (constant tables, noise-floor definitions, the kernel-ablation design, held-out check rounds, the full 18-sequence table). I evaluate only what is locatable in the PDF and lower confidence where a claim rests on supplement-only evidence, rather than assuming the supplement resolves it.

## Summary

The paper presents a mask-free configuration for dynamic-scene 3D Gaussian splatting SLAM built on MonoGS, deciding which pixels to trust from the disagreement between frozen RAFT optical flow and rigid-scene reprojection flow, and down-weighting rather than removing dynamic pixels. Rather than claiming architectural novelty — the authors state plainly that all components (Huber reweighting, keyframe coverage, reliability gating, a density lifecycle) are classical — the claimed contributions are a set of measurements: a pre-registered 120-run factorial (8 cells × 5 sequences × 3 seeds) showing component necessity is regime-dependent; a flow-budget control in which a naive p90 threshold on the identical frozen flow fails where the proposed weighting succeeds; and a measured variance–bias decomposition arguing pose-side claims must name their endpoint. A pre-registered RPE-based observable is offered as a post-hoc diagnostic for where the mask-free configuration stops being sufficient. On four BONN scenes under one protocol, the combined configuration is the best RGB-D 3DGS result on crowd scenes (2.2–2.3 cm ATE) at roughly half the GPU memory of the strongest reproduced segmentation-based baseline. The paper explicitly claims no state-of-the-art accuracy and reports its own failures (pt1, Replica, the PSNR paradox).

## Strengths

- **Unusually disciplined experimental design for this area.** Fixed 18-sequence denominator with a no-post-hoc-subset rule, pre-registered factorial and comparison floor, held-out validation rounds for the τ = 1.6445 diagnostic, an explicit completion criterion (≥95% frames, "unresolved, not dropped"), and 3 seeds with sd reported throughout (Sec. 4, Sec. 5.2, Table 2, Sec. 5.5).
- **The flow-budget control is the right control.** Giving a naive rule the byte-identical frozen flow and showing it crosses parity on one sequence (0.90× on pt2) while the proposed weighting improves 4/4 (1.63–4.99×, all seeds agreeing, Fig. 4a,b) directly addresses the "it just had more information" confound that most mask-free SLAM papers leave open.
- **Honesty that stays verifiable.** The no-SOTA claim, the mask-dominant regime (34.9/45.9 cm on crowd scenes, Table 1), the Replica degradation, the PSNR paradox where the ghost-carrying backbone wins full-frame PSNR (Sec. 5.7), and the majority-statistic limitation of τ (Sec. 3.4) are all stated by the authors against their own interest, and each is locatable in a table or figure.
- **One-protocol comparison table with arithmetic that checks out.** I verified the Avg. column of Table 1 for all rows; divergences are marked rather than silently omitted, and the memory comparison is explicitly confined to the same-hardware pair (Table 3 caption).
- **The endpoint-naming discipline (Sec. 5.6) is a genuinely transferable point**, and the paper measures the intermediate coherent-error quantity rather than only asserting the variance–bias story.

## Major Concerns

**R1-M1 — The "0 of 5" headline rests on an unstated and apparently inconsistent decision rule.**
Location: Fig. 3 (bottom strip and caption), Sec. 5.2, Abstract, Contribution 1.
The caption says the strip marks "per sequence, whether all three ∆f ≥ 0," yet on mv_no_box all three cell means are positive (+0.25, +0.03, +0.16) and the strip still reads "no." Evidently a non-bold mean (|mean| < 1 sd, i.e., ±0.03±0.19, ±0.16±0.42) is being treated as non-positive, but that rule appears nowhere. By the caption's literal criterion the count should be 1 of 5, which would falsify "no globally necessary subset exists in this design" as stated. Relatedly, "robust reweighting is indistinguishable from zero on 3 of 5" (Contribution 1) is an equivalence claim made without any equivalence test — with 3 seeds and sds of 0.15–0.19 in log-ATE, "consistent with zero" is what the evidence supports. *Why it matters:* this is the paper's first listed contribution and appears in the abstract without the "in this design" hedge that Sec. 5.2 carries. *Resolve:* state the exact rule (e.g., bold cells only, or a minimum effect size in log-ATE), make figure and text consistent, and replace "indistinguishable" with "consistent with zero."

**R1-M2 — The flow-budget control tests exactly one counterpart rule, but the claim is universal.**
Location: Sec. 5.4, Contribution 2, Abstract.
The counterpart is a single p90 hard threshold. The concluding sentence — "'any flow-consuming anti-dynamics treatment' does not reproduce the result" — generalizes from n = 1 rule to the whole class. The hard-mask-vs-soft-weight contrast also changes two things at once (pixel selection rule and removal-vs-attenuation), so the experiment attributes the gain to the bundle {calibration + soft weighting}, not to the weighting form specifically. *Why it matters:* this control underwrites the paper's second headline contribution and the abstract's "closing the 'it just had more information' reading." *Resolve:* add one or two stronger naive uses of the same flow (e.g., a hard threshold on the paper's own e_flow cue at matched coverage, or a soft weight from the raw flow disagreement) on the same 4 sequences; alternatively narrow the claim to "a reasonable single-rule threshold does not reproduce it." The effect sizes are large enough that I expect the result to survive — which is why this is a concern, not a rejection criterion.

**R1-M3 — The crowd regime — the paper's strongest results — is absent from the factorial, and the crowd attribution rests on one sequence.**
Location: Sec. 5.2 (factorial sequences are mv_no_box, mv_no_box2, pt2, balloon, pt1 — no crowd scene), Sec. 5.3 and Table 2 (crowd2 only), Limitation 5.
"No sequence rewards all three — 0 of 5" excludes precisely the regime where the combined configuration leads its class. The crowd-regime claim ("the full arm's advantage on this regime is attributable to the bundle") is carried by a single sequence on which the intervention-arm dispersions (±2.25, ±2.11) exceed most of the effects, and the paper itself labels it descriptive. *Why it matters:* a reader of the abstract encounters "component necessity is regime-dependent" as a general finding; within the paper's own evidence, the crowd regime is the least-measured and most-claimed part of it. *Resolve:* either add one crowd sequence to the factorial (8 cells × 3 seeds = 24 runs) or scope the regime-dependence claim explicitly to the five measured sequences and mark the crowd attribution as a single-sequence observation in the conclusion, not only in Limitation 5.

**R1-M4 — The variance–bias mechanism is measured on one sequence, with two of three endpoints marginally above their noise floors, and the intervention itself is not named in the main text.**
Location: Sec. 5.6, Contribution 3, Abstract.
Only balloon "carries the per-frame annotation this decomposition needs." The per-frame penalty effect is 1.22× its noise floor and the coherent-amplitude effect 1.38× — both marginal; the definition of "noise floor" is in S7 (support not locatable in the PDF). Sec. 5.6 names the direction of the intervention ("widening the share of pixels the tracking weight suppresses") but not the manipulated variable, so the reader cannot tell what was turned. *Why it matters:* Contribution 3 says the mechanism is "confirmed by measuring the intermediate quantity"; with one sequence and two near-floor endpoints, "confirmed" overstates what is a suggestive single-system measurement. *Resolve:* name the knob and the floor computation in the main text, downgrade "confirmed" to "measured, on one sequence, with the ATE endpoint 4.0× its floor," and state plainly that the cross-sequence check is below its noise floor (currently only in "Domain").

**R1-M5 — Quoted ratio bands are not checked against the paper's own baseline-instability filter.**
Location: Sec. 5.1 (0.89–1.17×, 1.92–3.96×), Sec. 5.4 and Fig. 4 (1.63–4.99×, 0.90×), Limitation 4.
Limitation 4 concedes that on 8 of 18 sequences (vanilla CV > 20%) "a ratio depends on which basin the baseline fell into." Yet the ratio bands quoted in the abstract, Sec. 5.1, and Sec. 5.4 are never annotated with whether their constituent sequences fall in the unstable set. For example, vanilla on pt2 is 43.8±8.6 (CV ≈ 20%), and the 0.90× naive ratio on pt2 is a headline number. *Why it matters:* by the paper's own standard, a ratio on a basin-unstable baseline is not a well-defined quantity, and the bands are quoted in the abstract as if they were. *Resolve:* mark each quoted band's sequences as basin-stable or not (one clause per band, or flags in Table 1 / Fig. 4), and move any band that depends on an unstable baseline into the flagged category.

## Minor Comments

**R1-m1** — Sec. 3.3: "six sequences, five regimes, 36 runs" is ambiguous as written — the reader cannot reconstruct 36 from the stated factors (presumably 6 sequences × 2 alternative kernels × 3 seeds, with "five regimes" a categorisation of the six sequences rather than a run multiplier). Required correction: state the design factors explicitly.
**R1-m2** — Sec. 5.3: "12 runs" covers only the two single-component arms; the pair arm (4.55) and insertion-gating arm (5.66) quoted from S2.3 are additional runs not included in the stated count. Required correction: give the total run count for the section.
**R1-m3** — Sec. 5.7 / Table 3: "runs faster than our RGD-SLAM reproduction (0.75 vs 0.67 FPS)" — the sds (±0.09, ±0.16) overlap the 0.08 difference. Required correction: state this as within noise and rest the comparison on the memory gap, which is clear.
**R1-m4** — p. 8, "as §5.5 predicts": Sec. 5.5 is explicitly a post-hoc diagnostic, not a predictor. Required correction: "is consistent with."
**R1-m5** — Abstract: "no globally necessary subset exists" lacks the "in this design" hedge used in Sec. 5.2; and "closing the … reading" overstates a 4-sequence, 1-rule control (see R1-M2). Required correction: align abstract strength with body.
**R1-m6** — Table 1: the GPU memory column mixes same-hardware measurements with author-reported values in one column; the caption warns against cross-reading, but per-cell markers (e.g., †) would prevent it visually. WildGS-SLAM row also has inconsistent bold/spacing formatting.
**R1-m7** — References [9] (DGS-SLAM) and [25] (DAGS-SLAM) have no venue; [12] (DynaGSLAM, WACV 2026) has no pages/DOI. Required correction: complete or annotate as preprints.
**R1-m8** — Related work names no pre-3DGS consistency-based dynamic rejection line (geometric/epipolar-constraint outlier rejection in feature-based dynamic SLAM); the gap is a direction, not a specific missing citation, but Sec. 2.3 reads as if consistency-based decisions begin with recent 3DGS systems.

## Questions to Authors

1. In Fig. 3, mv_no_box shows all three mean ∆ values positive (+0.25, +0.03, +0.16) yet the strip marks "no." What exact rule decides the strip, and does the "0 of 5" claim hold under that rule stated explicitly?
2. Is the p90 threshold the only counterpart rule tested in Sec. 5.4? Were any of the four control sequences among the 8/18 sequences your Limitation 4 flags as basin-unstable (vanilla CV > 20%)?
3. In Sec. 5.6, which variable is manipulated in the single intervention, and how is each "noise floor" (1.22×, 1.38×, 4.0×) computed?
4. How do diverged or <95%-completion runs enter the factorial means — excluded, imputed, or flagged — and did any of the 120 runs fail the completion criterion?
5. For Table 1, which rows are your 3-seed reproductions and which are author-reported numbers (specifically WildGS-SLAM and DynaGSLAM), given that the caption's provenance note covers only the GPU column?

## Scores (MMM review form)

- (a) Relevance to MMM scope: **3/5** — RGB-D video processing and dynamic scene understanding; no cross-media or multimodal aspect.
- (b) Novelty: **3/5** — the system is an honest assembly of classical components; the measurement-first framing (pre-registered factorial, flow-budget control, endpoint discipline) is the actual novelty and is real.
- (c) Technical soundness: **4/5** — careful controls and mostly well-calibrated language; dinged for R1-M1's rule inconsistency and R1-M4/M5 overstatements.
- (d) Presentation quality: **3/5** — honest and precise but very dense, heavily supplement-dependent, with several cryptic phrasings ("the denominator is fixed," "as §5.5 predicts").
- (e) Experimental rigor: **4/5** — pre-registration, held-out rounds, seeds, fixed denominator, and failure reporting are well above venue norm; limited by 3 seeds, one counterpart rule, and the crowd regime's absence from the factorial.

## MMM Fit Assessment

This is a single-media paper: everything operates on RGB-D video, with no audio, text, or cross-modal component. MMM's call welcomes such papers, and dynamic-scene video understanding is adjacent to the conference's multimedia modeling themes, but the paper's natural home is a vision/robotics venue; the fit is acceptable rather than strong, and I would not let fit drive the decision either way. On substance, the measurement discipline and the honest bounding of claims make this an above-average submission for the venue — Weak Accept, contingent on the abstract-level claims being brought into line with the paper's own (good) evidential standards.

---
*Review generated by GLM (reviewer emphasis: experimental methodology and technical soundness), 2026-08-30. Artifact: main_v3.pdf, 14 pages.*
