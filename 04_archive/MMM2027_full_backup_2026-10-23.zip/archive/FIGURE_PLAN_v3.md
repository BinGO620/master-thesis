# FIGURE PLAN v3 — 12 页版图片与表格规划（2026-08-29）

> **✅ 执行状态（2026-08-29 图表阶段收口）**：5 张正文图已按本规格重绘完成
> （`figures/make_v3_fig*.py` → `*_v3.pdf/svg/png`，脚本内置转录 assert：fig3 15 格、
> fig4 12 均值±半距、fig5 18 dev + 5 held-out 点）。图均入 v3 编译链且经逐页目检。
> 微调记录：fig3 色标解码键移入 caption；fig1 的 mask 框改为文字标注挂载点（无交叉箭头）；
> fig4 panel a 改用 WPB-CONFIRM 真实 per-seed 数据（弃用 mean±half-range 合成点）；
> fig2 flow 面板 gamma 增益修复 v2-B7；fig5 补上 v2 遗漏的 pt2 点。
> 页数账：正文 13.61 页 vs 目标 12（缺口与选项见 STATUS.txt）。


> **定位**：v3 的浮动体从"沿用 v2 的 7 图 5 表"改为**按叙事需要重新设计**。
> 每张图写明：承载的主张（F1/F2/F3 或功能）、面板内容、数据来源、以及给视觉
> 模型的设计约束。图表存在只为正文论证服务，不是必须用完 v2 的存量。
>
> **v2 图的历史缺陷**（VISUAL_AUDIT.md，重绘时一律不得回归）：
> 红绿对立配色（B4，色盲不可读）、图内 4–5pt 灰脚注（B5）、`\n` 字面量（B1）、
> 脚注叠印（B2）、刻度断词（B3）、Fig1 三出边与 §3.4 矛盾（A1）、图内标题
> "three components" 与正文矛盾（A2）、未解释图元（B7）、量纲混排标签（B8）。

---

## 一、版面总账

| 浮动体 | 页数 | 说明 |
|---|---:|---|
| Fig 1–5（5 张） | ≈1.3 | 每张 ≤0.28 页（12.2 cm 宽 × ≤6 cm 高，或占宽 1/2 的更矮图） |
| Table 1–3（3 张） | ≈0.75 | Table 1 主表 ~0.5 页，Table 2/3 各 ~0.12 页 |
| **合计** | **≈2.05** | 文字额度 ≈9.9 页 |

**与 v2 的差异**：
- 删 `fig4_main_results`（18 序列柱状图）——Table 1 已承载全部数字，CV 分档用
  † 标记 + 一句散文交代，图是重复的（省 ~0.3 页）
- 删 `fig6_endpoints`（F3 三 endpoint 图）——§5.7 的 3 行小表承载核心数字，
  机制链用散文说；F3 是证据最薄的贡献，不配独立图（省 ~0.25 页）
- 删 Table 4（受控对照表）——数字直接标注在 Fig 4 上，完整表在 SI（省 ~0.15 页）
- 删 Table 5（效率表）——移 SI，正文 3 句散文（省 ~0.2 页）

---

## 二、逐图规格（正文 5 张）

### Fig 1 — 系统管线：四个组件挂在哪里（§3.1）

- **承载**：系统可读性。让"四个组件、四个不同挂载点、reliability 恰好两个消费点"
  一眼可读——这是 §5 消融能被读作"对命名量做介入"的前提。
- **面板**：单面板。上行灰色骨干链：`frame t → pose solve → keyframe gate →
  window BA → map`。下行四个蓝色组件框，各用一条竖线挂到它修改的阶段：
  - **R**（robust reweighting）→ pose solve
  - **K**（uniform coverage）→ keyframe gate
  - **D**（lineage lifecycle）→ map（候选高斯的确认/删除）
  - **L**（reliability signal）画为第四个组件框，**恰好两条出边**：
    ① pose-solve residual（与 R 并排进 pose solve），② D 内的 candidate confirmation。
  - 可选 semantic mask 以右侧虚线小框出现，标注 "optional, Sec. 3.6"，不与 L 相连。
- **数据来源**：无数据，纯示意。拓扑以 `results/evidence/method_attachment_audit.md`
  为准（这就是 A1/A2 勘误的权威源）。
- **设计约束**：骨干灰阶 + 组件单色（蓝）；L 的两条出边是本图最关键的语义，
  视觉权重必须明显高于其他连线；图内不写 "three components"（正文是 four）；
  最小字号 ≥7pt（成品 12.2 cm 宽下）；无图内脚注。

### Fig 2 — Reliability 机制：两个 cue 融合成一个有界降权（§3.4）

- **承载**：把 §3.4 的抽象量（e_flow、vg、s、w）变成可见的东西；同时展示
  "有界降权、从不剔除"与 mask 的硬删除的对比。
- **面板**（单行 4–5 格 + 底部时间轴，或 2×3）：
  (a) 输入 RGB 帧（balloon 序列一帧，人与气球都清晰）；
  (b) flow 分歧 cue `e_flow` 热图（mover 高、背景≈0）；
  (c) 几何 cue `v·g` 热图；
  (d) 融合置信度 `s = (1−e_flow)(1−vg)`；
  (e) 该序列逐帧 mean(s) / mean(w) 时间线，展示 w 有下界（0.10 地板可画横线）。
- **数据来源**：logged per-frame 数据已在 figures/make_fig2_mechanism.py 的输入；
  RGB/flow 对取 balloon 帧 100（v2 同款，已验证）。
- **设计约束**：热图用 viridis（不用红绿）；每个面板左上角标 (a)–(e) 与量名；
  w 时间线的 0.10 地板线必须有图例项；色盲安全；≥7pt。

### Fig 3 — Regime 分层图（F1 主图，全稿中心图）（§5.2）

- **承载**：**F1**。"组件必要性随 regime 分层、无全局必要子集"的符号模式。
  这是论文的 headline figure，§1 的第一个 contribution bullet 直接指它。
- **面板**：单面板矩阵热图，3 行（K/R/L）× 5 列（序列按 tracking 难度排序：
  `mv_no_box, mv_no_box2, pt2, balloon, pt1`）。每格填 Δ 的 mean±sd（3 seed），
  发散色标（**RdBu_r，零=中性白**），格内 verdict 用小符号（+/0/−）。
  底部一行汇总条：每列"三行是否全正"，5 列全部为否，右下角标 **0/5**。
- **数据来源**：15 个 Δ 全部来自 `results/evidence/wpa_factorial_readout.md`
  （与 v2 Fig4 相同数据，重画不重算）；逐格数字转录后必须与该文件核对
  （v2 曾用 15-cell 转录校验，重绘时保留该步骤）。
- **设计约束**：发散色标禁红绿对立（B4 教训）；零线居中；"0/5 全正"这一行结论
  必须在图内可见（它是 F1 的判决）；序列名不断词（B3：`mv_no_box` 需留足宽度
  或手动换行点）；mean±sd 字号 ≥7pt。

### Fig 4 — 受控对照：同一份 flow，三种用法（F2）（§5.5）

- **承载**：**F2**。"增益来自机制不来自信息"——同一份 byte-identical 冻结 flow，
  朴素 p90 阈值 vs 我们的加权，结果分化。
- **面板**：单面板。x 轴 4 条 held-out 序列（pt1, pt2, mv_no_box2, balloon2），
  每序列三个臂（vanilla / naive flow-mask / MRCS）的 ATE，3 seed 个体点 +
  均值横线，log y 轴。**pt2 是判决格**：naive 比 vanilla 更差（51.07 vs 45.37）
  而 MRCS 好 5 倍（9.09）——用注释箭头或底色高亮这一格。
  每臂均值旁直接标数值（替代被删的 Table 4）。
- **数据来源**：`results/runs_remote_cache/WPB/WPB-CONFIRM/` 36 run，
  与 v2 Table 4 同源（已验证）。
- **设计约束**：三臂用三个明度区分的单色系（禁红绿对立）；seed 点可见
  （不能只画均值）；高亮判决格但不夸大（其余三格同权重展示）；
  数值标签字号 ≥6.5pt（图内数字可略小于轴标签，但不得 <6.5pt）。

### Fig 5 — 边界分离：mask-free RPE 预测 mask 必要性（§5.6）

- **承载**：诚实边界贡献的可视化。mask-free 臂自身的逐帧漂移（RPE）把
  "mask 冗余"与"mask 必需"两组分得完全不重叠（0.22–1.57 vs 1.72–2.98）。
- **面板**：单面板散点。x = mask-free RPE (cm/frame)，y = mask necessity N
  （log 轴）。18 点按组着色（两组两个色，色盲安全）；分离带 (1.572, 1.717)
  画竖直浅色带；τ=1.6445 画竖线；被排除的 f3_st_hf 用空心三角单独标；
  **5 个 held-out 检查点用不同 marker（如方形）叠加**，与预注册判决一致。
- **数据来源**：`results/evidence/rpe_stratification_rule_test.md` +
  `rpe_boundary_heldout.md`（18 + 5 点，全部已验证）。
- **设计约束**：y 轴 log；N=1.5 / 1.2 两条水平参考线（redundant/ambiguous/
  necessary 分档带）；"post-hoc diagnostic, not a selector" 交给 caption，
  不在图内写长文（B5 教训）。

---

## 三、表格规划（正文 3 张）

| 表 | 内容 | 状态 | 备注 |
|---|---|---|---|
| **Table 1** | 18 序列 × 4 臂 ATE 主表 | 不动 | 红线：完整保留，含 †/‡ 标记体系 |
| **Table 2** | mask necessity N（6 序列两臂） | 不动 | §5.1 的判据表；低矮，~0.12 页 |
| **Table 3** | 单变量归因（EXP53/54） | 不动 | 红线：完整保留；六臂阶梯延续留在 §5.3 散文一句 |
| ~~Table 4~~ | 受控对照 | **移 SI** | 数字标注在 Fig 4 上；完整表在 S（WPB 已有） |
| ~~Table 5~~ | 效率 | **移 SI** | 正文 3 句散文：combined 0.75fps/4.02GB vs RGD 0.67/7.37；RAFT 54ms 不在 online rate |

§5.7 的三 endpoint 小表（F3）保留为行内表（3 行，非编号浮动体），
与 v2 相同——它太小，不值得编号。

---

## 四、给视觉模型阶段的工作约定

1. **重绘脚本**：新脚本放 `figures/`，命名 `make_v3_fig{1..5}_*.py`，复用
   `_figstyle.py`（改配色后）；v2 的 make_fig*.py 保留不动（v2 可回溯）。
2. **转录校验**：Fig 3 的 15 格、Fig 4 的 12 个均值、Fig 5 的 23 个点，
   重绘后逐一对 `results/evidence/` 源文件核对（脚本内置 assert 或事后 diff）。
3. **验收标准**：130 dpi 全页渲染 + 300 dpi 局部裁剪复核；最小字号 ≥7pt；
   无红绿对立；无 `\n` 字面量；无叠印；无未解释图元；caption 与图内一致。
4. **caption 归属地**：caption 全部在 manuscript_v3.md 的 blockquote 中维护，
   图内不重复（B5 根因）。

---

## 五、v4 补记（2026-08-31，图面常规化重设计）

审稿人反馈：Fig.3/4/5 是"分析工件"风格（发散热图、strip plot、噪声地板归一化
条形图），不读题注无法解码，与 SLAM 论文的图面惯例脱节（对照
`resources/01-references/` 20 篇的图面普查：实验图老三样 = 轨迹对比图、
qualitative 渲染网格、分组消融柱状图/表）。三图已按常规形式重绘：

| 图 | 旧形式 | 新形式 | 脚本 / 输出 |
|---|---|---|---|
| Fig 3 (§5.2) | 3×5 发散热图 + "all three supported?" 条 | 分组消融柱状图：5 序列 × {full, −K, −R, −L}，log ATE，±sd 误差棒；∘ = directional（|Δ|<1sd，冻结支持规则） | `make_v4_fig3_ablation.py` → `fig3_ablation_v4.pdf` |
| Fig 4 (§5.4/5.5) | (a,b) strip plot + (c) 重标注散点 | (a) 4 序列 × 3 臂柱状图 + per-seed 点 + 数值标签；(b) 去噪边界散点（保留 gap 带、τ 线、held-out 黑边圈） | `make_v4_fig4_controlled.py` → `fig4_controlled_v4.pdf` |
| Fig 5 (§5.6) | 噪声地板归一化单轴条形 | 三小面板、各端点原始单位，灰带 = ±1 复跑地板，better/worse 方向轴 | `make_v4_fig5_endpoints.py` → `fig5_endpoints_v4.pdf` |

数据源不变且转录有 assert：Fig 3 用 `archive_pre_exp32/wpa_factorial_readout.md`
的 L2 conditional ATE（绝对值，含 full 格）；Fig 4a 仍读 WPB-CONFIRM 逐 seed CSV；
Fig 4b 与 v3 同 18+5 点；Fig 5 用 pose_trackside/pose_coherent verdict 的
shift+floor 原值。旧 `*_v3.pdf` 保留可回滚。题注与正文引用已同步
（manuscript_v3.md + body_v3.tex + SI S9 "bold cell"→"supported cell"）。
版面：正文 13 页 + 参考文献 2 页（2026-08-31 用户确认不再压缩页数）。
judge 验收：p10/p12 pass；p11 初判 fail 系误读（pt2 ours 柱标签 9.1 cm 与题注
5.0× = 45.4/9.1 比值一致），300 dpi 裁剪复核后确认无问题。
