# VISUAL_AUDIT — v2 PDF 图表视觉审查（2026-08-28，第二步产物）

> 审查对象：`latex/main_v2.pdf` 全部 23 页（130 dpi 全页 + 300 dpi 局部裁剪复核）。
> 产物用途：供第三步（最强模型）论文改写时逐项修复。按严重度分组；每条给出
> 页码/图号、现象、根因（若已知）、修复建议。
> 复核命令：`pdftoppm -png -r 130 latex/main_v2.pdf /tmp/paper_pages/page`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## A. 事实矛盾 / 版本过期（必须先修，属"错"而非"丑"）

**A1. Fig 1 的 reliability 出边数与 §3.4 直接矛盾，且触碰禁词表。**
- 现象（p6，300 dpi 已复核）：`fig1_pipeline.pdf` 中 reliability signal 画了
  **三条绿色出边**，分别指向 R (robust reweighting)、K (dense keyframing)、
  D (lineage lifecycle)；caption 同句写 "The shared reliability signal directly
  feeds robust reweighting, dense keyframing, and the lineage lifecycle"。
- 矛盾：正文 §3.4 明确 reliability 恰好**两个**消费点（tracking residual +
  candidate confirmation）；keyframe-insertion gate 属于 **SemanticMask** 的通道。
  `WRITING_ROADMAP.md` §六禁词表明确禁止写 reliability "feeds the …
  keyframe-insertion gate"；§四-B 对 Fig1 的规格是"四挂载点 + reliability 画
  **两条**出边"。当前图是相对 exp46 规格的回归。
- 修复：改 `figures/make_fig1_pipeline.py`，删除 L→K 边（或改为虚线标注
  "mask-only channel, not reported"——推荐直接删）；同步修 caption 句。

**A2. Fig 1 图内标题 "three components" 与正文 "four components" 冲突。**
- 图内标题："MRCS adds **three** components to MonoGS, all driven by one frozen
  reliability signal"。正文 §3 开篇与 §3.1："adds **four** components"（K/R/L/D），
  第五个为 optional mask。图中 L 被画成驱动器而非组件。
- 修复：图内标题改为与正文一致（如 "MRCS adds four components to MonoGS;
  three attach to the pipeline, one signal feeds two of them" 或等效），并把 L
  画为第四个组件框（自身下挂 pose solve 与 lifecycle 两个消费点箭头，共两条出边）。

**A3. 整个 PDF 落后于 manuscript.md 一个内容版本（exp50 held-out check 未编译进去）。**
- 证据：`latex/body_v2.tex` 时间戳 08-26 23:36 < `manuscript.md` 08-27 04:37；
  `main_v2.pdf`（08-27 04:39）编译的是**旧 body_v2.tex**。
- 后果：PDF p17 §5.5 写 "The separating interval is read off the same 18
  sequences that define it, **with no held-out set**"；p20 Limitation 7 写
  "…is **fitted, not validated**…Pre-registering the interval and testing it on
  unseen sequences is future work."。而 manuscript.md 现版已有 **Held-out check**
  段（τ=1.6445，5 条 held-out，4/4 判决格一致 + 1 带内排除）与对应的 Limitation 7
  更新。PDF 的当前表述与 manuscript.md 的现版**相反**。
- 修复：任何后续改写完成后，必须先
  `python scripts/md2latex_manuscript.py papers/maskfree_bundle/manuscript.md --out papers/maskfree_bundle/latex/body_v2.tex --figdir papers/maskfree_bundle/figures`
  再 `bash latex/compile_v2.sh`；并修 STATUS.txt 中 "00:10 构建" 的过期记录。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## B. 图内渲染缺陷（改 `figures/make_fig*.py` 后重出图）

**B1. Fig 4（`fig3_regime_split`，p14）标题含字面 `\n`。**
- 现象：图标题印为 "…(0/5)\nthe necessary subset is regime-dependent."，
  `\n` 以字面字符出现。Python 字符串转义 bug（单引号串里写了 \n 或用了 raw string）。
- 修复：make_fig 脚本标题字符串；顺便核查其余图脚本的 title/f-string。

**B2. Fig 4 脚注块第一行文字互相叠印（乱码）。**
- 现象（300 dpi 复核）：footnote 首行 "Each cell shows the mean ± sd (3 seeds)
  shift in ATE RMSE (log scale) when a component is moved…" 上叠印了另一行文字。
- 修复：脚注排版 y 坐标/行高冲突；或按 B7 整体删除图内脚注。

**B3. Fig 4 x 轴刻度标签断词："mv_no_box" 折成 "mv_no_bo / x"。**
- 修复：刻度标签留足宽度或禁用自动 wrap（matplotlib 无自动 wrap，此为手动
  `\n` 插入位置错误）。

**B4. 红绿对立配色违反绘图规范（§四-D：发散色标不得红绿对立）。**
- Fig 4（p14）：正=绿、负=红、零=灰。
- Fig 6（p17）panel (b)：mask necessity N=红条 vs mask-free RPE=绿条。
- Fig 7（p19）panel (a)：worse=红条、better=绿条。
- 修复：改色盲安全方案。发散图用蓝↔红（如 RdBu_r，零=浅灰/白）；
  "worse/better" 类二值对比用 蓝=好、橙=坏（或全部同色、用符号/文字标方向）。

**B5. 图内灰字脚注系统性过小、低对比、与 caption 重复（Fig 3/4/5/6/7 全中）。**
- 现象：各图底部 2–4 行浅灰小字，实测约 4–5pt（规范下限 7pt），部分重叠
  （Fig 4、Fig 7 明显乱码）；其内容与 LaTeX caption 高度重复。
- 修复（推荐）：**整体删除图内脚注**，caption 已承载全部信息；不删除的话
  逐图修字号 ≥7pt、对比度 ≥ 60% 黑。

**B6. Fig 3（p12）顶部图例与面板标题挤压。**
- 现象：图例行（o MonoGS / ▪ mask-free / ◆ combined / ▌RGD-SLAM）与 panel (a)
  标题、panel "b Ratio quotable?" 标签同排挤压，视觉碰撞。
- 修复：图例移到图外顶部单独一行或面板内空白区；(b) 面板 "20% cutoff" 虚线
  标注同步放大。

**B7. Fig 2（p8）panel (c) 两条红色竖直虚线无任何解释。**
- 现象：曲线图中 x≈120 与 x≈360 两条红点线，无图例项、caption 也没提。
  若是动态帧标注/分段边界，必须命名；无意义则删除。
- 附：panel (b) backward optical flow 面板几乎全黑，动态主体可见性弱，
  建议 flow 可视化换 colormap（如 viridis/turbo 叠加）或提高增益。

**B8. Fig 6（p17）panel (b) 归一化柱与原始读数标签混排。**
- 现象：y 轴写 normalised，但柱顶标签混用 "35.6 cm / 1.21× / 1.041 / 15.24× /
  2.643"，量纲不一致，易误读。
- 修复：每根柱只用一种口径标签（原值+单位），或在轴标签中写清双口径。

**B9. Fig 5（p16）panel (b) 边缘直方图过小、log-ratio 轴拥挤；图内脚注与图例重复。**
- 修复：panel (b) 最小字号 ≥7pt；删图内脚注（见 B5）。

**B10. Fig 1 小字号疑似 <7pt。**
- 现象：斜体小注 "residual weight / confirm / delete / computed once per frame,
  then frozen" 在 12.2 cm 成品宽度下接近 5–6pt。
- 修复：改图后按成品宽度实测；正文 10pt 的 70%（7pt）为下限。

**B11. Fig 7（p19）panel (b) 机制链文字过小（≈5pt），panel (c) 双柱过小。**
- 修复：合并进 panel (a) 的标注或放大；(c) 的 "noise floor (recompute)" 虚线
  说明至少 7pt。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## C. 表格排版（md2latex 转换层 + 源文件）

**C1. caption 与表体分离。**
- Table 1：caption 在 p12 页底，表体在 p13 页顶（跨页分离）。
- Table 2：表体在 p15 顶，caption 掉到 p15 中部、隔了两段正文（§5.2 scope 段
  + §5.3 + §5.4 开头）之后——读者先看裸表再看 caption。
- 根因：md2latex 把 markdown 表转成非浮动 tabular，caption 是独立段落。
- 修复：转换器为带 "Table N." 引导的段落生成 `\begin{table}[t]` + `\caption`
  绑定；或最低成本——把 caption 段移到表前紧邻位置。

**C2. 四个无编号、无 caption 的裸表。**
- p13 mask-ratio 表（§5.1）、p14 Δ 因子表（§5.2）、p16 RPE 分组表（§5.5）、
  p18 endpoint 表（§5.6）均无编号无标题。LNCS 惯例上正文表格应编号；
  至少 mask-ratio 表和 endpoint 表承载独立主张，值得正式编号。
- 修复：第三步改写时决定编号方案（推荐：这四个中保留 2 个编号表，
  其余降为 inline 列表或并入邻近编号表）。

**C3. p16 RPE 分组表 sequences 列两端对齐导致巨大词间距。**
- 现象：tt 序列名被 force-justify，"f2_xyz, f3_office, f2_person," 行内空隙极大。
- 修复：该列 `\raggedright`。

**C4. Table 2（p15）首列与数据列粘连。**
- 现象："mv_no_box2 15.64±14.14" 几乎连在一起；表头 vanilla/naive flow-mask/MRCS
  三列同样无间隔。
- 修复：加列距或首列右对齐留白。

**C5. §5.6 endpoint 表（p18）shift 与 floor 列视觉粘连。**
- 现象："+0.0806 0.0662"、"−0.0248 0.0180" 两列数字几乎贴住。
- 修复：列间距/小数对齐。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## D. 印刷级文本缺陷（源文件 typo / 转换器）

**D1. `manuscript.md:607` 双逗号 typo：** "the ratio of mask-free to combined
ATE,, with" → PDF 印成 "ATE„"。第三步改写时改为单逗号。

**D2. `manuscript.md` §5.4（≈L589）LaTeX 转义残留：** "i.e.\ 1.25--5.53$\times$"
在 PDF 中印出字面反斜杠（p16 "i.e.\ 1.25–5.53×"）。md 源里应写纯文本
"i.e. 1.25–5.53×"，转换器不识别 LaTeX 转义。**建议全稿 grep `\ ` 与 `--`：
转换器如不处理 LaTeX 转义，源文件里就不该出现。**

**D3. 减号/连字符一致性（轻微）：** 图内负值用连字符 "-0.18"，正文用数学减号 −。
不阻塞，改图时顺带统一为 −（en-dash 或 U+2212 转 PDF 安全写法）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## E. 与 EXP54 整合相关的图表缺口（衔接第一步清单）

- **Fig 4 只覆盖 WP-A 的 5 序列**；EXP54 的臂级归因（P11 / Combined /
  P11+DynKF / P11+Reliability × crowd2 / mv_no_box）需要新表（建议进 §5.2 末，
  footnotesize，2 判定行 + 地板说明）。crowd2 不在 Fig 4 的 5 列中，两者不重复。
- Fig 4 若因 EXP54 叙事调整列序或加注，注意 B1–B4 先修。
- 结论段（Conclusion 第二段 "We are equally clear about the boundary…"）在
  manuscript.md 现版已含 held-out 结果（PDF 未含，见 A3），第三步改写时以
  manuscript.md 为准，不要照抄 PDF。

## F. 审查中确认合格的部分（无需动）

- Table 1 加粗逻辑逐行核对正确（每行最优加粗，含 static 行的 baseline 最优）。
- Fig 2 整体布局与 caption 对应良好（除 B7 两条红虚线）。
- Fig 3 的 log 轴、灰连线、† 高 CV 红标与正文口径一致。
- 22 条参考文献排版正常；页眉 Anonymous / 短标题符合 LNCS。
- 数学编号 (1)–(3) 与正文引用一致。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 修复优先级建议（供第三步排序）

1. A3（重建链：md → body_v2.tex → PDF，否则一切白改）
2. A1/A2（Fig 1 事实矛盾，禁词表级）
3. B1/B2/B3（Fig 4 三处硬伤 + B4 全线红绿配色）
4. C1/C2（caption 绑定与表格编号方案）
5. D1/D2（源文件 typo，改写时顺手）
6. B5–B11（图内脚注删除与字号）
7. E（EXP54 新表进入 §5.2）


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## G. 第二轮目检（2026-08-28，视觉模型复核 25 页重建版）

> 逐页复核 2026-08-28 18:4x 构建的 25 页 PDF。第一轮 A/B/D 项的修复结果 + 本轮新发现。

### G1. 已验证修复（第一轮清单）
- A1/A2 ✓ Fig 1：两条出边（site 1 → pose solve / site 2 → lifecycle）、四组件标题、
  caption 同步；p6 目检通过。
- A3 ✓ 重建链修复：held-out check 内容入 PDF，"with no held-out set" 已消失。
- B1/B2/B3 ✓ Fig 4：标题无字面 \n、脚注不叠印、"mv_no_box (object)" 不断词。
- B4 ✓ Fig 4/6/7 红绿对立全部改为红/蓝（色盲安全）。
- B5 ✓ Fig 3/5/6/7 图内重复脚注已删除（caption 承载）。
- B7 ✓ Fig 2 三条未解释红虚线已删除。
- D1/D2 ✓ "ATE,," 与 "i.e.\\" 已修，p17 目检干净。

### G2. 本轮发现并修复的回归（均为第一轮修复的副作用）
- **G2a. caption 文件名标记回归**：重建时当前版 md2latex 不剥 blockquote 头部
  `**Figure N** (\`figures/...\`).`，全部 caption 印出文件名（exp49 已删过）。
  修复：转换器在提取 asset 后剥前缀（scripts/md2latex_manuscript.py）。
- **G2b. 全部图漂到文末（26 页版）**：G2a 多出的一行使每个贴着 [t] 高度上限的
  浮动体超限，从 Fig 2 起级联 defer。修复：preamble 加 float 参数
  （topfraction 0.95 等）+ G2a 剥前缀。图回到内联（p6/8/13/14/17/19/20）。
- **G2c. Fig 4 被缩小到 40%（自引入）**：修 B2 时脚注去掉 wrap=True 留了单行长文本，
  fig.text 不裁剪 → tight bbox 撑到 850pt → 整图等比缩小。修复：脚注改 4 行显式短句，
  bbox 恢复 371pt。
- **G2d. Fig 7 旧脚注残留**：删脚注后漏跑 make_fig6_endpoints.py。已补跑重建。

### G3. 遗留（不阻塞，与页压缩一并处理）
- C1 caption 与表体分离仍在（Table 1 caption 在表后两段处；Table 2 caption p12 底、
  表体 p13 顶；Table 3 caption p15 底、表体 p16 顶）。Table 4 已同页。
- B6/B8–B11：Fig 3 图例行与面板标题仍偏挤；Fig 7 panel(c) balloon 柱与
  "below floor" 标注轻微重叠；图内小字号（verdict 斜体词、panel c 刻度）仍 <7pt。
- 页数 25（较原 23 增加来自 §5.3/§3.6/Limitations§9 新内容；压缩计划不变）。


## H. EXP54 数据勘误（2026-08-28 晚，会话外复核确认）

- `exp54_component_attribution_verdict.md` 初版 mv_no_box seed1/2 四值无产物来源
  （转录错误；两 AI 独立核对结论一致：console.log 12/12 等于 keyframe_ate 列，
  无覆盖、无口径替换、runner 有 SKIP+EXPECTED_HEAD 硬门）。
- 修正值：DynKF 2.7142/2.7514（mean 2.710±0.044）、Reliability 3.2304/3.4377
  （mean 3.464±0.247）。主判决不变（DynKF 差 0.08 < 地板 0.43；Reliability 差
  0.19 < 地板但 sd 大 5.6×）。
- 连带修正：manuscript.md §5.3/Table 3/证据附录、NEXT_SESSION_PROMPT.md、
  registry.csv 补 EXP54 行、verdict 文件头加勘误注。
- 教训：判决文件的每个数字必须能被 `build_paper_tables.py` 这类脚本从 run 目录
  重新导出——本会话建立的表格工具正是这道闸，Table 3 现由 CSV 直接生成。
