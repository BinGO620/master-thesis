# MMM 2026 Review

Overall recommendation: Weak Reject

Confidence: 4/5

Dimension scores: relevance to MMM 3/5; novelty 2/5; technical soundness 3/5; presentation quality 3/5; experimental rigor 2/5.

## Summary

The revised manuscript presents RoGS-SLAM, a MonoGS-based RGB-D Gaussian-splatting SLAM system that combines keyframe coverage, robust residual weighting, flow/depth reliability weighting, and a Gaussian lineage lifecycle (Secs. 3.1-3.5). The paper positions its contribution primarily as a measurement and attribution study, using a 120-run three-factor factorial, a same-flow control, and a pose-side endpoint analysis (Secs. 1 and 5.2-5.6). The revision improves the earlier presentation by explicitly distinguishing single-component global necessity from strict necessity of the full K/R/L bundle (Sec. 5.2), identifying balloon as the single-sequence basis of the pose decomposition (Sec. 5.6), and stating that the naive flow control differs in more than just its weighting function (Sec. 5.4). The manuscript is also candid about failures, static-scene degradation, external RAFT cost, and the conditional use of a semantic mask (Secs. 5.7 and 6). However, the factorial's key “significant” criterion is an absolute mean effect of at least one standard deviation over only three seeds, which is not a statistical significance test and directly determines the headline necessity conclusion (Fig. 3 / Sec. 5.2). The flow-budget section still calls the naive arm worse at 0.90x even though the reported pt2 values are 51.07 cm for the naive arm versus 45.37 cm for vanilla, so the ratio direction is unresolved (Sec. 5.4 / Table 4 in the supplementary materials referenced by the manuscript). The principal evidence remains partly unauditable from the submitted PDF because S1-S12 are cited for complete protocols, full tables, and validation analyses but are not included in the supplied PDF. I therefore find the revised presentation improved but the central attribution case still insufficiently established.

## Strengths

- The revision now states the two distinct factorial questions explicitly, single-component global necessity and strict necessity of the complete bundle (Sec. 5.2 / Fig. 3).
- The method attachment points and the distinction between mask-free, combined, and simpler configurations are clear (Fig. 1 / Secs. 3.1 and 3.6).
- Protocol details include SE(3) alignment, completion rules, three-seed reporting, hardware, and the exclusion of precomputed RAFT from the online rate (Sec. 4).
- The authors expose important negative results, including mask-free failure on pt1, static-scene degradation on Replica, and the fact that the pose decomposition is based on balloon alone (Secs. 5.6 and 6).
- Table 1 now states that competitor rows are the authors' reproductions under one protocol and limits same-hardware memory comparisons to the explicitly identified pair (Table 1 caption).

## Major Concerns

- **R1-M1, Blocking: No. Location: Sec. 5.2 / Eq. 2 / Fig. 3 / Abstract / Sec. 1.**
  **Concern:** The revision fixes the earlier logical ambiguity by asking whether any component is globally necessary and separately whether the full bundle is strictly necessary. However, the answer to both questions is made conditional on “significant cells,” defined as `|mean| >= 1 sd` with three seeds, while non-bold cells are counted as no support (Sec. 5.2; Fig. 3 caption). One standard deviation of three runs is a descriptive spread, not a test of statistical significance, and no confidence interval, hypothesis test, or prespecified equivalence rule is reported in the PDF. Thus the headline statement that no sequence has all three components “significantly positive” is not supported as a significance claim.
  **Why it matters:** This criterion determines the revised central conclusion that the full bundle is nowhere strictly necessary and also affects the interpretation of L, whose raw effect is positive on all five sequences but only three cells are called directional. The conclusion may be a useful descriptive result, but its current inferential wording overstates what the design establishes.
  **What would resolve it:** Replace “significant” with a clearly descriptive term throughout, or provide a prespecified inferential analysis appropriate to the factorial design. Report the exact estimand, uncertainty calculation, and how the 3-seed limitation affects the conclusion.

- **R1-M2, Blocking: Yes for this review packet. Location: Secs. 2-6, references to S1-S12.**
  **Concern:** The submitted PDF repeatedly sends load-bearing evidence to S1-S12, including the full protocol, resolved constants, complete 18-sequence results, held-out threshold checks, rendering metrics, cross-sequence mechanism checks, and per-run artifacts (Secs. 3.3, 3.4, 4, 5.1, 5.3, 5.5-5.7, and 6). Those materials are not part of the supplied PDF, so their contents and consistency are not assessable here; support not locatable.
  **Why it matters:** The missing material carries the denominator, preregistration details, held-out split, full competitor results, and several checks used to support the paper's generality and reproducibility. This prevents an independent audit of the central case from the submitted manuscript alone.
  **What would resolve it:** Include the referenced supplement in the review package, or move the load-bearing protocol, full tables, and held-out results into the paper and provide precise, internally checkable definitions.

- **R1-M3, Blocking: No. Location: Sec. 5.4 / Fig. 4a,b and caption / supplementary Table 4 referenced by the manuscript.**
  **Concern:** The text says the naive counterpart is worse than vanilla on pt2 at “0.90x.” The supplementary table referenced by the paper gives pt2 as 51.07 cm for the naive flow-mask and 45.37 cm for vanilla, which is worse in the usual naive/vanilla direction and corresponds to a ratio above 1. The figure caption labels the plotted quantity “naive ÷ vanilla,” while the 0.90x annotation implies the inverse ratio. The revision explains that the control differs in multiple ways, but it does not reconcile this numerical direction.
  **Why it matters:** This is the headline quantitative evidence for the claim that the gain is not attributable to flow information alone. A ratio-direction error changes the stated result and undermines confidence in the control comparison.
  **What would resolve it:** State one ratio convention, show the raw means in the main text or figure, and make the text, annotation, axis, and caption use the same numerator and denominator.

- **R1-M4, Blocking: No. Location: Sec. 5.6 / Abstract / Sec. 7.**
  **Concern:** The revision appropriately says that the endpoint decomposition rests on one sequence and that the cross-sequence check is below its noise floor. Nevertheless, it still calls the result a variance-bias trade and says the consequence generalizes beyond this system. The zero-mean decomposition and the coherent-error measurement are not defined sufficiently for independent reconstruction in the PDF, and only balloon carries the required per-frame annotation (Sec. 5.6).
  **Why it matters:** The balloon result can support a bounded case study, but the general lesson is stronger than the visible evidence. This is especially important because the paper presents the endpoint discipline as one of its three principal contributions.
  **What would resolve it:** Either restrict the claim to a descriptive balloon case study, or provide the measurement definition, uncertainty analysis, and cross-sequence evidence needed for a mechanism-level conclusion.

## Minor Comments

- **R1-m1, location: Sec. 5.7 / Table 3.** “Statistically indistinguishable” is inferred from means lying within one standard deviation, without a statistical test. **Required correction:** Use descriptive wording such as “overlapping one-standard-deviation spreads,” or provide an inferential comparison.
- **R1-m2, location: Sec. 5.7 / Table 3.** The claim that the memory gap is the lifecycle rather than map size is not established by the displayed Gaussian counts and memory means. **Required correction:** Remove the causal attribution or provide a controlled memory breakdown.
- **R1-m3, location: Abstract / Sec. 1 / Table 1.** The 39.3 cm mixed-mover value and the roughly 1.5 cm static value remain outside the main numerical displays and are supported only by the cited S12 table. **Required correction:** Add a visible pointer or identify these explicitly as supplement-only values.
- **R1-m4, location: Abstract / Sec. 5.1 / Table 1.** “Strongest such system” is now followed by “RGD-SLAM,” but the selection criterion is still implicit. RGD-SLAM is best among the RGB-D 3DGS rows on the two crowd columns, while DG-SLAM has a lower four-scene average (Table 1). **Required correction:** State whether “strongest” means crowd-scene performance, four-scene average, or another criterion.
- **R1-m5, location: Sec. 5.2 / Fig. 3.** The phrase “consistent with zero within the seed spread” is better than the previous “indistinguishable from zero,” but the manuscript should state whether this is a descriptive comparison or an equivalence claim. **Required correction:** Keep the descriptive interpretation explicit wherever the three-seed effects are summarized.

## Questions to Authors

1. What is the exact statistical or descriptive status of the `|mean| >= 1 sd` rule, and why is it called “significant” in Sec. 5.2 and Fig. 3?
2. For pt2 in the flow-budget control, is 0.90x defined as vanilla/naive or naive/vanilla? Please reconcile it with the reported 45.37 cm and 51.07 cm means.
3. Is the complete S1-S12 supplement part of the actual submission package, and which item contains the full held-out sequence identities and per-seed results?
4. How is the coherent error component in Sec. 5.6 computed from the per-frame annotations, and what uncertainty estimate is used?
5. What is the end-to-end throughput when the 54 ms RAFT cost is included, and is flow inference overlapped with SLAM execution?

## MMM Fit Assessment

The paper addresses RGB-D video, optical flow, dynamic-scene reconstruction, and visual localization, so it is relevant to MMM's multimedia scope despite being primarily a single-media SLAM study (Secs. 3-5). The fit is moderate rather than strongly multimedia-oriented, but the visual video modeling problem is within scope.
