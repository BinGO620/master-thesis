## Summary

This third-round review was conducted as a reproducibility audit. I extracted both PDFs with `pdftotext -layout`, inspected the cited evidence files, recomputed the reported ratios with Python, and checked the implementation paths named in SI S2. The paper is unusually candid about scope, seed dispersion, post-hoc diagnosis, and the flow-cost exclusion. However, the numerical provenance is not yet publication-safe. At least one important chain has a direct standard-deviation mismatch between the main/SI table and the cited primary verdict, and several headline statements rely on campaign-specific denominators that are not the same as the full-table denominators. I therefore recommend **Major Revision**.

## Verification Matrix

The following checks use `/tmp/mmm_main_v3.txt` and `/tmp/mmm_si_v3.txt` (created with `pdftotext -layout`). “Evidence” is the file named in the manuscript or the closest primary verdict in `results/evidence/`.

| Main-paper number | SI correspondence | Evidence correspondence | Result |
|---|---|---|---|
| 2.3 cm crowd combined | S12 2.29±0.05 | 18seq table 2.29±0.05 | ✓ |
| 2.2 cm crowd2 combined | S12 2.19±0.09 | 18seq table 2.19±0.09 | ✓ |
| 2.7 cm mv_no_box mask-free | S12 3.09±0.46 (rounded 3.1) | p6 maskoff 3.09±0.37 | ✗ sd mismatch |
| 10.4 cm pt2 combined | S12 10.44±0.84 | 18seq table 10.45±0.84 | ✗ 0.01 cm |
| 4.4 cm combined average | Table 1 four values | arithmetic mean of 2.29,2.19,2.66,10.44 = 4.395 | ✓ |
| 23.3 cm mask-free average | Table 1 four values | arithmetic mean = 23.295 | ✓ |
| 7.4 GB RGD memory | Table 1 7.4±1.1 | efficiency tables 7.37±1.06 | ✓ rounding |
| 0.75±0.09 FPS combined | SI S5.1 | efficiency_stability_tables, global summary | ✓ |
| 0.77±0.21 FPS mask-free | SI S5.1 | efficiency_stability_tables, global summary | ✓ |
| 4.02±1.01 GB combined | SI S5.1 | efficiency_stability_tables, global summary | ✓ |
| 3.43±0.99 GB mask-free | SI S5.1 | efficiency_stability_tables, global summary | ✓ |
| 54 ms/frame RAFT | SI S5 | SI protocol statement only | cannot locate raw timing file |
| 18.6 fps RAFT bound | SI S5 | 1000/54 = 18.5185 fps | ✓ rounded |
| 0.89× pt2 mask-free/combined | S12 9.30/10.45 | headline_ratio_recompute 0.89 | ✓ |
| 1.17× mv_no_box mask-free/combined | S12 3.10/2.65 | headline_ratio_recompute 1.17 | ✓ |
| 1.09× mv_no_box2 mask-free/combined | S12 5.62/5.14 | headline_ratio_recompute 1.09 | ✓ |
| 1.92× balloon2 mask-free/combined | S12 10.14/5.27 | headline_ratio_recompute 1.92 | ✓ |
| 2.73× pt1 mask-free/combined | S12 32.41/11.89 | headline_ratio_recompute 2.73 | ✓ |
| 3.96× balloon mask-free/combined | S12 12.11/3.06 | p6 verdict says 4.0×, headline file 3.96 | ✓ rounded |
| 1.13× naive flow-mask/vanilla on pt2 | Main 51.07/45.37 | archive_pre_exp32/wpb_flowmask_verdict, same values | ✓ |
| 1.63–4.99× ours/vanilla | Main Fig.4 text | WPB verdict 1.63, 4.99 endpoints | ✓ campaign-specific |
| 5/5 positive ΔL | Fig.3 and Sec.5.2 | WP-A factorial table | ✓ descriptive |
| 0/5 sequences all three supported | Fig.3 | WP-A factorial table | ✓ |
| 2.7–4.5× keyframe increase | Sec.3.2, SI S4 | efficiency_stability_tables Table C 2.70–4.46 | ✓ |
| 0.198–0.204 KF/frame | Sec.3.2 | Table C | ✓ |
| +0.0806 tracking endpoint shift | Sec.5.6, Fig.5 | pose_trackside_paired_gate | ✓ |
| 1.22× tracking floor | Sec.5.6 | 0.0806/0.0662 = 1.2175 | ✓ rounded |
| −0.0248 coherent amplitude | Sec.5.6, SI S7 | pose_coherent_verdict | ✓ |
| 1.38× coherent floor | Sec.5.6 | 0.0248/0.0180 = 1.3778 | ✓ rounded |
| −1.42 cm ATE, 4.0× floor | Sec.5.6 | pose_coherent_verdict | ✓ rounded |
| N range 0.222–1.572 vs 1.717–2.980 | Sec.5.5 | rpe_stratification_rule_test | ✓ |
| 12.6-fold N contrast | Sec.5.5 | 15.24/1.21 = 12.595 | ✓ rounded |
| 5+6=11 and 8/10 agree | Sec.5.5, SI S8 | rpe_boundary_heldout: 4/5 plus 4/6 | ✓ |
| static degradation 3.82±4.58 vs 0.368±0.012 | Sec.6, SI S5/S9 | exp44_replica_seed_verdict and SI S9 | ✓ |

## Strengths

1. The manuscript pre-registers many decision rules and reports negative or indeterminate outcomes rather than selectively hiding them.
2. The full 18-sequence table, seed-level dispersion flags, duplicate-run rule, and explicit post-hoc-selector limitation materially improve auditability.
3. The flow-information control is well motivated and uses the same frozen backward flow for the naive and proposed arms.
4. The endpoint separation in Sec.5.6 is carefully caveated and the code paths are sufficiently specific to permit inspection.

## Major Concerns

### C1. The numerical chain is internally inconsistent for the headline mask-off result. Blocking Yes.

The main/SI chain reports balloon mask-free as `12.11±2.33` cm (main Table 1/S12 and `18seq_rendering_main_table.md`). The primary cited mask-off verdict `results/evidence/p6_maskoff_3seed_verdict.md` reports the same seeds as `12.11±1.90`, while `headline_ratio_recompute.md` uses `12.11±1.90` for its ratio table and S12 uses `±2.33`. These are not rounding variants. I ran `statistics.stdev` on the seed values printed in the verdict, `[13.66, 9.43, 13.24]`, obtaining 2.33 (ddof=1), not 1.90. Thus the verdict's own parenthetical seeds support S12, not the verdict header. The manuscript must identify one authoritative run set, regenerate every downstream table and ratio from it, and add an automated equality test over seed lists, means, and SDs. Until this is resolved, the audit cannot establish which uncertainty statement is true.

### C2. Campaign denominators are mixed in the flow-control claim. Blocking No.

Sec.5.4 says 1.63–4.99× and “ours improves on all four.” `results/evidence/archive_pre_exp32/wpb_flowmask_verdict.md` indeed gives 1.63–4.99×, but its vanilla/MRCS values are a separate WP-B campaign (for example pt1 63.22/38.51), whereas S12/full-table values are pt1 44.83/32.41. The paper does state that the control is a separate campaign, but the abstract and contribution wording do not label the denominator as WP-B-specific. Reproduce the distinction in every headline occurrence, provide run IDs in SI, and do not let readers infer that 1.63–4.99× is computed from Table 1.

### C3. Component necessity is descriptive but the prose still invites causal interpretation. Blocking No.

The paper correctly defines support as `|mean| ≥ 1 sd`, yet each cell has only three seeds and the “5/5 positive” statement includes three directional cells. `results/evidence/exp54_component_attribution_verdict.md` further shows that on crowd2 neither DynKF nor Reliability alone reaches Combined (5.157 and 5.995 versus 2.109 cm), while on mv_no_box DynKF does. This supports regime dependence, not a general component-neccessity law. Please make “positive,” “supported,” and “directional” mechanically distinct in the abstract and contribution list, and include the EXP54 single-variable evidence or explicitly bound the claim to WP-A.

## Minor Issues

M1. Table 1/S12 differ by 0.01 cm for pt2 combined (10.4/10.44 versus 10.45 in the rendering table). State whether this is full precision, campaign selection, or a transcription error.

M2. SI S2 names `utils/slam_utils.py`, `utils/deferred_commit.py`, and `utils/slam_frontend.py`, which exist and contain the claimed robust-weight, lifecycle, and warm-up logic. However, the table also says “resolved DynamicKeyframe” without a file and the inert `occ_tighten_thresh=2.0` path is explicitly unreachable in code. Mark this as an implementation fact, not an active algorithmic constant.

M3. The 54 ms RAFT timing is not linked to a raw timing artifact. Add the script or CSV and report the aggregation (mean, median, or bound construction).

M4. The paper says 12+2 pages by construction. `pdfinfo` confirms 14 main pages and 9 SI pages, not a 12+2 combined manuscript interpretation. Clarify the venue page rule and whether SI pages are exempt.

M5. PDF metadata is anonymous (`Creator: tectonic`, no author or institution fields), and text search found only “Anonymous Author(s)” and “Anonymous Institution(s)”. This passes the supplied anonymity check, but references and code-path names should be checked once camera-ready identities are inserted.

M6. The statement “full-frame PSNR ranking the ghost-carrying backbone above both arms” is supported by the SI rendering table, but PSNR is explicitly declared non-trajectory evidence. Repeat that qualifier in the Results sentence, not only in SI S5.

## Questions to Authors

1. Which exact seed triplet is authoritative for balloon mask-free, and why does `p6_maskoff_3seed_verdict.md` print `±1.90` beside seeds whose ddof=1 SD is 2.33?
2. Are all 1.63–4.99× values intentionally from WP-B rather than the 18-sequence campaign? Please provide a compact run-ID and denominator table.
3. Will you add a machine-checkable provenance test that fails when a manuscript table, SI table, verdict, and raw CSV disagree?
4. For the 120-run factorial, can you report confidence intervals or retain the explicitly descriptive language everywhere the abstract currently says “strongly positive” or “largest effect”?
5. Please clarify the page-count rule applied by MMM 2026 to the 14-page main PDF plus 9-page SI.

## Overall Recommendation

**Major Revision (六档标准: Reject, Weak Reject, Major Revision, Minor Revision, Weak Accept, Accept).** The method and audit culture are promising, and most independently recomputed arithmetic is correct, but the unresolved SD/provenance break affects a headline result and must be corrected before acceptance.

**Confidence: 5/5.** The recommendation is based on direct PDF extraction, source-file inspection, code-path checks, and explicit arithmetic recomputation, without consulting any existing `review_*.md` file.
