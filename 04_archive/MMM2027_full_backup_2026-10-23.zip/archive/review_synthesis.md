# 三盲审交叉综合（冻结后综合，非审稿人可见）

> 2026-08-30。三份独立报告：`review_mmm2026_glm.md`（技术严谨侧重，Weak Accept/3）、
> `review_codex.md`（综合，Weak Reject/4）、`review_mmm2026_claude.md`（新颖性+MMM
> 适配侧重，Weak Reject/3）。三者生成于相互隔离的上下文，符合 nature-reviewer 盲审
> 规程；本文件在全部报告冻结后单独撰写。每个共识项标注独立来源数。

## 一、总判决带

Weak Accept / Weak Reject / Weak Reject → **Borderline，拒稿侧**。
但拆开看：codex 与 claude 的 Weak Reject 主要由两个**可零成本修复的逻辑/呈现问题**
（共识阻塞项 C1、C2）驱动；三人对"测量纪律、诚实负结果、flow-budget 对照设计"
的评价高度正面（glm 给 rigor 4/5，claude 给 4/5）。**C1+C2 修掉后，三人各自报告里
的理由都会动摇**——这是本轮综合最重要的结论。

## 二、共识阻塞项（≥2 份独立提出，必须先修）

### C1 — "0 of 5 / no globally necessary subset" 量词自相矛盾（3/3 提出，真雷）

GLM R1-M1、codex R1-M1(Blocking)、claude R1-M1(Blocking) 三方**独立**抓住同一问题：
- 正文定义的问题是 `∃f: Δ_f(s) ≥ 0 ∀s`（存在全局必要组件）；
- 证据回答的是 `¬∃s: ∀f Δ_f(s) ≥ 0`（没有序列三者全正）——**换序量词，答非所问**；
- 且按正文自己的定义，**Δ_L 5/5 全正 ⇒ L 就是全局必要组件**——数据支持与 headline 相反；
- Fig 3 底条 mv_no_box 列三格均值全正（+0.25/+0.03/+0.16）却标 "no"，caption 说的
  判据（"whether all three Δf ≥ 0"）与图不符；实际起作用的是未声明的加粗规则
  （|mean|≥1sd 才算数）。

**修法（三方一致，零 GPU 成本）**：
1. §5.2 把命题改为实际测的那个：**"no sequence rewards the full bundle ⇒ 不存在
   所有场景都该全开的三组件配置"**，或直接正面陈述 "L is never negative on 5/5
   sequences — the only component with that property"，把 L 的 5/5 作为发现而不是
   矛盾藏起来；
2. Fig 3 caption 声明底条真实判据（非加粗=仅方向性，视作不成立）；
3. Abstract "no globally necessary subset exists" 必须带 "in this design" + 换成
   与证据同构的表述；
4. "indistinguishable from zero"（GLM m/claude R1-m7 均提）→ "consistent with zero
   within the seed spread"（3 seeds 无等价性检验）。

### C2 — headline 数字来自 combined（带 mask），而论文立论是 mask-free（2/3 提出）

codex R1-M2、claude R1-M2（GLM 未提但 R1-M3 相邻）。摘要的 2.2–2.3 cm + "4.0 GB
against 7.4" 都来自 combined 臂——恰是论文批评的 detect-then-exclude 家族（Mask
R-CNN）。且 Table 1 里 DynaSLAM (4.0) / NGD-SLAM (3.2) 四场景均值都优于 combined
(4.4)；"strongest segmentation-based system" 指 RGD-SLAM 但其 Avg 7.6 反而是三个
分割系统里最差的——superlative 无判据。

**修法**：
1. 摘要里明确这组数字是 combined 配置（"our combined (masked) configuration"）；
2. "strongest" → 点名 RGD-SLAM + 判据（"the strongest RGB-D 3DGS segmentation-based
   system we reproduce under this protocol"）；
3. §5.1 或 Limitations 正面回答 claude 的问题：crowd regime 下为什么选本系统而不是
   DynaSLAM/NGD-SLAM——答案在 Table 3：**GPU 显存 4.0 GB vs DynaSLAM CPU-only、
   NGD-SLAM no-GPU 不是同类部署；且我们给的是 3DGS 地图重建能力**（Fig 2 的静态
   重建），这是 ORB-SLAM 系不可给的。这句论证现在完全缺失，补上即闭环。

### C3 — S1–S12 补充材料不在审稿包里，承重证据不可审（3/3 提出）

GLM 置信度因此封顶 3，codex 标 Blocking，claude 置信度封顶 3。这是**提交操作问题**
而非论文问题：supplementary.md 存在（41KB）但未入编译链（STATUS 未闭合项 1）。
**修法**：投稿时把 supplementary 编成单独 PDF 与正文同包提交；同时把正文里 4 处
承重引用（S12 全表、S7 噪声地板、S8 第二轮、S3 N 全表）的关键行搬进正文或脚注。

## 三、共识非阻塞 Major（多数提出）

### C4 — §5.6 "confirmed" 措辞超出单序列证据（3/3 提出）

GLM R1-M4、codex R1-M4、claude R1-M6 全部独立指出：balloon 单序列、两条腿 1.22×/
1.38× 贴地板、"confirmed" 过强。三方一致修法：降级为 "consistent with /
measured on one sequence"；干预变量（哪个 knob）和噪声地板定义在正文点名；把
"generalises beyond this system" 收回到 ATE/RPE 符号翻转这条硬腿上。**零成本。**

### C5 — §5.4 单一对照规则，generalisation 越界（2/3 提出）

GLM R1-M2、claude R1-M4（codex 未提）。"'any flow-consuming anti-dynamics
treatment' does not reproduce the result" 从 n=1 规则泛化到全类；且 hard-mask
对照同时改了两件事（选像素规则 + 剔除 vs 降权）。修法：要么收窄措辞（"a
reasonable single-threshold treatment does not reproduce it"），要么补一条非稻草
臂（同 MAD 归一化的 hard mask，隔离 soft-vs-hard）。**收窄是零成本首选。**

### C6 — crowd regime 缺席析因设计（2/3 提出，但方向相反）

GLM R1-M3 建议补 crowd 进析因（24 runs）；codex R1-M2 关注 D 组件缺席析因。
两者都是"声明范围"问题的变体：析因只测了 K/R/L（D 钉死），且五序列无 crowd。
**裁决**：不补跑（按 monogs-pragmatic-closure-style：主信号成立即收口）；改范围
声明——摘要/结论明确 "necessity is regime-dependent **across the five measured
sequences**"，crowd 归因明确单序列 descriptive；§3.1 已声明四组件、§5.2 已写
"D pinned identically"，把这两处的 scope 语句在摘要层面呼应一次即可。

### C7 — Mask R-CNN 在线性披露缺失（1/3 提出，但事实核查支持审稿人）

Claude R1-M3 问 mask 推理是否在 reported FPS/显存内。**代码核查结论：
`semantic_mask.py:88-141` 在线推理**（torchvision 模型进程内加载、逐关键帧计算、
Camera 缓存）。所以 combined 的 0.75 FPS/4.02 GB **已含** mask 开销——对比是公平
的，但论文没写。修法：Table 3 caption 或 §5.7 加一句 "the combined arm's
inference-time Mask R-CNN (per-keyframe, cached) is included in its online rate and
memory; only RAFT flow is precomputed"。顺带修 GLM m3 / claude M3 的 FPS 重叠问题
（0.75±0.09 vs 0.67±0.16 同 1sd 内）→ "statistically indistinguishable FPS;
the memory gap is the reliable difference"。

## 四、Minor 精选（高频共识 + 快修）

| 项 | 来源 | 修法 | 成本 |
|---|---|---|---|
| 39.3/1.5cm 出处不可寻 | codex m1, claude m1 | Intro 点名 balloon + 指向 S12 | 零 |
| Replica 无引用、在分母外 | claude m2 | 补 Replica 引用 + "outside the pre-registered denominator" 半句 | 零 |
| Limit 2 的 TUM 数字不在正文 | claude m3 | Limitations 补一句 S12 摘要行 | 零 |
| Limit 5 标题与 §5.3 结论不符 | claude m4 | "requires the bundle" | 零 |
| "band" 两义（RPE 带vs N 带） | codex m4, claude m5 | N 带改称 "ambiguity interval" | 零 |
| 5+6=11 vs 8/10 分母 | claude m6 | 写明 "10 decidable (1 in-band), 8 consistent, both misses conservative"；第二轮 6 序列在 18 分母外（exp59 红线 ✓） | 零 |
| Table 1 复现vs引用未标 | codex Q5, claude m10, glm Q5 | caption 加 "rows we reproduce: …; others as reported" | 零 |
| crowd2 2.2±0.0 vs 2.2±0.1 加粗平局 | claude m9 | 加一位小数 | 零 |
| Avg 与 GPU 表头粘连 | codex m3 | 列间距 | 零 |
| Fig 2 底排与照片重叠 | claude m7 | 重排（经查 Fig 3 用 panel_label，Fig 2 需检查 gridspec） | 半小时 |
| Fig 4b 注释压数据 | claude m8 | 已在 R10 修（parity 左移）——**可回复已修** | 已完成 |
| 引文 [9][25] 无 venue/DOI | glm m7, claude m14 | 补全或标 preprint | 零 |
| "§5.5 predicts" | glm m4 | → "consistent with §5.5's diagnostic" | 零 |
| m5 摘要 hedge | glm m5 | 随 C1 一并修 | 零 |

## 五、分歧点（真实分歧，保留）

1. **MMM 适配**：GLM 3/5（可接受）、codex 3/5（中等）、claude 2/5（牵强）。
   claude 的批评最实质：论文通篇无 multimedia 论证，且唯一 multimedia 天然相关
   的轴（渲染质量）反而是 PSNR 输给 backbone 的负结果。**行动**：intro/§5.7 补
   2-3 句 multimedia 定位（3DGS 作为媒体表示、mask-free 地图的 content-creation/
   AR 用途）；若 venue 可再议，考虑 3DV/ICRA 系（这是策略问题，留给作者）。
2. **novelty**：GLM 3/5（measurement framing 是真新颖）、codex 2/5、claude 3/5。
   codex 的 2/5 主要被 C1 拖累（"principal factorial conclusion is logically
   inconsistent"）——修掉 C1 后 novelty 读法会回升。
3. **析因该不该补 crowd**：GLM 建议补，本综合按 closure 风格裁决不补、改声明。

## 六、整改优先级（建议执行序）

| # | 项 | 类型 | 规模 |
|---|---|---|---|
| 1 | C1 量词矛盾全套（正文+图 caption+摘要） | 必修 | 1-2 小时 |
| 2 | C2 摘要 combined 披露 + superlative 判据 + 为什么选本系统句 | 必修 | 1 小时 |
| 3 | C3 supplementary 入编译链同包提交 | 必修（提交操作） | 半天 |
| 4 | C4 "confirmed"降级 + 命名干预变量 | 必修 | 半小时 |
| 5 | C7 Mask R-CNN 在线性披露 + FPS 措辞 | 必修 | 半小时 |
| 6 | C5/C6 措辞收窄（§5.4 泛化、scope 声明） | 应修 | 半小时 |
| 7 | Minor 表全部零成本项 | 应修 | 2 小时 |
| 8 | Fig 2 重叠重排 | 应修 | 半小时 |
| 9 | multimedia 定位句（策略性） | 可选 | 半小时 |

总工时 ≈ 1.5-2 天，全部零 GPU。修完后建议重跑一轮三盲审看判决是否翻正。

## 七、对审稿人报告本身的 QA（简记）

- 三报告无互相污染迹象：C1 的三方措辞与切入（GLM 从 caption 规则、codex 从逻辑
  命题、claude 从量词结构）各不相同，符合独立发现特征。
- claude 自报两个候选 concern 经自查后**主动撤回**（4a 的 2/4 读数、band 矛盾），
  显示其证据纪律良好，报告可信度高。
- codex R1-M2 的 "D 组件缺席析因" 是三方中唯一提出的真视角，已并入 C6 处理。
- glm 报告算术核对过 Table 1 Avg 列（通过），其技术审读最细。
