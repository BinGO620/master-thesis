# TERMS v3 — 术语裁定与 §6 裁定（2026-08-29，措辞阶段锁定）

> 全稿统一执行；与 v2 措辞冲突处以本文件为准。

## 一、术语裁定

### 1. 系统级称谓：`mask-free core`（不再用 "mask-free kernel"）

v2 同时把系统组合叫 "kernel"、把 Huber/Cauchy/GM 叫 "kernel"，§3.3 的 kernel
ablation 与 "our kernel" 撞名。v3 裁定：
- 系统组合 = **the mask-free core**（首用于 §1 定义，之后 core 单独可用）
- Huber/Cauchy/Geman–McClure 一族 = **M-estimation kernels**（§3.3 上下文可简称 kernels）
- 代码标识符（`DynamicKeyframe`/`RobustTracking`/`ReliabilitySignal`/
  `Mapping.lifecycle_mode`）只出现在 S2 配置表，正文一律不用

### 2. 四组件名（功能名 + 字母代号，全稿唯一形式）

| 代号 | 正文唯一名称 | 禁用的变体 |
|---|---|---|
| K | **uniform keyframe coverage (K)** | dense keyframing / DynamicKeyframe / temporal sampling |
| R | **robust reweighting (R)** | RobustTracking / huberisation |
| L | **the reliability signal (L)** | reliability weighting（信号名，不是动作名）|
| D | **the lineage lifecycle (D)** | insert-then-remove / density control |

### 3. regime

首用于 §1 定义：*the sequence's regime — the kind of dynamic content it contains
(object-only, person, crowd, mixed-mover) together with its tracking difficulty*。
全稿只用 regime，不用 scenario / scene type / difficulty level 单独替代。

### 4. 配置名：mask-free / combined / simpler

三配置平级、正体、不加引号；每次引用数字必须点名配置，不允许裸用 "our method"
指代某一臂。simpler 仅在 §3.6/§5.3 出现（EXP53/54 归因基线）。

### 5. 两个 "floor" 必须全称区分

- **pre-registered comparison floor**（EXP53/54/56/57 归因战役的地板：
  max(0.43, 6%×较大臂均值)）
- **re-run noise floor**（§5.7 方差-偏置分析：同配置同 seed 重跑的漂移）
首次出现必须带全称与定义，后文同节内可简称 the floor。

### 6. mask necessity N

§5.1 一次性定义：**N = ATE(mask-free) / ATE(combined)**；分档 N≥1.5 necessary /
N≤1.2 redundant / 其间 ambiguous。此后 N 不再重新定义。

### 7. 倍数引用规则（沿用 v2，措辞统一）

- baseline CV ≤ 20% 的序列才可引用单倍数；否则只报 mean±sd
- headline 带宽固定写法：mask-free **2.2–4.7×**、combined **4.2–17.1×**
- "quotable / not well-defined" 保留 v2 用法

## 二、§6 Limitations 裁定（v3 结构：5 条完整 + 1 个紧凑范围段）

**完整保留 5 条**（每条 2–4 句）：
1. **pt1 边界反例**——mask-free 在一个人序列上彻底失败（32.41→11.89），
   "mask 在 person 序列冗余"为假
2. **不 claim SOTA**——TUM walking/person 落后最佳 1.4–2.5×，全表呈现
3. **Replica 静态退化**——combined 在全静态场景更差且双稳态，只推荐已确认含
   动态内容的序列
4. **baseline 方差 + RAFT 成本**——8/18 序列 CV>20% 禁单倍数；RAFT 54ms/帧对
   不在 online rate，是 operating condition
5. **插入门必要性 / 无子集够用**（红线 item 9）——object-only 上 coverage 单独
   即可恢复，crowd 上无任何子集接近 full；归因仅 2 序列 descriptive

**紧凑范围段**（每项一句 + S11 指针，共 4–5 句）：
- framework generality 未测（单一 MonoGS fork，不写 framework-general）
- Δ_L 是两消费点的联合效应（未分离、不分摊）
- §5.6 边界诊断不是 selector（带位置未检验，需先跑 mask-free 臂）
- 无 cue selector（序列级语义面积实测不可分）

**移出正文、只留指针**：TRC median 负结果、渲染指标 caveat 细节（正文 §5.8 已
有 3 句）、地图侧解读边界——均在 S11。

## 三、v3 措辞风格约束（全稿扫一遍时的判据）

- em-dash 降频：v2 密度过高（AI 指纹）；一句至多一处，一段至多两处
- 禁 "not X, but Y" 对仗连发；一节内不超过一次
- 禁空词：crucially / comprehensively / leverage / notably / seamlessly /
  furthermore（段首）
- 句长节奏：相邻句长短错落；连续三句等长即重写
- 数字格式沿用 v2：mean±sd 一体、× 用 ASCII、范围用 en-dash（LaTeX --）
