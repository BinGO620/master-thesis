# MMM 第二轮三盲审交叉综合

日期：2026-08-30。输入为三份独立第二轮报告：

- `review_codex_v2.md`：Weak Reject，confidence 4
- `review_mmm2026_claude_r2.md`：Borderline，confidence 3
- `review_mmm2026_glm_r2.md`：Accept，confidence 3

本文件在三份报告冻结后撰写，不修改任何独立报告。报告均只看 `latex/main_v3.pdf`，未把
`supplementary.md` 作为审稿包的一部分。

## 1. 当前综合判决

当前状态是 **Borderline，科学内容略偏可救，投稿包与版式仍未达到安全投稿状态**。

第二轮已经确认第一轮最严重的量词矛盾已被修复，且三位审稿人都认可本稿的实验纪律、
负结果披露、flow-budget 对照和 claim moderation。GLM 已给 Accept，Claude 从 Weak Reject
上调为 Borderline。剩余问题主要集中在：

1. 一个真实的 flow ratio 方向不一致；
2. `significant` 一词仍然超出三 seed 描述性设计的证据；
3. semantic mask 的作用点和 100/100 介入没有在论文中说明清楚；
4. memory 的因果归因与当前配置相矛盾；
5. 当前 PDF 用 `\\small` 压缩 §4–§7，存在 LNCS 字号合规风险；
6. supplementary 未随审稿包提供，导致承重证据不可审。

这些问题大多不需要 GPU，但其中第 5 项不能靠再压文字解决，必须恢复统一正文字号并重新做版面预算。

## 2. 三方共识

### C1. `significant` 仍是错误的推断性用词（Codex + GLM，Claude 以 N5 形式提出）

当前正文和 Fig. 3 使用：

- `|mean| >= 1 sd` over 3 seeds
- `significant cells`
- `all three components significantly positive`
- `directional cells count as no support`

这只是一个预先规定的描述性支持过滤器，不是显著性检验。3 个 seed 不足以支撑统计显著性，
而且正文最后又写了“every statement is descriptive”。

**必须修改为：**

- `supported cells` 或 `bold cells`
- `the descriptive support rule`
- `no sequence demonstrably supports all three components under this rule`
- `neither global necessity nor strict bundle necessity is established across the five measured sequences`

不要再写“both answers are negative”。未加粗格代表“未判定”，不是“反向证据”。尤其是
`Delta_L` 在 5/5 的均值为正，正确说法应是“positive in all five sequences, although three
cells are directional”，不能用过滤规则把未判定格硬转成否定。

### C2. flow ratio 的方向必须统一（Codex + GLM，且由证据核查确认）

第二轮报告指出：WP-B 原始均值为 `pt2: vanilla 45.37 cm, flow-mask 51.07 cm`。
因此：

- `vanilla / flow-mask = 0.89`, 即约 `0.90x`
- `flow-mask / vanilla = 1.13`, 表示 naive 更差

当前正文写“naive is worse on pt2 (0.90x)”，而 Fig. 4b 的轴写的是
`log ATE ratio to vanilla`，其绘图脚本 `make_v3_fig45_combined.py` 使用
`log(flow-mask / vanilla)`。这两者不是同一个方向。

**最安全的修法：**正文直接给 raw means，并统一采用 `arm / vanilla`：

> The naive flow-mask is worse on `pt2` (51.07 vs 45.37 cm, 1.13x flow-mask/vanilla).

同时将图中注释的 `0.90x` 改成 `1.13x`，或明确把所有轴改为
`log(vanilla / arm)`。不能只改正文而保留图的相反方向。

同一处还应明确“2 of 4”的判据是 **all three seeds having the same sign**。当前证据
`wpb_flowmask_verdict.md` 给出的结构是：pt1、mv_no_box2 通过，pt2、balloon2 不通过。

### C3. supplementary 是投稿包阻塞项（3/3）

当前正文仍依赖 S1–S12 来承载：完整协议、常数、18 序列全表、N 表、噪声地板、held-out
序列、渲染全表和逐 run 证据。`supplementary.md` 虽然在仓库中存在，但没有随当前 PDF
提供，也没有编译成最终 SI PDF。

这不是实验缺失，而是提交包不完整。投稿前必须：

1. 编译 supplementary PDF；
2. 检查 S1–S12 编号、表号和正文交叉引用；
3. 与主 PDF 一起进入实际投稿包；
4. 在提交前从最终 PDF 检查正文所有 `S#` 均可定位。

### C4. crowd regime 的 factorial 证据仍然不足（Codex + Claude，GLM 也保留为 major）

五序列 factorial 没有 crowd，crowd 的 bundle attribution 只有 `crowd2` 一个序列，且
intervention arms 的 dispersion 很大。当前修订已经诚实承认这一点，因此它不再是逻辑
阻塞，但仍限制 F1 的外推范围。

不建议现在补跑 crowd factorial。应把 scope 固定为：

> component necessity is measured across the five factorial sequences;
> the crowd-regime attribution is a descriptive single-sequence observation.

这句话必须同时出现在摘要/贡献和 Limitations 的相应位置，不要让读者把五序列结论读成
涵盖 crowd 的普遍规律。

### C5. mask / reliability 的作用点和 intervention 语义必须重写（Claude N2/N3，代码核查支持）

当前 Sec. 3.6 连续写了三件事：

1. mapping loss
2. keyframe-insertion gate
3. first `warmup_iters` tracking iterations 的 hard mask

随后又说“exactly two code paths”。这在论文层面确实矛盾，Fig. 1 caption 也只写 mapping loss
和 insertion gate。

代码核查得到的准确语义是：

- 标准 combined 配置中，semantic mask 在 tracking 的 warm-up 阶段作为 hard mask；
- warm-up 后，标准路径切换到 reliability soft weight；
- `hard_tracking_mask=true` 的 100/100 intervention 不是完全丢弃 soft weight。代码
  `get_loss_tracking_rgbd_hardsoft` 明确先 hard-exclude semantic dynamic pixels，
  再在保留下来的 static pixels 上乘 robust kernel 和 soft static confidence；
- 因此 Claude N3 “100/100 使 soft weight 完全不再应用”的条件性推断不符合当前实现，
  但论文没有写清楚，审稿人产生该误读是合理的。

**推荐修改：**

- Sec. 3.6 明确写“the semantic mask has three tracking/mapping/insertion consumers,
  with tracking hard masking limited to warm-up in the standard combined configuration”;
- 对 100/100 intervention 明确写“the hard mask remains active for all iterations,
  while the soft reliability weight still applies on surviving static pixels”;
- Fig. 1 要么增加 tracking residual 的 semantic-mask 虚线连接，要么 caption 明确该图只画
  persistent mapping/insertion paths，并在正文补充 warm-up tracking path；
- 不再使用“exactly two code paths”这种会把 tracking 排除在外的句子。

### C6. memory 的 lifecycle 归因不能保留（Claude N1，真实问题）

当前 §5.7 最后一句是：

> Since the Gaussian counts differ by only 10% between arms, the memory gap is the lifecycle,
> not map size.

这不能成立：combined 和 mask-free 共享同一个 lineage lifecycle D，且 combined 还包含
在线 Mask R-CNN；mask-free 的 Gaussian 数量反而更多但显存更低。当前证据最多支持“观察到
memory difference”，不支持把差异因果归因到 lifecycle。

**建议直接删除因果句，替换为：**

> The memory difference is observed under these configurations and is not causally decomposed;
> both arms share the lineage lifecycle, while combined also includes the online Mask R-CNN.

同时在 Table 3 caption 中保留：Mask R-CNN included, RAFT excluded。不要为了保留一个漂亮的
机制解释而引入与配置事实冲突的归因。

### C7. reliability map 的 pose circularity 至少要进入 limitation（Claude 继续提出）

`f_static` 使用 warm-up 后的当前 pose 计算，之后冻结。当前 §3.4 只讨论 tau 的 majority
statistic，却没有承认另一条可能失败源：warm-up pose 已被 mover 拉偏时，reliability map
本身可能被污染。

如果不补实验，至少要在 limitation 中写成第二个候选解释，并停止把 crowd failure 单独归因
于 tau：

> The reliability map also depends on the warm-up pose used to generate rigid flow. We do not
> separate this closed-loop effect from the majority-statistic explanation on crowd sequences.

代码中已有 `ego_pose_oracle` 的诊断开关和相关注释，可在 supplement 说明，但不应把默认关闭
的 oracle 当作主结果。

## 3. 第二轮已确认解决的问题

以下问题不应重复投入时间：

- 第一轮 Fig. 3 的量词结构已修正，mv_no_box 的 strip 已按规则显示 no；
- Fig. 3 图内旧的 “no globally necessary subset exists” 已改为新的 full-bundle 表述；
- Fig. 2 上下排重叠已通过缩窄并居中上排解决；
- Fig. 4b 的注释位置已移开数据簇；
- `as Sec. 5.5 predicts` 已改为 `consistent with Sec. 5.5`；
- Table 1 已明确竞品 ATE 行均为本方统一协议复现；
- Replica 已注明在预注册 18 序列分母外并补入引用；
- [9] DGS-SLAM 和 [26] DAGS-SLAM 已补 arXiv 标识；
- §5.6 的干预变量、噪声地板和单序列限制已写入正文；
- Mask R-CNN 在线、计入 combined 的 rate/memory，RAFT 预计算并排除，已写入 §5.7。

## 4. 低成本但应修的文字项

1. **Abstract**：把“strongest such system, RGD-SLAM”改成直接的协议描述，避免隐含
   superlative。建议“against RGD-SLAM, the same-protocol RGB-D 3DGS comparator (7.4 GB)”。
2. **§5.1 的 no-alternative 句**：当前“has no alternative in this table”是事实错误。
   Table 1 有 DG-SLAM、RGD-SLAM、WildGS-SLAM 等 dense-map alternatives。改为
   “has no more accurate or more memory-efficient alternative among the RGB-D 3DGS rows on
   the crowd columns”或更保守地直接删掉该句。
3. **`significant` 全文搜索替换**：Fig. 3 caption、strip、§5.2、Intro contribution。
4. **§5.4 raw means**：同时写 45.37/51.07，消除 ratio direction 争议。
5. **§5.4 ratio stability**：声明“2/4 under the all-seeds-same-sign rule”。
6. **§3.3 run count**：说明 36 = 6 sequences × 2 alternative kernels × 3 seeds，
   “five regimes”只是序列分类，不是 run multiplier。
7. **§5.3 run count**：12 个单组件 arm + 12 个 pair/gating arm，改正文总数。
8. **§4 latest-run 规则**：说明重复 seed run 如何处理，为什么固定选择最新合格产物。
9. **§2.2**：明确“our label”是本文作者对自身配置的称呼，并在同段说明 mask-free
   仍依赖 frozen RAFT，而非把对 WildGS 的 prior 批评写成单向要求。
10. **Related Work**：加入 ReFusion/纯几何残差动态剔除方向。引用 [14] 已在文献表中，
    但目前只作为 BONN 数据集/相关条目出现，没有作为方法定位。
11. **DynaGSLAM 文献**：补 WACV 2026 的页码/DOI，或明确标成 preprint。
12. **Table 1 crowd2**：不要只给 WildGS-SLAM 2.16±0.04 而其他行一位小数。统一精度，
    或在 caption 明确 crowd2 使用两位小数来解析 printed-precision tie。

## 5. 真实分歧与裁决

### 5.1 flow ratio 是谁的方向？

这是报告中的表面分歧，不是科学结论分歧。原始均值明确支持：flow-mask 在 pt2 更差，
`0.90` 只能是 vanilla/flow-mask，不能与 `arm/vanilla` 轴混用。以 raw means + 单一
`arm/vanilla` 约定为准。

### 5.2 100/100 是否完全替代 soft weight？

Claude 的条件性担忧被代码反驳：当前 `hardsoft` 分支在 hard mask 后仍对 surviving static
pixels 应用 soft confidence。论文仍需显式说明，否则读者会继续误读。

### 5.3 所有 Table 1 rows 是否自测？

第一轮曾有人怀疑 WildGS-SLAM/DynaSLAM 等是作者原论文数字。代码和 CSV 核查确认：
`build_paper_tables.py` 的 `cell()` 对竞品也从 `resources/02-baselines/baselines_result/<method>/tracking_raw.csv`
逐 seed 读取，竞品均有三 seed run artifact。此问题已解决，caption 可以保留“every row,
competitors included, is our own reproduction”。

### 5.4 MMM fit

三位 reviewer 给 2–3/5。论文是单媒体 RGB-D SLAM，MMM fit 合理但不强。Claude 的批评
最实质：仅在 §5.1 加一句“reader who needs a reconstructable 3DGS scene”还不足以形成
multimedia case。可以补一小段真实的媒体产物定位（动态视频中的可编辑/可渲染 3D scene
artifact、AR/VR 或 content creation use case），但不能把没有验证的应用写成结果。若不愿
添加真实 media-side motivation，应接受这是 venue fit 风险，而不是继续包装措辞。

## 6. 最高优先级整改顺序

### P0，投稿前必须完成

1. 删除或改写 `significant`，把“无支持”改成“未建立/未判定”；
2. 统一 flow ratio，修正文、Fig. 4b 轴/注释和 caption；
3. 改掉 memory → lifecycle 的因果句；
4. 解释 semantic mask 三个作用点以及 100/100 中 hard + soft 的组合；
5. 恢复统一 LNCS 正文字号，禁止用 `\\small` 把 §4–§7 压成另一种字号；
6. 编译并随投稿包提交 supplementary S1–S12。

### P1，建议同轮完成

7. 承认 reliability map 的 pose circularity；
8. 将 crowd factorial scope 和 crowd2 单序列 attribution 写入摘要/结论/Limitations；
9. 加 ReFusion/纯几何动态剔除相关工作；
10. 修 Abstract 的 RGD-SLAM comparator 表述和 §5.1 “no alternative”事实错误；
11. 完成 Table 1/3 的精度、run count 和 provenance 说明。

### P2，策略项

12. 加一段真实的 MMM multimedia motivation，或接受 venue fit 只有 2–3/5；
13. 统一 A4/LNCS 页面设置，当前模拟报告指出 PDF 是 US Letter (612×792 pt)，需在
    投稿模板允许的情况下确认 `llncs.cls` 的纸张设置和实际提交要求。

## 7. 是否适合现在投稿

**不建议直接用当前 PDF 投稿。** 不是因为实验结论已经失败，而是因为：

- flow ratio 的图文方向不一致；
- `significant` 会再次触发第一轮已经修过的 claim calibration 问题；
- memory 归因可被当前配置直接反驳；
- semantic mask 三个作用点在正文中自相矛盾；
- §4–§7 的 `\\small` 是格式合规风险；
- supplement 未进入审稿包。

完成 P0 后，三份报告的推荐理由会从“borderline/weak reject”转向“可接受但 fit 保留”。
其中 P0-1、P0-2、P0-3、P0-4 是零 GPU 的科学表述修复，P0-5 是版面工程，P0-6 是提交
材料工程。
