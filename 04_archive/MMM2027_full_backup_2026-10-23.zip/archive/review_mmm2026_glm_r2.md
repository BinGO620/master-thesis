# Review (Round 2) — MMM 2026 Submission (GLM)

**Manuscript:** RoGS-SLAM: Robust Dynamic-Scene Gaussian Splatting SLAM via Reliability-Guided Weighting and Coverage Sampling
**Reviewer emphasis:** experimental methodology and technical soundness
**Reviewed artifact:** `latex/main_v3.pdf` (revised build, 12 pages + 2 pages references, anonymous). Supplementary S1–S12 again referenced but not available to this reviewer; judgments are from the PDF alone, with confidence lowered where a claim rests on supplement-only evidence. This is a re-review; prior concerns are tracked explicitly.

## Overall recommendation: **Accept**

## Confidence: **3**

Confidence remains capped by the supplement's unavailability: constant tables (S2), per-seed artifacts (S1), the kernel-ablation design (S2.2), noise-floor details (S7), held-out rounds (S8), and the full 18-sequence table (S12) are all supplement-resident. The revision resolved the central claim-consistency problems of the previous version; what remains is weight-of-evidence, not claim-evidence mismatch.

## Summary

The paper presents a mask-free configuration for dynamic-scene 3D Gaussian splatting SLAM built on MonoGS, deciding which pixels to trust from the disagreement between frozen RAFT optical flow and rigid-scene reprojection flow, and down-weighting rather than removing dynamic pixels. The authors claim no architectural novelty — all four components (keyframe coverage, Huber reweighting, a flow-consistency reliability signal, a density lifecycle) are classical — and instead stake the paper on measurements: a pre-registered 120-run factorial showing component necessity is regime-dependent; a flow-budget control showing a naive p90 threshold on the byte-identical frozen flow does not reproduce the gain; and a variance–bias decomposition arguing pose-side claims must name their endpoint. The revision materially improves the calibration: the factorial's decision rule is now stated in the figure caption and applied consistently (I verified "0 of 5" under the stated bold-only rule); the Sec. 5.6 intervention is now named (extending the hard tracking mask from 10 to 100 iterations) with its noise floor defined (spread of same-config, same-seed re-runs); the flow-budget claim is scoped in the body to "a reasonable single-threshold use of the same flow"; the crowd regime's absence from the factorial is acknowledged in Sec. 5.2; and Table 1's caption now states every row is the authors' own reproduction under one protocol, with the same-hardware memory pair isolated. On the BONN crowd scenes the combined configuration leads the reproduced RGB-D 3DGS class (2.2–2.3 cm ATE) at roughly half the memory of RGD-SLAM, with the CPU-side systems that average better (NGD-SLAM, DynaSLAM) explicitly noted as producing no dense map. No state-of-the-art claim is made, and the paper's own failure modes (pt1, Replica, the PSNR paradox, the mask-dominant regime) are reported.

## Strengths

- **The claim-consistency problems are fixed at their root, not papered over.** The Fig. 3 rule ("bold cells only; directional cells count as no support") is stated, the strip relabelled to match, and the abstract now carries the "in this design" hedge. I recomputed the strip verdict for all five columns under the stated rule; "0 of 5" is now self-consistent.
- **The flow-budget control remains the paper's best experiment, and its scope is now honest.** Sec. 5.4 explicitly concedes the counterpart differs in more than the weighting form (no MAD normaliser, no geometric cue, hard removal) and states what the control does and does not rule out. This is the correct epistemic posture.
- **Sec. 5.6 is now fully specified.** The intervention is named, the noise floors are defined in the main text, the single-sequence domain and the two near-floor legs are stated in the contribution itself rather than buried, and the cross-sequence check's below-floor status is plain.
- **The revision adds honesty that was not forced by any reviewer-visible defect**: the CPU-systems caveat in Sec. 5.1 (NGD-SLAM 3.2 / DynaSLAM 4.0 average better but produce no dense map), the occlusion-boundary caveat on the flow-disagreement cue (Sec. 3.4), the Mask R-CNN-in-rate clarification (Sec. 5.7), and the held-out rounds being outside the 18-sequence denominator (Sec. 5.5).
- **Pre-registration discipline** (fixed denominator, frozen floors and rules, completion criterion, 3 seeds with sd everywhere) remains well above the venue norm.

## Major Concerns

**R2-M1 — (carried from R1-M5, unresolved) To-vanilla ratio bands are still not checked against the paper's own baseline-instability filter.**
Location: Sec. 5.4 and Fig. 4a,b (ours/vanilla 1.63–4.99×; naive/vanilla 0.90× on pt2), Limitation 4.
Limitation 4 concedes that on 8 of 18 sequences (vanilla CV > 20%) "a ratio depends on which basin the baseline fell into," yet no quoted ratio band is annotated against that filter. The N-ratios of Sec. 5.1 are immune by construction (both arms are the authors' own configurations — the paper says so), and Fig. 4b's 12/12-seed parity consistency partially mitigates the ours/vanilla side. But the naive counterpart's 0.90× on pt2 — the headline asymmetry of Sec. 5.4 — is a single mean on a baseline whose vanilla CV on pt2 (43.8±8.6) sits at the edge of the paper's own instability threshold. *Why it matters:* by the paper's own standard, this specific ratio is not guaranteed well-defined, and it carries one of the three headline contributions. *Resolve:* one clause stating whether the four Sec. 5.4 sequences are in the basin-stable set, and either a seed-level view of the naive/vanilla ratio on pt2 or a flag on the band. I expect the qualitative conclusion (naive crosses parity, ours does not) survives; this is a calibration fix, not a validity threat.

**R2-M2 — (carried from R1-M3, now properly scoped but unchanged in evidence) The crowd regime — the paper's strongest Table 1 results — has no factorial evidence, and its attribution rests on one sequence.**
Location: Sec. 5.2 (five factorial sequences, none a crowd scene), Sec. 5.3 and Table 2 (crowd2 only, intervention dispersions ±2.25/±2.11 exceeding most effects), Limitation 5.
The revision adds the scoping sentence ("the crowd regime is absent from this factorial; its attribution evidence is the single-sequence study of Sec. 5.3"), which resolves the claim-evidence mismatch. What remains is weight of evidence: the abstract's regime-dependence finding generalises from five sequences that exclude the regime where the combined arm leads its class, and the bundle-attribution for that regime is n = 1 sequence, labelled descriptive by the authors. *Why it matters:* a reader weighing the combined configuration's crowd-scene numbers has no component-level evidence for that regime. *Resolve:* either one crowd sequence in the factorial (8 cells × 3 seeds = 24 runs) or nothing further — the current honest labelling is acceptable for a 12-page paper, but the gap should survive into any camera-ready as a stated limitation rather than being read as resolved.

**R2-M3 — (new, wording) "Significant" is used for a criterion that is not a significance test.**
Location: Fig. 3 caption and bottom strip ("significantly positive"), Sec. 5.2 ("no sequence has all three components significantly positive").
The stated rule is |mean| ≥ 1 sd over 3 seeds. With n = 3 that corresponds to t ≈ 1.73 on 2 degrees of freedom — nowhere near conventional significance — and the paper's own closing sentence for the section is "every statement is descriptive." The criterion itself is a reasonable descriptive support filter; the inferential label is the problem, and it now appears in a caption where it will be quoted. *Why it matters:* the paper's credibility rests on never claiming more than its evidence; "significant" is exactly the word it elsewhere avoids. *Resolve:* relabel as "supported" or "bold" cells throughout (strip, caption, Sec. 5.2, and the contribution list's phrasing if echoed).

## Minor Comments

**R2-m1** — (carried) Sec. 3.3: "six sequences, five regimes, 36 runs" still does not let the reader reconstruct the design (presumably 6 sequences × 2 alternative kernels × 3 seeds, with "five regimes" a categorisation). Required correction: state the factors.
**R2-m2** — Abstract retains "closing the 'it just had more information' reading" while the revised body explicitly narrows the control's scope to a single-threshold rule. Required correction: soften the abstract to match (e.g., "making that reading untenable for a reasonable single-threshold use of the same flow").
**R2-m3** — (carried) Sec. 2.3 still presents consistency-based dynamic decisions as beginning with recent 3DGS systems; the pre-3DGS line (geometric/epipolar outlier rejection in feature-based dynamic SLAM) is a missing direction, not a missing citation.
**R2-m4** — Reference [12] (DynaGSLAM, WACV 2026) still lacks pages/DOI; [9] and [26] were correctly completed with arXiv IDs in this revision.
**R2-m5** — Table 1 caption's new claim "Every row, competitors included, is our own reproduction under one protocol" is strong and important; given the GPU column note (other hardware), a one-line statement of which hardware the non-3090 rows ran on would make the claim fully self-contained.
**R2-m6** — Sec. 4 "the denominator is fixed" remains cryptic on first read; one clause ("the 18-sequence set was fixed before any campaign") would fix it. Cosmetic.

## Questions to Authors

1. Are the four Sec. 5.4 control sequences in the basin-stable set under your Limitation 4 criterion (vanilla CV > 20%), and does the naive/vanilla 0.90× on pt2 hold seed-by-seed?
2. In Fig. 3 / Sec. 5.2, do you regard |mean| ≥ 1 sd (n = 3) as a significance criterion or a descriptive support filter? If the latter, would you relabel the strip and caption (see R2-M3)?
3. Table 1 now states every row is your own reproduction: which hardware carried the CPU rows (DynaSLAM, NGD-SLAM) and WildGS-SLAM, and were they run under the identical SE(3)-alignment completion protocol as your own arms?
4. Did any of the 120 factorial runs fail the ≥95% completion criterion, and how do such runs enter the cell means?
5. For the Sec. 5.6 intervention, is the comparison arm identical to the combined configuration except for the mask duration (10 → 100 iterations), and how many re-runs define each noise floor?

## Scores (MMM review form)

- (a) Relevance to MMM scope: **3/5** — RGB-D video and dynamic scene understanding; single-media, no cross-modal component.
- (b) Novelty: **3/5** — system is an assembly of classical components by the authors' own statement; the measurement-first methodology is the real and defensible contribution.
- (c) Technical soundness: **4/5** — controls are the right ones, language is now calibrated; dinged for the "significant" terminology (R2-M3) and the unannotated to-vanilla band (R2-M1).
- (d) Presentation quality: **4/5** — the revision fixed the rule ambiguity, named the intervention, and added honest caveats; still dense and supplement-dependent.
- (e) Experimental rigor: **4/5** — pre-registration, held-out rounds, fixed denominator, seed reporting; limited by 3 seeds (descriptive, and said so), one counterpart rule, and no factorial coverage of the crowd regime.

## MMM Fit Assessment

Unchanged from the previous round: this is a single-media RGB-D video paper with no audio, text, or cross-modal component — an acceptable but not strong fit for MMM, and the paper's natural home is a vision/robotics venue. On substance, the revision did what a revision should: every claim-evidence mismatch I could locate was fixed at the level of the claim's wording or the figure's rule, and the remaining gaps (crowd-regime factorial coverage, to-vanilla ratio annotation) are honestly labelled limitations rather than overreaches. That is enough to move from Weak Accept to Accept; the residual items are calibration, not validity, and none blocks the central case.

---
*Review generated by GLM (reviewer emphasis: experimental methodology and technical soundness), 2026-08-30, second round. Artifact: main_v3.pdf (revised build, 14 pages). Prior-round concerns tracked as carried where applicable.*
