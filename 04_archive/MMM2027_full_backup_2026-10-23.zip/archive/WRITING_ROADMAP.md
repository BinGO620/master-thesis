# MRCS 写作路线图（2026-08-25 更新：路线 A 启动 + 模拟审稿整改）

> **方法稿主线**：papers/maskfree_bundle/ 是当前唯一活动的投稿方向。
> 本文档 = 写作启动条件 + 章节规划 + 待补空缺 + 禁词表。
>
> **2026-08-25（exp45）**：三份独立模拟审稿（技术/新颖性/呈现三个侧重）已完成，
> 意见整改项已并入本文档 §一/§三/§五/§六。**用户已定路线 A（方法稿）。**
> 审稿共识：实验纪律超 CCF-C 平均线；两个真阻塞（无稿件 / novelty framing 不锐利），
> 其余均为 claim moderation。**claim framing 升级见 §零（新增，写作时的最高约束）。**
>
> **2026-08-26（exp47）目录梳理**：papers/maskfree_bundle/ 收敛为单一真身结构 ——
> 当前稿 `manuscript.md`（v2）+ `supplementary.md` + `figures/`（7 图
> ×3 格式 + make_*.py）+ `latex/`（main_v2.tex → body_v2.tex → main_v2.pdf，编译
> 一条链 `compile_v2.sh`）。历史版本进 `archive/`（manuscript_v0.md / manuscript_v1.md /
> skeleton_exp21.md）。图片块统一为 blockquote asset 格式后，md2latex 直接产出
> `\includegraphics`，占位符与手工补丁的根因已消除。旧 papers/mmm/ 维持归档不动。

---

## 零、claim framing（2026-08-25 新增，凌驾于旧章节措辞）

**旧 framing（审稿人 R2-M1 判为不足）**：
> "我们组合了 dense-KF + huber + reliability 三个机制，在 mask-free 下拿到 3.6–4.4×"

⇒ 审稿人读法：*"你把三个现成技术拼起来，碰巧有用"*，CCF-C novelty bar 可能不过。

**新 framing（写作时必须按此组织贡献）**：

> **贡献不是组件清单，是三个可测量的发现。**
>
> **F1（主）—— 组件必要性随 regime 分层，且这是被测出来的，不是被声称的。**
> 120-run 三因子全因子（8 格 × 5 序列 × 3 seed，预注册冻结）测出：
> `dense-KF` 在纯物/纯人 easy 上不可约（Δ_K +0.25/+0.59/+0.72）但在 balloon（混合 mover）
> 上**有害**（Δ_K −0.18）；`RobustTracking` 在 easy/medium 的 3/5 冗余（Δ_R≈0）但在
> balloon/pt1（难/混合）不可约（+0.78/+0.41）；`ReliabilitySignal` 是唯一跨 5 序列
> **不为负**的组件（Δ_L 5/5 正，pt2 +0.17 / balloon +0.29 显著）。
> **0/5 序列三者全正 ⇒ 不存在全局必要子集。**
> 这是一条**机制陈述**（必要集合是难度的函数），不是工程陈述。
>
> **F2 —— 增益不可归因于"随便什么用了 flow 的处理"。**
> WP-B 受控对照：同一份冻结 backward flow，朴素 p90 阈值 mask 在 held-out 4 序列上
> **不稳定**（pt2 反更差 0.90×），MRCS **4/4 稳定** 1.63–4.99×。
> ⇒ 关掉"信息预算解释"这条退路。
>
> **F3 —— 位姿侧机制：方差-偏置分解，且三个终点相互印证。**
> 同一单变量介入在两个位姿终点上方向相反（逐帧动态惩罚 +0.0806 变差 / 全轨迹 ATE
> −1.42 cm 变好），中间量 `coherent_amp` −0.0248 解释了为什么：剔除更多动态像素让
> 每帧误差更大但更"噪声化"，噪声沿轨迹平均掉、偏置累积。
> **适用域必须同写：仅 balloon 可判，f3_wk_xyz 跨序列验证为 ATE-INDISTINGUISHABLE。**

**写作时的硬映射**：Intro §P4 的三个 contribution bullet **就是 F1/F2/F3**，
不得退回"我们加了三个模块"的叙述。Method 章解释机制**怎么实现**，
Experiments 章证明 F1/F2/F3，两章不重复承担 novelty。

---

## 一、写作启动条件（闸门，全部绿灯才可写）

| 条件 | 状态 | 证据/备注 |
|---|---|---|
| **两问自答**（贡献是我们的 + 对动态有用）| ✅ 绿 | archive/skeleton_exp21.md §一 |
| **核心消融完整**（P-B 2×2 + WP-A 全因子）| ✅ 绿 | WP-A 120/120、P-B 24/24 |
| **中间地带 baseline**（WP-B flowmask）| ✅ 绿 | B1 判决 36/36，held-out① 2/2 |
| **18 序列主表**（mask-free + combined，3-seed）| ✅ 绿 | `18seq_rendering_main_table.md` 36/36 行 |
| **诚实适用域边界**（pt1 边界反例）| ✅ 绿 | archive/skeleton_exp21.md §3.1（阈值 2.5 已证否，正文改为 1.57–1.72 分离带） |
| **P7 cue-split 判决**（regime-aware 需要选择）| ✅ 绿 | 48/48，但无 selector → future work |
| **竞品差异化核对**（arxiv 已查）| ✅ 绿 | archive/skeleton_exp21.md §二，表格完整 |
| **诚实负结果**（TRC median 不增强）| ✅ 绿 | 已写进 §六 |
| **ReliabilitySignal 独立归因**（审稿 R1-M3）| ✅ 绿（2026-08-25 补） | `wpa_reliability_contribution.md`：WP-A L 轴隔离 + E0 装置门 |
| **vanilla baseline 方差**（审稿 R1-M1/R3-m4）| ✅ 绿（2026-08-25 补） | 18/18 序列已有 3-seed（`resources/02-baselines/.../MonoGS/tracking_raw.csv`）；**8 序列 CV>20%** 见 §五-A |
| **RAFT 离线成本**（审稿 R1-M7/R2-M5）| ✅ 绿（2026-08-25 补） | 54 ms/帧对（3090, RAFT-small, 12 iters, 640×480），来源 `flow_build_11seq_master.log` |
| **Replica 静态退化**（审稿 R3-M3）| ✅ 绿（2026-08-24 补） | `exp44_replica_seed_verdict.md`，进 Limitations |

**写作启动判定**：**全部绿灯**，可以开始写作。

---

## 二、venue 与篇幅定位

- **目标 venue**：CCF-C（初步定 MMM，但非硬绑定）
- **篇幅**：12 页正文 + 2 页引用（LNCS Springer 格式）
- **定位**：mask-free 内核实证稿 + 受控消融 + 诚实适用域，**不 claim SOTA**
- **投稿时间**：实验达标后自然启动，不由日历 ddl 强制（最高准则）

---

## 三、章节规划（12 页结构，8-10 页核心 + 2 页 RW/Intro）

### 1. Title & Abstract（0.5 页）

**标题候选**（待 codex 确认，见下方 §七）：
- **推荐**：*MRCS: Mask-Free Dynamic 3D Gaussian Splatting SLAM via Reliability-Guided Coverage Sampling*

**Abstract 要素**（200 词）：
- 问题：动态 3DGS SLAM 的 vanilla 在动态序列上漂移（28–147 cm）
- 现有方法全依赖 explicit 动态检测（YOLO/mask/flow 分割）
- 我们的 mask-free 内核：DynamicKeyframe + RobustTracking(huber) + ReliabilitySignal
- 核心数值（**含 baseline 方差，见 §五-A**）：balloon 39.3±1.0→12.11±1.90、
  mv_no_box 15.3±9.5→3.10±0.46、pt2 43.9±8.6→9.30±0.64
- **F1 主发现**：120-run 全因子 ⇒ 组件必要性随 regime 分层，无全局必要子集
- **F2 受控对照**：同等 flow 信息下朴素 flow-mask 不稳定（pt2 0.90×），MRCS 4/4 稳定
- 诚实边界：pt1 失败反例（RPE > 2.5 cm/frame 时 mask 必要）+ 静态 Replica 上 combined 更差

### 2. Introduction（1.5 页）

**P1 问题**：动态 SLAM 的挑战 + vanilla 失败实例
**P2 现有方案不足**：竞品依赖 explicit 检测的三层限制（外部模块、单帧脆弱、类别封闭）
**P3 我们的立场**：mask-free 组合在 Gaussian 准入层工作
**P4 贡献（3 bullet = §零 的 F1/F2/F3，不得退回"我们加了三个模块"）**：
1. **F1**：120-run 预注册全因子测出**组件必要性随 regime 分层** —— dense-KF 在 easy 上不可约
   但在混合 mover 上有害、RobustTracking 在 easy 上冗余但在难序列不可约、Reliability 跨序列
   唯一不为负；**0/5 序列三者全正 ⇒ 不存在全局必要子集**
2. **F2**：受控对照关掉"信息预算"退路 —— 同一份冻结 flow，朴素 p90 阈值不稳定
   （pt2 反更差 0.90×），MRCS 4/4 稳定 1.63–4.99×
3. **F3**：位姿侧方差-偏置机制由三个终点相互印证（逐帧惩罚变差 / coherent 分量降低 /
   全轨迹 ATE 变好），并诚实给出其适用域（仅 balloon 可判）

### 3. Related Work（1 页）

**P1 动态 SLAM**：RGD/DG/Gassidy/DAGS/BDGS/WildGS（表格对比，全依赖 explicit 检测）
**P2 3DGS 紧凑度**：在线剪枝（MGS-SLAM/Speedy-Splat）vs 我们的时域采样
**P3 鲁棒跟踪**：huber loss/reliability weighting 在 NeRF-SLAM 的先例，我们在 3DGS 准入层

### 4. Method（2 页）

**4.1 骨干（0.3 页）**：MonoGS + prune lifecycle，pipeline 图
**4.2 DynamicKeyframe（0.4 页）**：稠密关键帧的时域覆盖机制
**4.3 RobustTracking（0.4 页）**：huber 鲁棒核
**4.4 ReliabilitySignal（0.6 页）**：`s = (1-e_flow)(1-v·g)` + Cauchy 降权
  - **P7 裁决**：固定 both 不是普适，但无已验证 selector（写成 future work）
**4.5 机制可视化**（0.3 页）：5 面板图（RGB/Flow/e_flow/s/w + 时间线）

### 5. Experiments（3.5 页）

**5.1 设置（0.3 页）**：BONN/TUM 18 序列，3 seeds，2060/3090
**5.2 主结果 —— 18 序列主表（1 页）**：
  - Table 1: ATE 主表（mask-free vs combined vs MonoGS vs RGD）
  - 读法：相对 vanilla 的增益 + combined 的竞争区间
**5.3 消融 I —— P-B 2×2（0.5 页）**：
  - Table 2: mask × dynKF，mv_no_box 四格全 ~3cm
  - 结论：内核 = RT + Reliability 组合，单关不崩、全拿走才回 vanilla
**5.4 消融 II —— WP-A 全因子（0.5 页）**：
  - Table 3: 8 格摘要（balloon/mv_no_box/pt2）
  - 结论：A2-partial-redundant，难度分层适用域
**5.5 受控对照 —— WP-B flowmask（0.5 页）**：
  - Table 4: 朴素 flow-mask vs MRCS（held-out 4 序列）
  - 结论：B1，同等 flow 信息下 MRCS 必要（pt2 flow-mask 反更差 0.90×）
**5.6 适用域边界（0.4 页）**：
  - Table 5: pt1 vs pt2 RPE 分层（阈值 ~2.5 cm/frame）
  - 结论：高漂移序列 mask 从冗余变必需
**5.7 渲染与效率（0.3 页）**：
  - Table 6: PSNR/SSIM/LPIPS 摘要（与主表并列或分开）
  - 诚实解读：mask-ON PSNR 常低于 mask-free（动态剔除 trade-off）

### 6. Limitations（0.7 页，2026-08-25 按审稿意见扩充）

1. **pt1 边界反例**（RPE > 2.5 cm/frame 时 mask 从冗余变必需；mask-free 32.41 vs combined 10.04）
2. **不 claim SOTA**：绝对 ATE 在 TUM walking / person 上落后最佳竞品 1.4–2.5×
   （f3_wk_xyz 3.06 vs RGD 2.01 / WildGS 1.22；pt1 10.04 vs RGD 7.21）。**必须给全表不做选择性高亮**（审稿 R2-M2/R3-M5）
3. **静态场景退化（Replica，新增）**：combined 在全静态 Replica 上**更差且双稳态** ——
   office0 3.82±4.58 vs vanilla 0.368±0.012（CV 120% vs 3%，s1 落 9.10 cm 崩溃支）；
   room0 也双稳态。⇒ combined 只推荐用于**已确认含动态内容**的序列。证据 `exp44_replica_seed_verdict.md`
4. **P7 cue selection 未给出 selector**（只证明需要选择；WP-HS 已实测证否序列级语义占比这一族）
5. **TRC median 不增强分离**（K=8 降到 0.99）
6. **RAFT 是离线预计算，在线 FPS 不含它**（新增）：54 ms/帧对（3090, RAFT-small, 12 iters, 640×480）
   ⇒ 端到端在线部署需额外付这笔钱（上限 ~18.6 FPS 的 flow 分支）。**必须明确声明这是 operating
   condition，不得把不含 RAFT 的 FPS 当端到端效率**（审稿 R1-M7/R2-M5）
7. **vanilla baseline 自身在部分序列高方差**（新增）：mv_no_box CV 62%、mv_no_box2 CV 101%、
   f3_st_rpy CV 52% ⇒ 这些序列的 improvement ratio 依 basin 而变，**报均值必须同报方差**；
   CV≤10% 的序列（balloon 3%、f3_wk_xyz 3%）改进倍数才可单独引用（审稿 R1-M1/R3-m4）
8. **framework generality 未测**（新增）：全部证据基于单一 MonoGS fork，
   **不得写 "framework-general"**，只能写 "does not require semantic segmentation within our
   MonoGS-based implementation"（审稿 R1-M4/R2-M2）

### 7. Conclusion（0.3 页）

mask-free 内核对 vanilla **2.2–4.7×**（balloon/balloon2/pt2，逐序列保守区间 1.87–5.83×）
+ combined 在低方差序列上 **4.2–17.1×** + 受控对照证明机制必要 + 诚实适用域边界
+ future work（regime-aware selector、long-horizon 位姿正则）

---

## 四、图表清单与版面账（2026-08-25 重排：按"图是论文的灵魂"重定优先级）

### 四-A. 版面账（先算浮动体，再分配文字）

LNCS 12 页正文。**浮动体优先占位，文字吃剩下的额度** —— 此前把 12 页当"全是文字"来分配是错的。

| 类别 | 页数 |
|---|---:|
| 正文浮动体（下方 §四-B 的 7 个）+ caption | **≈ 2.0** |
| ⇒ 文字总额度 | **≈ 10.0** |

文字分配（合计须 ≤ 10.0）：Title+Abstract 0.5 · §1 Intro 1.5 · §2 RW **1.5** ·
§3 Method **2.2** · §4 Protocol **0.8** · §5 Exp 正文 2.5 · §6 Limitations 0.7 · §7 Conclusion 0.3
= **10.0**。

**当前实测与缺口** —— ⚠ **2026-08-25 已由真实 LaTeX 编译校准，旧的 520 words/页作废**
（证据 `results/evidence/latex_page_rate_calibration.md`）：

| 常数 | 旧假设 | **实测** | 影响 |
|---|---:|---:|---|
| 正文换算率 | 520 词/页 | **≈477 词/页** | 旧值乐观 9% |
| front matter（title+abstract+keywords） | 0.50 页 | **≈1.48 页** | 旧值少算 ~1.0 页 |
| 浮动体（5 表 + 1 图占位） | 2.0 页（7 个） | **1.0 页** | 表比预想省（`\footnotesize`） |

**v1 实编译 = 18 页**（`latex/main_v1.tex`，tectonic + llncs.cls，**三张图齐**、无参考文献）。
⇒ **v2 需削约 6 页**（旧估算说 4.35，低估 1.7）。
模型复核：散文 15.16 + caption 0.74 + front matter 1.48 + 图面积 0.82 = 18.20，实测 18。

| § | v0 | **v1** | v2 预算 | v1 仍超 |
|---|---:|---:|---:|---:|
| §1 Intro | 1.83 | **1.72** | 1.50 | +0.22 |
| §2 RW | 2.51 | **1.96** | 1.50 | +0.46 |
| §3 Method | 4.50 | **3.59** | 2.20 | +1.39 |
| §4 Protocol | 1.14 | **0.91** | 0.80 | +0.11 |
| §5 Results | 5.86 | **4.95** | 2.50 | +2.45 |
| §6 Limitations | 1.98 | **1.38** | 0.70 | +0.68 |
| §7 Conclusion | 0.67 | **0.60** | 0.30 | +0.30 |
| **文字合计** | **18.36** | **15.16** | 9.50 | +5.66 |

（上表已按 477 词/页重算；v0 那一列因此比冻结时记的 16.84 大。）

⇒ **v2 要削约 5.5 页，不是此前记的 4.35。** v0→v1 的 −3.3 页是实打实的，没有白做，
但 v2 的工作量比旧账大 1.2 页。

> **实测带来的两条策略修正**：
> 1. **不必急着合并表格** —— 5 张 `\footnotesize` 表加 1 张图占位一共才 1.0 页，
>    旧账给 7 个浮动体留 2.0 页是高估。削减的大头在**散文**与 **front matter**。
> 2. **abstract 是贵的** —— title 块 + 200 词 abstract + keywords 实测吃掉 1.48 页。
>    写满 200 词上限前先想清楚是否值得。
>
> **读数精度**：分页量化使单次测量约 ±8%（±1.4 页 @18 页）⇒ "18 页"读作 **18 ± 1**，
> 不要拿它做半页级决策。
> **⚠ 第一次真编译抓到一个会改内容的静默错误**：XeTeX 丢掉了正文里所有 Unicode 减号
> （8 处），包括 §5.2 的 **Δ_K(balloon) = −0.182** —— F1 的核心负号，丢了整句话就反了。
> 转换器现在**默认拒绝输出任何非 ASCII 字符**。判据：**排版工具链的静默降级与实验代码的
> 静默降级同等危险，一律改成硬失败**（同 `ReliabilitySignal` 缺 flow 静默跳过、
> `grep -c || echo 0` 两次事故）。
> **§1 仍不要削**（1.72，最接近预算，且承载 F1/F2/F3 的 framing）。

### 四-B. 进正文的浮动体（7 个，按"是否承载 F1/F2/F3"排序）

| 编号 | 内容 | 承载 | 页数 | 状态 |
|---|---|---|---:|---|
| **Fig1** | Pipeline：骨干 + **四**组件的挂载点，reliability 画**两条**出边（tracking 残差 / 候选 C± 确认） | 系统可读性 | 0.31 | ✅ `fig1_pipeline.pdf`（exp46 绘，全字号 ≥7pt） |
| **Fig2** | 机制可视化 5 面板：RGB / flow / e_flow / s / w | 让 §3.4 的抽象量可见 | 0.22 | ✅ `mechanism_figure_paper.png`（3176×1115，全宽 0.22 页） |
| **Fig3 ★新增** | **regime 分层图**：Δ_K/Δ_R/Δ_L × 5 序列的符号与幅度（发散色标，零线居中） | **F1 主贡献** | 0.30 | **待绘（P0）** |
| **Table1** | 18 序列 ATE 主表（mask-free / combined / MonoGS±sd / RGD） | 主证据 | 0.55 | ✅ 数据齐（须加 vanilla sd 列） |
| **Table2** | WP-B flowmask 受控对照（held-out 4 序列） | **F2** | 0.15 | ✅ |
| **Table3** | P-B 2×2（mask × dynKF） | 支撑 F1 | 0.15 | ✅ |
| **Table4** | 适用域边界：pt1 vs pt2 的 RPE 分层 | 诚实边界 | 0.15 | ✅ |

> **Fig3 是本轮新增的关键项**：F1 是全稿主贡献，但原清单只用一张 WP-A 数字表承载它。
> Δ_K 在 balloon 上为负、Δ_R 在 easy 上为零、Δ_L 五序列全正 —— 这个**符号模式**是论文要讲的事，
> 图能一眼看出，表需要读者自己逐格比较。数据已在 `wpa_factorial_readout.md`（15 个 Δ 全有 mean+sd）。

### 四-C. 下补充材料（正文只留一句话 + 指针）

| 原编号 | 内容 | 理由 | 正文如何交代 |
|---|---|---|---|
| 原 Fig3 | 竞品差异化表转图 | §2 已用散文讲完同一件事，图会重复 | 保持散文，不出图 |
| 原 Table6 | 渲染指标全表 | 18 序列 × 4 指标查表性质 | §5 一句话给方向 + 指 S2 |
| 原 Table7 | 效率全口径 | 自比性质，非主张载体 | §4 已写"仅自比、不含 RAFT" + 指 S3 |
| 原 Table8 | Replica 静态退化 | limitation 的支撑数据 | §6 一句话给 office0 数字 + 指 S4 |
| — | WP-A 8 格全因子详表 | Fig3 已承载判读；详表供复核 | Fig3 caption 指 S5 |
| — | 完整实验协议 | 已移出 | ✅ 已建 `supplementary.md` §S1 |

### 四-D. 绘图规范（两张待绘图共用）

- **尺寸**：全文宽 12.2 cm；高 ≤ 6.0 cm（保证 ≤ 0.31 页）。
- **字号**：图内最小字号 ≥ 7 pt（LNCS 正文 10 pt），矢量导出（PDF），不用位图。
- **配色**：发散色标只用于 Fig3 的 Δ（零 = 中性色），**不得用红绿对立**（色盲不可读）；
  Fig1 用单色+灰阶区分骨干与我方组件。
- **Fig3 必须标注**：每格 Δ 的 mean 与 sd、判定（positive/zero/negative/mixed），
  以及"0/5 序列三者全正"这一行结论。
- **禁止**：图里出现任何 §六 禁词；不得画未测量的箭头（如"动态污染被减少"这类未验证机制）。

---

## 五、待补空缺（优先级排序，2026-08-25 按审稿意见重排）

### 五-A. 审稿驱动的数据事实（已备好，写作时直接引用）

**vanilla baseline 3-seed 方差**（源 `resources/02-baselines/baselines_result/MonoGS/tracking_raw.csv`）：

| 类别 | 序列（CV） | 写作口径 |
|---|---|---|
| **低方差，倍数可引用** | balloon 3% · f3_wk_xyz 3% · f3_office 3% · f3_st_xyz 2% · f1_desk 6% · f2_person 6% · balloon2 7% · f2_xyz 8% · f3_wk_rpy 11% | 可写 "N× improvement" |
| **高方差，必须同报区间** | crowd 21% · f3_wk_hf 25% · crowd2 26% · f3_st_hf 33% · f3_st_rpy 52% · **mv_no_box 62%** · **mv_no_box2 101%** · person_t 20% | 只能写 "mean ± sd"，倍数须给范围 |

⚠ **mv_no_box 是主表里被反复引用的序列，而它的 vanilla CV 是 62%**（4.7/18.5/22.8 cm）
⇒ 倍数必须按 `headline_ratio_recompute.md` 的分档写。**mv_no_box / mv_no_box2 退出增益 headline**
（vanilla CV 62% / 101%，最保守配对仅 1.30× / 1.08×），改承担 **mask 冗余**判据（1.17× / 1.09×，
两臂皆我方且低方差，不经 vanilla 分母 ⇒ 该判据干净、不受影响）。

**RAFT 离线成本**（源 `flow_build_11seq_master.log`，2026-08-16，3090）：
54 ms/帧对均值（11 序列 17002 帧对 / 914 s），单序列 49–184 s（帧数 591–3693）。

**竞品渲染覆盖**（源 `18seq_rendering_main_table.md`）：
pt1/pt2 只有 RGD-SLAM 报了 PSNR/SSIM/LPIPS/DepthL1；DG/WildGS/Dyna/NGD/Co 只报 ATE
⇒ 表格中这些格标 "not reported"，**不得留空**（留空读作 cherry-pick）。

### P0（写作前必补）
- [x] **标题确定** ✅ `MRCS: Reliability-Guided Coverage Sampling for Dynamic 3D Gaussian Splatting SLAM`
- [x] **Fig1 pipeline 图绘制** ✅ exp46（0.31 页，四挂载点 + reliability 两出边，全字号 ≥7pt）
- [x] **Fig3 regime 分层图绘制** ✅ 承载 F1 主贡献（0.31 页，内置 15-cell 转录校验）
- [ ] **文字削 1.5 页**（§2 2.3→1.5 · §3 2.6→2.2 · §4 1.1→0.8）
      ⚠ **exp46 后 §3 变长了**（+第四组件 §3.5 + Fig1 caption + 两 site 说明）⇒ 缺口重算见 §四-A

### P1（写作中补齐）
- [ ] **主表加 vanilla sd 列**（8 个高 CV 序列必须可见）
- [ ] **references.bib 合并**（mmm/ 归档的 + 新增 WP-A/WP-B 引用）
- [x] **补充材料** ✅ 已建 `supplementary.md`（§S1 完整协议已移入）；待补 S2 渲染全表 /
      S3 效率全口径 / S4 Replica 详表 / S5 WP-A 8 格详表

### P2（可选）
- [ ] **crowd/crowd2 补样本**（codex 已建议跳过，post-result sample selection 风险）
- [x] **Replica 数据集** ✅ 已跑（2 场景 × 2 臂 × 3 seed = 12 run），结果进 Limitations 而非主表

---

## 六、禁词表（审稿人地雷，绝不踩）

### 不能写的主张
- ❌ "SOTA" / "超越 RGD" / "最优" / "state-of-the-art"
- ❌ "完全解决动态 SLAM" / "所有序列最优"
- ❌ "dense-KF 是内核"（balloon 上 dynKF-off 不变）
- ❌ "mask 无用"（balloon 上 mask 主导）
- ❌ "不可分整体" / "超加性" / "联合必要"（WP-A A2 已否决）
- ❌ "解决 pt1"（pt1 绝对值 38–63 cm 仍是失败区）
- ❌ "competitive on all sequences"（只能写 "on balloon and mv_no_box"）

### 不能写的机制
- ❌ "多帧 median 增强检测"（TRC 负结果：K=8 降到 0.99）
- ❌ "adaptive cue selection"（P7 只证明需要选择，未给出 selector）
- ❌ "geometry-only 全局最优"（mv_no_box 仍 both 优）
- ❌ "person 面积 / 语义占比可用于选择线索"（**WP-HS 已实测证否**：both-偏好的 mv_no_box 4.54%
  夹在 geo-偏好的 mv_no_box2 3.30% 与 pt2 8.24% 之间，任何阈值不可分；median/检出率/dilate=0 同构失败）
- ❌ "人占据画面主体 / person dominates the frame"（pt1 全 580 帧 person 面积 **max 仅 20.24%**、
  mean 7.31%；pt1 的难在 RPE 2.89 cm/frame 而非 person 面积）

### future work 的正确措辞（升级版，比"尚未验证"有力）
- ✅ "我们检验了最简单的候选 selector——序列级语义占比——并**测得**它无法分开这些 regime
  （both-偏好序列夹在 geo-偏好序列之间，任何阈值均不可分）；因此 regime selector 必须来自
  **mask-free 可观测量**（flow / geometry 残差诊断）。" 证据：`wphs_person_area_characterization.md`
- ✅ **（2026-08-25 exp46 测得；2026-08-27 exp50 外推检验 CONFIRMED）已测得一个满足该要求的候选**：
  **mask-free RPE** 在 18 序列上把
  "mask 冗余"与"mask 必需"两组分得**完全不重叠**（0.22–1.57 vs 1.72–2.98，17/17 决定格；
  被排除的那格若计入也一致）。它正是 mask-free 可观测量，不需要语义检测器。
  **预注册中点 τ=1.6445 已在 5 条 held-out 序列上检验**（exp47 派发 30 run，判决
  CONFIRMED：4 判决格 4/4 一致 + 1 带内格排除、无反向大错；证据
  `rpe_boundary_heldout.md`）。
  **仍须同写自限**：需先跑 mask-free 臂 ⇒ 事后诊断而非先验 selector；带**边界位置**
  未被外推检验（held-out 的 5 个 RPE 点无一落在带内）；n=5 descriptive。
  下一步 = 更多新序列检验带位置。
  证据：`rpe_stratification_rule_test.md` + `rpe_boundary_heldout.md`
- 附带好处：避免"要跑语义检测器才能配置 mask-free 模式"的自相矛盾。

### 不能误导的对比
- ❌ FPS 不得与竞品并列（2060 vs 竞品高显存，硬约束）
- ❌ 渲染 PSNR 不得只报 mask-free（combined 常更低但 SSIM 更好，要诚实说 trade-off）
- ❌ **不得把 improvement ratio 写成单一倍数而不给 baseline 方差**（2026-08-25 新增）：
  8 个序列的 vanilla CV>20%（mv_no_box 62%、mv_no_box2 101%），倍数依 basin 而变
- ❌ **不得只报有利的对比行**（2026-08-25 新增）：TUM walking / person 上落后最佳竞品
  1.4–2.5×，必须与 crowd 上的优势同表呈现
- ❌ **不得把不含 RAFT 的 online FPS 当端到端效率**（2026-08-25 新增）
- ❌ **不得写 "framework-general" / "broadly applicable"**（2026-08-25 新增）：
  单一 MonoGS fork，无跨框架证据

### 不能写的机制（续）
- ❌ **不得声称 "证明了动态污染被减少"**（2026-08-25 新增）：PLY 剖析显示高斯数量不变、
  opacity 全局变暗，与"背景保护"一致，但**未做逐高斯动态/静态分类** ⇒ 只能写
  "consistent with background protection"，不能写 "proven dynamic contamination reduction"（审稿 R2-M4）
- ❌ **不得写 "we use MonoGS unmodified" / "native density lifecycle" / "三个组件"**
  （2026-08-25 exp46 新增，证据 `method_attachment_audit.md`）：上报配置是
  `Mapping.lifecycle_mode: prune` —— 每个新高斯带 lineage tag、reject/expire 时整条删除，
  **实测删掉中位 55%（区间 27–81%）的候选 lineage**；vanilla MonoGS 是 `immediate`。
  ⇒ 组件数是 **4**（+可选 mask），密度规则**已被改**，必须披露。
- ❌ **不得写 reliability 信号"feeds the mapping loss / the keyframe-insertion gate"**
  （2026-08-25 exp46 新增）：那两条是 **SemanticMask** 的通道。reliability 只有两个
  消费点 —— ①tracking RGB+depth 残差（权重有 **0.10 地板**，从不剔除像素）、
  ②候选高斯 C± 确认加权。
- ❌ **不得把 Δ_L 说成"tracking 降权的效应"**（2026-08-25 exp46 新增）：WP-A 8 格钉死
  `reliability_confirm: true`，L=OFF 同时关掉上述两个 site ⇒ Δ_L 是**联合效应**。
  也不得声称两 site 各占多少份额（未测）。
- ❌ **不得写 "RPE > 2.5 cm/frame 时 mask 从冗余变必需"**（2026-08-25 exp46 新增，
  证据 `rpe_stratification_rule_test.md`）：该阈值内插自 pt1/pt2 两点，18 序列检验下
  **17 决定格错 4 个**（f3_wk_xyz RPE 1.72 却 N=8.76×、balloon 2.03 却 3.96×、
  f3_wk_rpy 2.26 却 3.41×、f3_wk_hf 2.33 却 5.27×）。
  正确写法 = "mask-free RPE 把两组分得完全不重叠（冗余 0.22–1.57 / 必需 1.72–2.98，17/17），
  分界落在 **(1.57, 1.72)**"。
- ❌ **不得把 1.64 cm/frame 写成"selector"**（exp50 部分放宽但仍禁）：预注册中点已在
  5 条 held-out 序列上 4/4 判决格一致（CONFIRMED），**允许写"外推方向受检验的
  post-hoc 诊断"**；但**仍不得写"selector"**——算它要**先跑 mask-free 臂** ⇒ 事后
  诊断非先验选择器；且**带边界位置未被检验**（held-out 无 RPE 点落在带内）、n=5
  descriptive。措辞模板见 manuscript §5.5 Held-out check 段。
- ❌ **不得引用 "pt1 动态像素占 ~65% 画面"**（2026-08-25 exp46 就地撤回）：
  `bracketing_pt1_pt2_scene.md` §二 的该数字在 mask-ON 口径下不可复现
  （实测 mean 7.31% / max 20.24%），且其脚本未入库。

---

## 七、标题候选（等 codex 确认）

**已确认标题**（2026-08-15）：
> **MRCS: Reliability-Guided Coverage Sampling for Dynamic 3D Gaussian Splatting SLAM**

**选题依据**：聚焦内核机制，不用模式标签（mask-free/mask-ON）。
- `Reliability-Guided`：RobustTracking + ReliabilitySignal 可靠性驱动降权
- `Coverage Sampling`：DynamicKeyframe 时域覆盖采样
- 准确反映 P-B 2×2 结论："组合才是内核、单点都不是"

**为什么不用 Mask-Free 做标题**：
- 与 RGD 有竞争力的数字全来自 combined（mask-ON），不是 mask-free
- mask-free 相对 vanilla 有 2.2–4.7× 增益（低方差序列），但绝对值不与 SOTA 竞争
- 标题用 Mask-Free 暗示"不用 mask 就能打 SOTA"，与数据不符
- 正确做法：method 正文说明"不依赖语义分割亦可运行（mask-free 模式），可选加入 mask（combined 模式）进一步提升"

**原候选标题（已废弃）**：
- ~~"MRCS: Mask-Free Dynamic 3DGS SLAM via Reliability-Guided Coverage Sampling"~~（过度承诺 mask-free 竞争力）
- ~~"Robust Temporal Sampling Without Semantic Segmentation"~~（太泛）
- ~~"Temporal Consistency Bundle"~~（自贴堆叠标签）

---

## 八、写作流程 —— 多版本演进（2026-08-25 用户定策，取代原线性流程）

**原则**：先写全，再压缩。不要一边写一边压——那会让"该不该删"和"怎么写"两个决策纠缠在一起，
而且细节一旦没落笔就永久丢失（本会话已有两个实例：Huber δ 和倍数分母，都是靠详细核对才发现的）。

| 版本 | 目标 | 页数 | 内容策略 | 产物 |
|---|---|---:|---|---|
| **v0 详尽版** | 把所有已验证细节写下来，**不受页数约束** | 不限（估 18–22） | 每个 claim 都带 sd / 区间 / 适用域 / 证据指针；协议全文在正文；所有表全列 | `archive/manuscript_v0.md` |
| **v1 精华版** | 按 §零 F1/F2/F3 取舍，删掉不承载贡献的段落 | ~14 | 查表性质内容移 supplementary；合并同类表；每节只留承重论证 | `archive/manuscript_v1.md` |
| **v2 投稿版** | 硬压到 venue 限制，图表定稿 | **12**（MMM LNCS） | 按 §四-A 版面账；文字 10.0 页 + 浮动体 2.0 页 | `manuscript.md`（当前文件 = v2） |

**为什么这样做**：
- v0 是**资产**，不是草稿。之后换 venue（页数不同）、写扩展版、写学位论文章节，都从 v0 取材，不用重新考古。
- v0 → v1 的删除决策有据可依（是否承载 F1/F2/F3），不是凭手感。
- v1 → v2 的压缩是**版面工程**（合表、缩图、移 supplementary），不再动科学内容。

**当前状态**：v0→v1→v2 已于 2026-08-25/26 走完：v1 冻结在 `archive/manuscript_v1.md`，v2 = 当前 `manuscript.md`。
⇒ **下一步应先回填 v0**：把已起草三节按 v0 口径展开（补回被我压掉的细节），
再走 v0→v1→v2。已压缩的内容未丢失，在 git 历史与 `supplementary.md` 中。

### 八-A. v0 → v1 已删内容清单（2026-08-25 exp46 执行，逐条可回取）

> **v0 冻结在 `archive/manuscript_v0.md`（16.84 页文字）**；下表每一行的原文都在那里。
> 移出正文的材料**已经写进** `supplementary.md` §S2–S7（不是"待补"）。
> 净效果：**16.84 → 13.85 页文字（−2.99，−17.7%）**，七节俱在。

| 位置 | 删/移了什么 | 去向 | 理由 |
|---|---|---|---|
| §2.1 | 竞品逐条枚举压成两段（DynaSLAM/NGD/RoDyn + 5 个 3DGS 系统），引文保留但不再逐句展开 | 引文锚点表（正文附录）| 承担"这个模式很普遍"即可，不需逐系统详述 |
| §2.2/2.3 | WildGS 段与第三条线段各压约三分之一；§2.3 顶部的项目状态 blockquote 删除 | — | 状态 blockquote 是项目簿记，不是论文文字 |
| §2.4 | **整段删**："Two questions remain open…" | — | 与 §1 P3 几乎逐句重复；§1 已承担 framing |
| §2.5 | 跨系统读数差异两段 → 一段 + 指针 | **S6** | 查表性质；且明写"无结论依赖该表" |
| §3.1 | 四组件编号列表 → 一段散文 | Fig1 承担拓扑 | 图已画出四挂载点与 reliability 两出边 |
| §3.2 | 覆盖机制三段 → 两段 | — | 措辞冗余，数字全留 |
| §3.4 | 归一化/权重两段合并压缩 | 常数入 **S2** | 机制陈述全留（含 0.10 地板与两 site）|
| §3.5 | 五段 → 两段；逐 run 计数与"第三种 lifecycle 变体的负结果"移出 | **S2.1** | 负结果必须保留，但属复核材料 |
| §3.6 | 自指的审计史一段 → 一句 | **S2** | 审计过程不是方法内容 |
| §3.7 | 三段（常数清单 + inert 字段 + 配置卫生瑕疵）→ 一段 + 指针 | **S2** | 16 个常数逐条查表性质 |
| §4 | 协议摘要六段 → 五段，seeds/completion 合并 | **S1**（早已全文在此）| 正文只留"读表所需" |
| §5 开头 | 小节导航段删除 | — | 小节标题自己会说 |
| §5.1 | 逐序列极值配对区间、baseline 原始 seed 值 | **S3.1 / S3.2** | 查表性质；正文保留"倍数怎么读"的规则与 8/18 高 CV 事实 |
| §5.3 | 2×2 表移出，正文留一段判读 | **S4** | 表是支撑材料，判读才是论证 |
| §5.7 | 三块（渲染/代价/离散度）各压成一句领起 + 指针 | **S5** | 诚实性要求它们**可见**，但细节不必在正文 |
| §5.2/5.4/5.5/5.6 | 散文收紧约 20–30% | — | **claim 与 caveat 一字未删**，只删重复解释 |
| §6 | 14 条 → 8 条：复现/度量类 6 条移出 | **S7** | 正文留"限制我们**主张**什么"，S7 收"限制怎么**复现/读数**" |
| §7 | 三段收紧 | — | — |
| Fig1 caption | 260 词 → 85 词 | 常数入 **S2** | 字号与版面约束 |

**v1 没有做、留给 v2 的**（≈4.35 页，属版面工程非科学取舍）：
§5 现有五张表的合并/缩排、浮动体尺寸定稿、LaTeX 断行与图文环绕、
以及按真实 LNCS 排版复核 520 words/页这个换算率本身。

**v1 明确没削的**：§1 Introduction（1.58 页，几乎正贴预算）——它承载 F1/F2/F3 的 framing。

### 各版本的硬约束（三版共同遵守，不因压缩而放松）
1. §六 禁词表全版本生效；
2. 每个数字可溯源到 `results/` 下的 run artifact；
3. 每个竞品陈述可溯源到该论文自己的原文（`competitor_protocol_table.md`）；
4. 倍数一律用 3-seed 分母并按 `headline_ratio_recompute.md` 的 CV 分档报。

---

## 九、原线性流程（已被 §八 取代，保留作参考）

1. Intro + RW 先行 → 2. Method 平行 → 3. Experiments 主体 → 4. Limitations + Conclusion
→ 5. 全稿 codex 终审（禁词/措辞/逻辑链）→ 6. LNCS LaTeX 格式转换 → 7. 投稿

---

**更新记录**：
- 2026-08-15：创建本文档，Phase 1 归档完成，等 codex Phase 2 决策
- 2026-08-25（exp45）：**路线 A 启动**。新增 §零 claim framing（F1/F2/F3，凌驾旧措辞）；
  §一 补 4 条审稿驱动闸门（Reliability 归因 / vanilla 方差 / RAFT 成本 / Replica 退化）；
  §三 Intro 贡献 bullet 改为 F1/F2/F3、Limitations 从 5 条扩到 8 条；
  §五 新增 §五-A 数据事实速查表；§六 禁词新增 5 条。
  依据 = 三份独立模拟审稿（技术/新颖性/呈现），共识两阻塞项：无稿件 + novelty framing。
- 2026-08-25（exp45 续）：**§四 版面账重做（图优先）** —— 首次把浮动体计入 12 页，
  文字额度从"12 页"修正为 **10.0 页**；正文浮动体裁到 7 个（2.0 页），4 表下补充材料；
  **新增 Fig3 承载 F1**（已绘，0.31 页，含 15-cell 转录校验）；
  §八 改为**多版本演进**（v0 详尽 → v1 精华 → v2 投稿 12 页），取代原线性流程。
