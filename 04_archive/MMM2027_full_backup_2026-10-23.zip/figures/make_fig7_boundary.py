"""Fig. 7 - where the mask-free configuration stops being sufficient.

Core conclusion: a quantity the mask-free arm can itself observe - its own
per-frame RPE - separates the sequences where the semantic mask is redundant from
those where it is necessary with no overlap across all 17 decided sequences; but
the interval is fitted to those same sequences and needs the mask-free arm to have
been run, so it is a post-hoc diagnostic and not a selector.

Archetype: quantitative grid. Panel (a) is the hero: the separation itself, one
point per sequence on the observable axis. Panel (b) is the control that stops the
obvious misreading - that this is just "mask-free did badly" - by showing the pair
with near-identical ATE but 12.6-fold different mask necessity.

Source: results/evidence/rpe_stratification_rule_test.md (18 sequences x 2 arms
x 3 seeds, re-read from the main table; no new runs).
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from _figstyle import C, TEXTWIDTH, apply_style, panel_label, save

apply_style(font_size=6.8)

# sequence, mask-free RPE (cm/frame), N = ATE(mask-free)/ATE(combined), verdict
ROWS = [
    ("f2_xyz",     0.222,  0.99, "redundant"),
    ("f3_office",  0.456,  1.02, "redundant"),
    ("f2_person",  0.498,  0.92, "redundant"),
    ("f1_desk",    0.847,  1.07, "redundant"),
    ("f3_st_xyz",  0.910,  0.57, "redundant"),
    ("f3_st_hf",   1.041,  1.21, "ambiguous"),
    ("mv_no_box",  1.210,  1.17, "redundant"),
    ("f3_st_rpy",  1.465,  1.02, "redundant"),
    ("mv_no_box2", 1.521,  1.09, "redundant"),
    ("f3_wk_xyz",  1.717,  8.76, "necessary"),
    ("balloon",    2.028,  3.96, "necessary"),
    ("f3_wk_rpy",  2.264,  3.41, "necessary"),
    ("f3_wk_hf",   2.327,  5.27, "necessary"),
    ("crowd",      2.643, 15.24, "necessary"),
    ("balloon2",   2.730,  1.92, "necessary"),
    ("pt1",        2.894,  2.73, "necessary"),
    ("crowd2",     2.980, 20.95, "necessary"),
]

COL = {"redundant": C["maskfree"], "necessary": C["combined"],
       "ambiguous": C["vanilla"]}
MRK = {"redundant": "o", "necessary": "D", "ambiguous": "^"}

fig = plt.figure(figsize=(TEXTWIDTH, 7.4 / 2.54))
gs = fig.add_gridspec(2, 1, height_ratios=[1.0, 0.52], hspace=1.05,
                      left=0.105, right=0.885, top=0.91, bottom=0.235)
axa = fig.add_subplot(gs[0, 0])
axb = fig.add_subplot(gs[1, 0])

# --------------------------------------- panel a: the separation, one axis ----
# The separating band is the claim; draw it first so points sit on top of it.
axa.axvspan(1.572, 1.717, color=C["up"], alpha=0.14, lw=0, zorder=1)
# Annotation goes in the empty lower-right quadrant and points back at the band,
# so it cannot sit on top of the f3_wk_xyz point just right of the band.
axa.annotate("every threshold in this band separates\nall 17 decided sequences",
             xy=(1.60, 2.4), xytext=(0.78, 9.5),
             fontsize=5.2, color=C["up"], ha="center", va="center",
             linespacing=1.4, zorder=6,
             arrowprops=dict(arrowstyle="-", lw=0.6, color=C["up"],
                             shrinkA=2.0, shrinkB=1.0))

for name, rpe, n, verdict in ROWS:
    axa.plot(rpe, n, MRK[verdict], ms=3.4, color=COL[verdict], mew=0, zorder=4)

# necessity thresholds, stated in the protocol before the test
axa.axhline(1.5, color=C["ink"], lw=0.6, ls=(0, (2.5, 1.5)), zorder=3)
axa.axhline(1.2, color=C["ink"], lw=0.6, ls=(0, (2.5, 1.5)), zorder=3)
# The two necessity cut-offs share one right-margin label; at this y-scale the
# lines sit ~0.3 dex apart, too close for two stacked two-line callouts.
axa.text(3.38, 1.34, "$N$ = 1.5 necessary\n$N$ = 1.2 redundant", fontsize=5.0,
         color=C["ink"], va="center", ha="left", linespacing=1.35)

# Label the sequences a reader will look for. Offsets are per-point so the
# labels of the two closely spaced necessary sequences do not overlap.
OFFS = {"crowd2": (4.5, 1.5), "crowd": (-4.5, 3.0), "f3_wk_xyz": (5.0, -1.0),
        "f3_st_hf": (4.5, 2.0), "balloon2": (5.0, -3.0), "balloon": (4.5, 1.5)}
for name, rpe, n, verdict in ROWS:
    if name in OFFS:
        ha = "right" if OFFS[name][0] < 0 else "left"
        axa.annotate(name, (rpe, n), textcoords="offset points",
                     xytext=OFFS[name], fontsize=5.0, color=COL[verdict],
                     ha=ha)

axa.set_yscale("log")
axa.set_ylim(0.45, 42)
axa.set_yticks([0.5, 1, 2, 5, 10, 20])
axa.set_yticklabels(["0.5", "1", "2", "5", "10", "20"])
axa.set_xlim(0.05, 3.30)
axa.set_ylabel("mask necessity  $N$\nATE(mask-free) / ATE(combined)",
               fontsize=5.9, linespacing=1.3)
axa.set_xlabel("mask-free per-frame RPE (cm/frame)  -  computed by the mask-free arm itself")
axa.grid(alpha=0.35, zorder=0)
axa.set_axisbelow(True)
panel_label(axa, "a", x=-0.140, y=1.235)
axa.set_title("A mask-free observable separates the two regimes", loc="left",
              fontsize=7, pad=17)
axa.legend(handles=[
    Line2D([], [], marker="o", ms=3.4, ls="none", color=C["maskfree"],
           label="mask redundant (9)"),
    Line2D([], [], marker="D", ms=3.4, ls="none", color=C["combined"],
           label="mask necessary (8)"),
    Line2D([], [], marker="^", ms=3.4, ls="none", color=C["vanilla"],
           label="ambiguous, excluded (1)"),
], loc="lower left", bbox_to_anchor=(0.0, 1.005), ncol=3, fontsize=5.4,
    handletextpad=0.4, columnspacing=1.1, borderpad=0.0)

# ------------------------- panel b: the control against the obvious misread ---
pair = [("f3_st_hf", 35.59, 1.21, 1.041), ("crowd", 34.89, 15.24, 2.643)]
xx = np.arange(2)
wb = 0.20

ate = np.array([p[1] for p in pair])
nn  = np.array([p[2] for p in pair])
rpe = np.array([p[3] for p in pair])

axb.bar(xx - wb, ate / ate.max(), width=wb * 0.9, color=C["vanilla_lt"], lw=0,
        zorder=2, label="mask-free ATE (normalised)")
axb.bar(xx,      nn / nn.max(),  width=wb * 0.9, color=C["down"], lw=0,
        zorder=2, label="mask necessity $N$ (normalised)")
axb.bar(xx + wb, rpe / rpe.max(), width=wb * 0.9, color=C["div_pos"], lw=0,
        zorder=2, label="mask-free RPE (normalised)")

for i in range(2):
    axb.text(xx[i] - wb, ate[i] / ate.max() + 0.03, f"{ate[i]:.1f} cm",
             fontsize=5.0, ha="center", va="bottom", color=C["ink"])
    axb.text(xx[i],      nn[i] / nn.max() + 0.03, f"{nn[i]:.2f}$\\times$",
             fontsize=5.0, ha="center", va="bottom", color=C["down"])
    axb.text(xx[i] + wb, rpe[i] / rpe.max() + 0.03, f"{rpe[i]:.3f}",
             fontsize=5.0, ha="center", va="bottom", color=C["div_pos"])

axb.set_xticks(xx)
axb.set_xticklabels([p[0] for p in pair], fontsize=6.2)
axb.set_ylim(0, 1.32)
axb.set_yticks([])
axb.spines["left"].set_visible(False)
axb.set_xlim(-0.5, 1.5)
panel_label(axb, "b", x=-0.140, y=1.10)
axb.set_title("Not a restatement of “mask-free did badly”", loc="left",
              fontsize=7, pad=15)
# Legend above the bars: below them sits the sequence-name tick row.
axb.legend(loc="lower left", bbox_to_anchor=(-0.005, 1.005), ncol=3,
           fontsize=5.3, handlelength=1.0, handletextpad=0.4,
           columnspacing=1.2, borderpad=0.0)


save(fig, "fig7_boundary")
