"""Fig. 2 - mechanism chain with measured visual and temporal evidence.

Core conclusion: two complementary cues form one frozen reliability signal,
which is converted into a bounded Cauchy residual weight.

Archetype: asymmetric mixed-modality figure. Panel (a) states the mechanism,
panel (b) grounds it in one measured RGB/flow example, and panel (c) shows the
measured sequence-level signal and weight.
"""
from pathlib import Path
import csv

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from _figstyle import C, TEXTWIDTH, apply_style, save

apply_style(font_size=7)

repo_root = Path(__file__).resolve().parents[3]
evidence = plt.imread(
    repo_root / "results/evidence/mechanism_reliability_flow_samples.png"
)
timeline_csv = (
    repo_root
    / "results/runs/P11/P11-REMEDIAL-3090/render_balloon_maskfree_seed0"
    / "datasets_bonn/p6_maskoff_prune_balloon/seed_0/2026-08-19-23-00-03"
    / "reliability_signal/frames.csv"
)
with timeline_csv.open(newline="") as handle:
    rows = list(csv.DictReader(handle))
frames = [int(row["frame"]) for row in rows]
mean_s = [float(row["mean_s"]) for row in rows]
mean_w = [float(row["mean_w"]) for row in rows]

# Frame 100 has the clearest simultaneous view of the moving person and balloon,
# and the strongest, most spatially interpretable flow response in this sequence.
rgb_100 = evidence[205:425, 145:484]
flow_100 = evidence[550:758, 145:484]

fig = plt.figure(figsize=(TEXTWIDTH, 10.2 / 2.54))
gs = fig.add_gridspec(
    3, 1, height_ratios=[0.62, 1.10, 0.78], hspace=0.30,
    left=0.06, right=0.985, top=0.94, bottom=0.04,
)

# Panel a: a single horizontal chain with formulas kept inside their boxes.
axa = fig.add_subplot(gs[0, 0])
axa.set_xlim(0, 12)
axa.set_ylim(0, 2.1)
axa.axis("off")

boxes = [
    (0.20, 1.10, 2.20, 0.72, "flow cue   $e_{\\mathrm{flow}}$", "#D6EAF8", C["maskfree"], 6.0),
    (0.20, 0.18, 2.20, 0.72, "geometry cue   $v g$", "#D6EAF8", C["maskfree"], 6.0),
    (3.25, 0.46, 3.85, 1.08, "fused reliability\n$s=(1-e_{\\mathrm{flow}})(1-vg)$", "#E8F5E9", C["up"], 5.7),
    (8.15, 0.46, 3.65, 1.08, "bounded weight\n$w=1/[1+(d/\\tau)^2]$", "#E8F5E9", C["up"], 5.6),
]
for x, y, width, height, label, face, edge, text_size in boxes:
    axa.add_patch(
        FancyBboxPatch(
            (x, y), width, height, boxstyle="round,pad=0.08",
            facecolor=face, edgecolor=edge, linewidth=1.2,
        )
    )
    axa.text(
        x + width / 2, y + height / 2, label,
        ha="center", va="center", fontsize=text_size, color=C["ink"],
        linespacing=1.2,
    )

# The two cues are independent inputs. They join on an orthogonal bus before
# entering the fused signal, avoiding any false cue-to-cue causal edge.
axa.plot([2.48, 2.82], [1.46, 1.46], color=C["combined"], lw=1.0)
axa.plot([2.48, 2.82], [0.54, 0.54], color=C["combined"], lw=1.0)
axa.plot([2.82, 2.82], [0.54, 1.46], color=C["combined"], lw=1.0)
for start, end in [((2.82, 1.00), (3.17, 1.00)),
                   ((7.18, 1.00), (8.07, 1.00))]:
    axa.add_patch(FancyArrowPatch(
        start, end, arrowstyle="-|>", mutation_scale=7,
        linewidth=1.0, color=C["combined"], shrinkA=0, shrinkB=0,
    ))

axa.set_title("Two measured cues produce one frozen, bounded weight",
              loc="left", fontsize=7.2, pad=2)

# Panel b: the best measured RGB/flow example, shown large and side by side.
middle = gs[1, 0].subgridspec(1, 2, wspace=0.08)
axb1 = fig.add_subplot(middle[0, 0])
axb2 = fig.add_subplot(middle[0, 1])
for axis, crop, title in [
    (axb1, rgb_100, "RGB, frame 100"),
    (axb2, flow_100, "backward optical flow"),
]:
    axis.imshow(crop)
    axis.set_title(title, fontsize=6.4, loc="left", pad=2)
    axis.set_xticks([])
    axis.set_yticks([])
    for spine in axis.spines.values():
        spine.set_visible(False)

# Panel c: redraw the timeline from the measured CSV so every line and label
# remains vector-sharp after LNCS page scaling.
axc = fig.add_subplot(gs[2, 0])
axc.plot(frames, mean_s, color="#334CFF", lw=0.9,
         label="mean $s$ (static confidence)")
axc.plot(frames, mean_w, color=C["up"], lw=0.9,
         label="mean $w$ (tracking weight)")
axc.set_xlim(0, 440)
axc.set_ylim(0.48, 0.86)
axc.set_xticks([0, 100, 200, 300, 400])
axc.set_yticks([0.5, 0.7])
axc.set_xlabel("frame index", labelpad=1)
axc.set_ylabel("mean value", labelpad=2)
axc.grid(alpha=0.35)
axc.legend(loc="lower right", ncol=2, fontsize=5.3,
           handlelength=1.4, columnspacing=0.9)
axc.set_title("Measured reliability across the full balloon sequence",
              fontsize=6.4, pad=2)

# Keep all panel labels on one page-level vertical guide. Axes-relative x
# offsets drift because the middle row is split into two nested subplots.
for label, axis in (("a", axa), ("b", axb1), ("c", axc)):
    pos = axis.get_position()
    fig.text(
        0.008, pos.y1, label,
        fontsize=8, fontweight="bold", color=C["ink"],
        ha="left", va="bottom",
    )

save(fig, "fig2_mechanism")
