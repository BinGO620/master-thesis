"""Fig. 3 (v3) - component necessity is regime-dependent (F1 headline figure).

Core conclusion: in a pre-registered 8-cell x 5-sequence x 3-seed factorial, no
sequence has all three components positive (0/5), so no globally necessary
subset exists; which component is necessary is a function of the regime.

Design (FIGURE_PLAN_v3.md):
- 3 rows (K/R/L) x 5 columns (sequences by tracking difficulty);
- continuous RdBu diverging colour on the mean shift, zero pinned to neutral;
- each cell: mean +/- sd, non-bold when |mean| < 1 sd (directional only);
- bottom strip: the 0/5 all-positive summary, one check per column.
"""
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import FancyBboxPatch

from _figstyle_v3 import C, DIV_RAMP, TEXTWIDTH, apply_style, save

apply_style(font_size=7)

# ======================= data (transcription-checked) =======================
# Source: results/evidence/wpa_factorial_readout.md; identical to manuscript
# v3 Sec. 5.2 table. Positive = removing the component hurts.
SEQS = ["mv_no_box", "mv_no_box2", "pt2", "balloon", "pt1"]
SEQ_TAGS = ["object-only", "object-only", "person", "mixed-mover", "person, hard"]
COMPONENTS = ["K", "R", "L"]
COMP_NAMES = ["uniform keyframe\ncoverage (K)", "robust reweighting\n(R)",
              "reliability signal\n(L)"]
MEAN = np.array([
    [+0.250, +0.586, +0.719, -0.182, -0.201],   # K
    [+0.030, -0.013, -0.011, +0.780, +0.413],   # R
    [+0.157, +0.131, +0.170, +0.291, +0.108],   # L
])
SD = np.array([
    [0.162, 0.250, 0.309, 0.131, 0.183],
    [0.187, 0.178, 0.147, 0.037, 0.140],
    [0.417, 0.158, 0.048, 0.202, 0.199],
])
_expect = {
    (0, 0): "+0.250", (0, 1): "+0.586", (0, 2): "+0.719", (0, 3): "-0.182", (0, 4): "-0.201",
    (1, 0): "+0.030", (1, 1): "-0.013", (1, 2): "-0.011", (1, 3): "+0.780", (1, 4): "+0.413",
    (2, 0): "+0.157", (2, 1): "+0.131", (2, 2): "+0.170", (2, 3): "+0.291", (2, 4): "+0.108",
}
for (r, c), v in _expect.items():
    assert f"{MEAN[r, c]:+.3f}" == v, f"transcription mismatch at {(r, c)}"

# ============================== geometry ====================================
# figure canvas: full text width, 5.0 cm tall.
fig = plt.figure(figsize=(TEXTWIDTH, 3.98 / 2.54))

# matrix axes: leave 0.165 left for component names, 0.065 right for the
# vertical colourbar, 0.30 bottom for strip + conclusion, 0.16 top for headers.
ax = fig.add_axes([0.165, 0.335, 0.755, 0.585])
ax.set_xlim(0, 5)
ax.set_ylim(0, 3)
ax.invert_yaxis()
ax.axis("off")

cmap = mpl.colors.LinearSegmentedColormap.from_list("rbdu", DIV_RAMP)
norm = TwoSlopeNorm(vmin=-0.8, vcenter=0.0, vmax=+0.8)

for r in range(3):
    for c in range(5):
        m, s = MEAN[r, c], SD[r, c]
        face = cmap(norm(m))
        directional = abs(m) < s
        ax.add_patch(FancyBboxPatch(
            (c + 0.045, r + 0.06), 0.91, 0.88,
            boxstyle="round,pad=0,rounding_size=0.06",
            facecolor=face, edgecolor="white", lw=1.2, zorder=1))
        sign = "+" if m > 0 else ("\u2212" if m < 0 else "")
        lum = 0.299 * face[0] + 0.587 * face[1] + 0.114 * face[2]
        tcol = "white" if lum < 0.55 else C["ink"]
        ax.text(c + 0.5, r + 0.38, f"{sign}{abs(m):.2f}", ha="center", va="center",
                fontsize=7.5, fontweight="bold" if not directional else "normal",
                color=tcol, zorder=2)
        ax.text(c + 0.5, r + 0.70, f"\u00b1{s:.2f}", ha="center", va="center",
                fontsize=5.6, color=tcol, alpha=0.9, zorder=2)

# row labels
for r, name in enumerate(COMP_NAMES):
    ax.text(-0.10, r + 0.5, name, ha="right", va="center", fontsize=6.4,
            color=C["ink"], linespacing=1.25)

# column labels (below the header band, above the matrix)
for c, (seq, tag) in enumerate(zip(SEQS, SEQ_TAGS)):
    ax.text(c + 0.5, -0.06, seq, ha="center", va="bottom", fontsize=6.6,
            fontweight="bold", color=C["ink"], clip_on=False)
    ax.text(c + 0.5, -0.36, tag, ha="center", va="bottom", fontsize=5.2,
            color="#707070", clip_on=False)

# vertical colourbar at the right edge, aligned with the matrix.
# Per FIGURE_PLAN_v3 the decode key lives in the caption, not in the figure.
cax = fig.add_axes([0.945, 0.335, 0.020, 0.585])
cbar = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax,
                    orientation="vertical", ticks=[-0.8, -0.4, 0.0, 0.4, 0.8])
cbar.ax.tick_params(labelsize=5.0, length=1.5, pad=1.5)
cbar.outline.set_visible(False)

# ======================= bottom strip: the 0/5 verdict ======================
# One strip: the question once, on the left; one answer per column. The label
# is printed per column nowhere (an earlier build did that and the five copies
# collided at print size).
strip = fig.add_axes([0.165, 0.075, 0.755, 0.185])
strip.set_xlim(0, 5)
strip.set_ylim(0, 1)
strip.axis("off")
strip.add_patch(FancyBboxPatch(
    (0.06, 0.10), 4.88, 0.86,
    boxstyle="round,pad=0,rounding_size=0.05",
    facecolor=C["panel_bg"], edgecolor=C["rule"], lw=0.5))
strip.text(0.24, 0.74, "all three supported?", ha="left", va="center",
           fontsize=5.4, color="#707070")
for c in range(5):
    strip.text(c + 0.5, 0.36, "no", ha="center", va="center", fontsize=7.0,
               fontweight="bold", color=C["bad"])

# conclusion line, centred under the strip and kept inside the canvas
fig.text(0.50, 0.022, "No sequence rewards all three components (0 of 5): "
         "the full bundle is nowhere strictly necessary",
         ha="center", va="bottom", fontsize=6.2, fontweight="bold", color=C["ink"])

save(fig, "fig3_regime_split_v3")
