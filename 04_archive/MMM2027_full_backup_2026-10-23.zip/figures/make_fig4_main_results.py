"""Fig. 4 - 18-sequence trajectory error, all four arms, log axis.

Core conclusion: our two configurations reduce trajectory error over the
unmodified backbone across the dynamic sequences, but the size of that reduction
is a function of the sequence, and the baseline's own dispersion decides whether
a ratio may be quoted at all.

Archetype: quantitative grid, one hero panel (a) plus a dispersion strip (b).
Panel (a) carries the comparison; panel (b) carries the honesty about which
denominators are stable, which is the thing a reviewer will probe.

Source: results/evidence/18seq_rendering_main_table.md (ours, 3-seed) and
resources/02-baselines/04-baselines_result.xlsx (prior work, published means).
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from _figstyle import C, TEXTWIDTH, apply_style, panel_label, save

apply_style(font_size=6.5)

# ------------------------------------------------------------------- data ----
# (sequence, group, vanilla_mean, vanilla_sd, maskfree, combined, rgd_mean, rgd_sd)
# Groups are merged to the dataset level so 18 rows carry 4 spans, not 8 crowded
# ones; the finer scene type is already legible from the sequence name itself.
# RGD values updated 2026-08-26 (exp49): now include ±std from 3-seed reproduction
# (resources/02-baselines/baselines_result/RGD-SLAM/tracking_raw.csv).
ROWS = [
    ("f1_desk",    "TUM static",  1.47,  0.08,  1.49,  1.39,  2.32, 0.11),
    ("f2_xyz",     "TUM static",  1.66,  0.13,  1.91,  1.93,  1.71, 0.07),
    ("f3_office",  "TUM static",  1.65,  0.05,  1.59,  1.55,  1.42, 0.06),
    ("f2_person",  "TUM dynamic", 6.30,  0.40,  6.79,  7.34,  6.11, 0.22),
    ("f3_st_hf",   "TUM dynamic", 2.80,  0.92, 35.59, 29.43,  2.76, 0.48),
    ("f3_st_rpy",  "TUM dynamic", 18.99, 9.80,  2.63,  2.58,  2.90, 0.34),
    ("f3_st_xyz",  "TUM dynamic", 1.66,  0.04,  2.66,  4.69,  2.03, 0.38),
    ("f3_wk_hf",   "TUM dynamic", 44.45, 11.06, 17.33,  3.29,  3.25, 0.11),
    ("f3_wk_rpy",  "TUM dynamic", 62.89,  6.81, 14.61,  4.29,  3.55, 0.24),
    ("f3_wk_xyz",  "TUM dynamic", 28.14,  0.86, 26.84,  3.06,  2.01, 0.36),
    ("balloon",    "BONN",        39.32,  1.01, 12.11,  3.06,  2.45, 0.22),
    ("balloon2",   "BONN",        22.05,  1.55, 10.14,  5.27,  4.26, 0.89),
    ("crowd",      "BONN",        86.47, 18.34, 34.89,  2.29,  2.61, 0.28),
    ("crowd2",     "BONN",       147.50, 39.03, 45.89,  2.19,  2.36, 0.06),
    ("mv_no_box",  "BONN",        15.33,  9.47,  3.10,  2.65,  2.28, 0.26),
    ("mv_no_box2", "BONN",        16.84, 16.96,  5.62,  5.14,  4.70, 0.24),
    ("pt1",        "BONN",        44.83,  9.06, 32.41, 11.89,  7.21, 1.24),
    ("pt2",        "BONN",        43.85,  8.55,  9.30, 10.45, 22.99, 3.66),
]

names = [r[0] for r in ROWS]
van   = np.array([r[2] for r in ROWS])
vsd   = np.array([r[3] for r in ROWS])
mfree = np.array([r[4] for r in ROWS])
comb  = np.array([r[5] for r in ROWS])
rgd   = np.array([r[6] for r in ROWS])
rgd_sd = np.array([r[7] for r in ROWS])
cv    = vsd / van * 100.0
high_cv = cv > 20.0

y = np.arange(len(ROWS))[::-1]          # first row at the top

fig = plt.figure(figsize=(TEXTWIDTH, 8.8 / 2.54))
gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 0.24], wspace=0.12,
                      left=0.17, right=0.995, top=0.90, bottom=0.175)
ax = fig.add_subplot(gs[0, 0])
axc = fig.add_subplot(gs[0, 1], sharey=ax)

# ------------------------------------------------- panel a: the comparison ----
# Alternating row bands make an 18-row chart readable without gridlines.
for i, yy in enumerate(y):
    if i % 2 == 0:
        ax.axhspan(yy - 0.5, yy + 0.5, color=C["panel_bg"], lw=0, zorder=0)

# A connector from baseline to our best arm turns each row into one readable move.
best = np.minimum(mfree, comb)
for yy, v, b in zip(y, van, best):
    ax.plot([v, b], [yy, yy], color=C["rule"], lw=0.8, zorder=1,
            solid_capstyle="round")

ax.errorbar(van, y, xerr=vsd, fmt="o", ms=3.0, mfc="white", mew=0.9,
            color=C["vanilla"], ecolor=C["vanilla"], elinewidth=0.7,
            capsize=1.4, zorder=3, label="MonoGS (unmodified)")
ax.plot(mfree, y, "s", ms=3.0, color=C["maskfree"], mew=0, zorder=4,
        label="MRCS mask-free")
ax.plot(comb,  y, "D", ms=3.0, color=C["combined"], mew=0, zorder=5,
        label="MRCS combined")
ax.errorbar(rgd, y, xerr=rgd_sd, fmt="|", ms=5.0, mew=1.0,
            color=C["prior"], ecolor=C["prior"], elinewidth=0.6,
            capsize=1.2, zorder=6, label="RGD-SLAM")

ax.set_xscale("log")
ax.set_xlim(0.9, 400)
ax.set_xticks([1, 3, 10, 30, 100])
ax.set_xticklabels(["1", "3", "10", "30", "100"])
ax.set_xlabel("ATE RMSE (cm, log scale)  -  lower is better")
ax.set_yticks(y)
ax.set_yticklabels(names, fontsize=6.0)
ax.set_ylim(-0.6, len(ROWS) - 0.4)
ax.tick_params(axis="y", length=0, pad=1.5)
ax.spines["left"].set_visible(False)
ax.grid(axis="x", zorder=0, alpha=0.55)

# Group spans on the far left: a rule plus one rotated label per dataset family,
# placed outside the tick labels so nothing overlaps the sequence names.
seen = {}
for i, r in enumerate(ROWS):
    seen.setdefault(r[1], []).append(y[i])
trans = ax.get_yaxis_transform()
for g, ys in seen.items():
    ytop, ybot = max(ys), min(ys)
    ax.plot([-0.235, -0.235], [ybot - 0.34, ytop + 0.34], transform=trans,
            color=C["rule"], lw=0.8, clip_on=False, solid_capstyle="butt")
    ax.text(-0.255, (ytop + ybot) / 2, g, transform=trans, rotation=90,
            ha="center", va="center", fontsize=5.4, color=C["vanilla"],
            clip_on=False)

panel_label(ax, "a", x=-0.295, y=1.015)
ax.set_title("Trajectory error across the full 18-sequence benchmark",
             loc="left", fontsize=7, pad=5)

# Legend above the plot: an 18-row chart has no empty corner to give away.
handles = [
    Line2D([], [], marker="o", ms=3.0, mfc="white", mew=0.9, ls="none",
           color=C["vanilla"], label="MonoGS (unmodified)"),
    Line2D([], [], marker="s", ms=3.0, ls="none", color=C["maskfree"],
           label="MRCS mask-free"),
    Line2D([], [], marker="D", ms=3.0, ls="none", color=C["combined"],
           label="MRCS combined"),
    Line2D([], [], marker="|", ms=5.0, mew=1.0, ls="none", color=C["prior"],
           label="RGD-SLAM"),
]
ax.legend(handles=handles, loc="lower left", bbox_to_anchor=(0.0, 1.035),
          ncol=4, handletextpad=0.4, columnspacing=1.1, borderpad=0.0,
          fontsize=5.8)

# ------------------------------------ panel b: is the denominator stable? ----
for i, yy in enumerate(y):
    if i % 2 == 0:
        axc.axhspan(yy - 0.5, yy + 0.5, color=C["panel_bg"], lw=0, zorder=0)

bar_c = [C["down"] if h else C["vanilla_lt"] for h in high_cv]
axc.barh(y, cv, height=0.62, color=bar_c, lw=0, zorder=2)
axc.axvline(20, color=C["ink"], lw=0.7, ls=(0, (2.5, 1.5)), zorder=3)
axc.set_xlim(0, 118)
axc.set_xticks([0, 20, 60, 100])
axc.set_xlabel("baseline CV (%)")
axc.tick_params(axis="y", length=0, labelleft=False)
axc.spines["left"].set_visible(False)
axc.grid(axis="x", alpha=0.45, zorder=1)
panel_label(axc, "b", x=-0.10, y=1.015)
axc.set_title("ratio quotable?", loc="center", fontsize=6.4, pad=5)
axc.text(24, y[0] + 0.62, "20% cut-off", fontsize=5.0, color=C["ink"],
         va="center", ha="left")


save(fig, "fig4_main_results")
