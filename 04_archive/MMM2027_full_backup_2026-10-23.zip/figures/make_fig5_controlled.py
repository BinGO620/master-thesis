"""Fig. 5 - the gain does not follow from the flow information alone.

Core conclusion: given byte-identical frozen flow, a naive per-pixel threshold on
that flow is unstable across sequences - worse than the baseline on one - while
our weighting improves on the baseline on all four; so the gain is attributable to
the mechanism, not to the extra input.

Archetype: quantitative grid. Panel (a) is the hero: three arms, four held-out
sequences, absolute error. Panel (b) makes the paired per-seed comparison
explicit, because the claim is about consistency of sign, not about a mean gap.

Source: results/evidence/archive_pre_exp32/wpb_flowmask_verdict.md (36 runs,
3 arms x 4 held-out sequences x 3 seeds, all completing >= 95% of frames).
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from _figstyle import C, TEXTWIDTH, apply_style, panel_label, save

apply_style(font_size=6.8)

SEQ = ["pt1", "pt2", "mv_no_box2", "balloon2"]

# mean +- half-range, the pre-registered convention for this campaign
van_m  = np.array([63.22, 45.37, 15.64, 24.10])
van_e  = np.array([10.65,  2.02, 14.14,  0.56])
nai_m  = np.array([51.41, 51.07,  6.23, 23.30])
nai_e  = np.array([11.17, 11.09,  0.43,  9.87])
our_m  = np.array([38.51,  9.09,  4.97, 11.90])
our_e  = np.array([ 2.51,  0.31,  0.29,  1.85])

# paired per-seed log-ratio log(naive / ours); positive = ours better
paired = {
    "pt1":        [+0.402, +0.059, +0.361],
    "pt2":        [+1.883, +1.509, +1.738],
    "mv_no_box2": [+0.299, +0.198, +0.182],
    "balloon2":   [+0.782, +0.040, +0.957],
}
# naive vs the baseline it is supposed to beat; note pt2 is negative
naive_vs_van = np.array([+0.212, -0.103, +0.582, +0.122])

fig = plt.figure(figsize=(TEXTWIDTH, 5.8 / 2.54))
gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 0.72], wspace=0.42,
                      left=0.085, right=0.995, top=0.92, bottom=0.38)
axa = fig.add_subplot(gs[0, 0])
axb = fig.add_subplot(gs[0, 1])

# ------------------------------------------------ panel a: absolute error ----
x = np.arange(len(SEQ))
w = 0.26
for off, (m, e, col, lab) in enumerate([
    (van_m, van_e, C["vanilla"],  "vanilla (no flow)"),
    (nai_m, nai_e, C["naive"],    "naive threshold on the same flow"),
    (our_m, our_e, C["combined"], "MRCS weighting on the same flow"),
]):
    axa.bar(x + (off - 1) * w, m, width=w * 0.92, color=col, lw=0,
            zorder=2, label=lab)
    axa.errorbar(x + (off - 1) * w, m, yerr=e, fmt="none", ecolor=C["ink"],
                 elinewidth=0.6, capsize=1.5, zorder=3)

axa.set_xticks(x)
axa.set_xticklabels(SEQ, fontsize=6.2)
axa.set_ylabel("ATE RMSE (cm)")
axa.set_ylim(0, 96)
axa.set_yticks([0, 20, 40, 60, 80])
axa.grid(axis="y", alpha=0.45, zorder=0)
axa.set_axisbelow(True)
panel_label(axa, "a", x=-0.115)
axa.set_title("Equal, byte-identical flow budget", loc="left", fontsize=7, pad=4)

# The one row that closes the "any flow treatment would do" reading.
axa.annotate("naive is worse\nthan vanilla here", xy=(1.0, 51.07 + 11.6),
             xytext=(1.42, 78), fontsize=5.4, color=C["down"], ha="left",
             va="top", linespacing=1.35,
             arrowprops=dict(arrowstyle="-", lw=0.6, color=C["down"],
                             shrinkA=0, shrinkB=1.5))

# ------------------------------------------- panel b: paired, per seed -------
axb.axvline(0, color=C["ink"], lw=0.7, zorder=3)
axb.axvspan(-1.2, 0, color=C["down"], alpha=0.055, lw=0, zorder=0)

yy = np.arange(len(SEQ))[::-1]
for i, s in enumerate(SEQ):
    vals = paired[s]
    axb.plot([min(vals), max(vals)], [yy[i], yy[i]], color=C["rule"], lw=1.0,
             zorder=2, solid_capstyle="round")
    axb.plot(vals, [yy[i]] * 3, "o", ms=2.6, color=C["combined"], mew=0,
             zorder=4)
    axb.plot(np.mean(vals), yy[i], "|", ms=7, mew=1.3, color=C["combined"],
             zorder=5)
    # the naive-vs-vanilla point, on the same axis, same units
    axb.plot(naive_vs_van[i], yy[i] - 0.30, "s", ms=2.4, color=C["naive"],
             mew=0, zorder=4)

axb.axvline(0.20, color=C["vanilla"], lw=0.6, ls=(0, (2.5, 1.5)), zorder=3)
axb.text(0.235, yy[0] + 0.52, "pre-registered\nmargin $\\delta$ = 0.20",
         fontsize=5.0, color=C["vanilla"], va="center", linespacing=1.3)

axb.set_yticks(yy)
axb.set_yticklabels(SEQ, fontsize=6.2)
axb.set_ylim(-0.55, len(SEQ) - 0.35)
axb.set_xlim(-0.35, 2.15)
axb.set_xlabel("paired log-ratio  (positive $\\rightarrow$ MRCS better)")
axb.tick_params(axis="y", length=0)
axb.spines["left"].set_visible(False)
axb.grid(axis="x", alpha=0.4, zorder=0)
axb.set_axisbelow(True)
panel_label(axb, "b", x=-0.145)
axb.set_title("Per-seed, paired", loc="left", fontsize=7, pad=4)

# One figure-level legend row below both x-labels. The three arms are the same
# objects in a and b, so a single key serves the whole figure and nothing can
# land on a bar, an error bar, a data point, or the panel-a callout.
fig.legend(handles=[
    Line2D([], [], marker="s", ms=3.4, ls="none", color=C["vanilla"],
           label="vanilla (no flow)"),
    Line2D([], [], marker="s", ms=3.4, ls="none", color=C["naive"],
           label="naive threshold, same flow"),
    Line2D([], [], marker="s", ms=3.4, ls="none", color=C["combined"],
           label="MRCS weighting, same flow"),
    Line2D([], [], marker="o", ms=2.6, ls="none", color=C["combined"],
           label="b: log(naive / MRCS), per seed"),
    Line2D([], [], marker="s", ms=2.4, ls="none", color=C["naive"],
           label="b: log(vanilla / naive), mean"),
], loc="upper center", bbox_to_anchor=(0.5, 0.235), ncol=5, fontsize=5.3,
    handlelength=1.0, handletextpad=0.4, columnspacing=1.15, borderpad=0.0)


save(fig, "fig5_controlled")
