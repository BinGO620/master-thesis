"""Fig. 3 - regime-dependent component necessity (3-factor factorial, 5 sequences).

Core conclusion: no sequence has all three components positive (0/5); the necessary
subset is regime-dependent. Coverage (dense keyframing) is positive on 3 easy
sequences, negative on the mixed-mover, mixed on one medium. Robust reweighting
(Huber IRLS) is positive on 2 hard sequences and zero on the 3 easy ones.
Reliability (flow + geometry) is positive on 2 sequences, mixed on 3.

Color: a colour-blind-safe diverging map (red = negative, blue = positive,
grey = neutral), per the drawing norm that forbids red/green opposition.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

from _figstyle import C, TEXTWIDTH, apply_style, panel_label, save

apply_style(font_size=6.8)

# ======================== Data: 3 components x 5 sequences =================
# Rows: Coverage (K), Robust reweighting (R), Reliability (L)
# Columns: mv_no_box, mv_no_box2, pt2, balloon, pt1 (easy -> hard)
# Values: mean +/- sd (cm), relative to control (no components)
# Sign convention: positive = improvement (lower ATE)

ROWS = ["Coverage\n(dense keyframing)", "Robust reweighting\n(Huber IRLS)",
        "Reliability\n(flow + geometry)"]
COLS = ["mv_no_box\n(object)", "mv_no_box2\n(object)", "pt2\n(person)",
        "balloon\n(mixed)", "pt1\n(person)"]

# Mean shifts (cm, improvement = positive)
MEAN = np.array([
    [+0.25, +0.59, +0.72, -0.18, -0.20],   # Coverage
    [+0.03, -0.01, -0.01, +0.78, +0.41],   # Robust
    [+0.16, +0.13, +0.17, +0.29, +0.11],   # Reliability
])

# Standard deviations
SD = np.array([
    [0.16, 0.25, 0.31, 0.13, 0.18],
    [0.19, 0.18, 0.15, 0.04, 0.14],
    [0.42, 0.16, 0.05, 0.20, 0.20],
])

# Verdicts (for color + label)
VERDICT = [
    ["positive", "positive", "positive", "negative", "mixed"],
    ["zero", "zero", "zero", "positive", "positive"],
    ["mixed", "mixed", "positive", "positive", "mixed"],
]

fig = plt.figure(figsize=(TEXTWIDTH, 8.2 / 2.54))
ax = fig.add_axes([0.10, 0.30, 0.88, 0.62])

# ======================== Heatmap colours by verdict =======================
# Colour-blind-safe diverging map: red = negative, blue = positive, grey = neutral.
# (Red/green opposition is forbidden by the drawing norm; blue/red is readable
# to deuteranopes because the opposing channel is lightness, not hue.)
NEG = C["div_neg"]      # #B2182B red
POS = C["div_pos"]      # #2166AC blue
MIX = C["vanilla_lt"]   # light grey
ZERO = C["vanilla"]     # mid grey

# light -> dark tints for magnitude within a verdict
def _tint(hexcol, frac):
    """Lighten hexcol toward white by frac in [0,1]."""
    r = int(hexcol[1:3], 16); g = int(hexcol[3:5], 16); b = int(hexcol[5:7], 16)
    r = int(r + (255 - r) * frac); g = int(g + (255 - g) * frac)
    b = int(b + (255 - b) * frac)
    return f"#{r:02x}{g:02x}{b:02x}"

cmap = mpl.colors.ListedColormap([
    NEG,                       # negative
    _tint(NEG, 0.55),          # weak negative (mixed-negative)
    MIX,                       # mixed / near-zero
    ZERO,                      # zero
    _tint(POS, 0.55),          # weak positive
    POS,                       # positive
])
bounds = [-1.5, -0.8, -0.2, -0.05, 0.05, 0.4, 1.5]
norm = mpl.colors.BoundaryNorm(bounds, cmap.N)

# Build the color matrix
color_mat = np.zeros((3, 5))
for i in range(3):
    for j in range(5):
        v = VERDICT[i][j]
        if v == "positive":
            mag = min(abs(MEAN[i, j]) / 0.8, 1.0)
            color_mat[i, j] = 0.05 + 0.05 + mag * 0.30   # 0.10 .. 0.40
        elif v == "negative":
            color_mat[i, j] = -0.8
        elif v == "mixed":
            color_mat[i, j] = -0.08
        else:  # zero
            color_mat[i, j] = 0.0

im = ax.imshow(color_mat, cmap=cmap, norm=norm, aspect="auto", zorder=1)

# ======================== Cell text: mean +/- sd + verdict label =============
for i in range(3):
    for j in range(5):
        m, s = MEAN[i, j], SD[i, j]
        v = VERDICT[i][j]

        text_val = f"{m:+.2f}\n\u00b1{s:.2f}"
        ax.text(j, i - 0.16, text_val, ha="center", va="center",
                fontsize=7.0, color=C["ink"], weight="bold",
                linespacing=1.2)

        label_color = {"positive": POS, "negative": NEG,
                       "mixed": C["vanilla"], "zero": C["vanilla"]}[v]
        ax.text(j, i + 0.28, v, ha="center", va="center",
                fontsize=6.0, color=label_color, style="italic")

# ======================== Axes and labels ==================================
ax.set_xticks(np.arange(5))
ax.set_xticklabels(COLS, fontsize=6.3, linespacing=1.2)
ax.set_yticks(np.arange(3))
ax.set_yticklabels(ROWS, fontsize=6.3, linespacing=1.2)
ax.tick_params(length=0, pad=4)

# Grid lines between cells
for i in range(1, 3):
    ax.axhline(i - 0.5, color="white", lw=2.0, zorder=2)
for j in range(1, 5):
    ax.axvline(j - 0.5, color="white", lw=2.0, zorder=2)

ax.set_xlim(-0.5, 4.5)
ax.set_ylim(2.5, -0.5)

# Difficulty annotation below x-axis
ax.text(2.0, 3.15, "tracking difficulty:  easy $\\longrightarrow$ hard",
        ha="center", va="top", fontsize=6.0, color=C["vanilla"],
        style="italic", transform=ax.transData)

# Title  (NOTE: a real newline, not the literal "\n" that the earlier build printed)
ax.set_title("No sequence has all three components positive (0/5):\n"
             "the necessary subset is regime-dependent",
             loc="center", fontsize=7.5, pad=12, linespacing=1.35)

# Legend annotation (top-right corner)
ax.text(4.5, -0.62, "$\\Delta$ ($+$ = removing it hurts)",
        ha="right", va="top", fontsize=6.0, color=C["vanilla"],
        style="italic", transform=ax.transData)

panel_label(ax, "", x=-0.08, y=1.02)

# Footnote: short, explicit line breaks (no wrap=True -- a single long
# fig.text line is not clipped and stretches the tight bbox, shrinking
# the whole figure when scaled to \textwidth).
fig.text(0.02, 0.015,
         "Each cell: mean $\\pm$ sd (3 seeds) shift in ATE (cm) when the component is removed.\n"
         "Positive = removing it hurts; negative = removing it helps; zero = within noise.\n"
         "Colour: blue = positive, red = negative, grey = neutral (colour-blind safe).\n"
         "Source: WP-A 120-run factorial.",
         fontsize=6.0, color=C["vanilla"], ha="left", va="bottom",
         linespacing=1.45, transform=fig.transFigure)

save(fig, "fig3_regime_split")
