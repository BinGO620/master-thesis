"""Fig. 4 (v3) - the gain is not attributable to the flow information alone (F2).

Core conclusion: with a byte-identical frozen flow budget, a naive p90
threshold mask is unstable (its mean ratio to vanilla crosses 1.0 on pt2,
0.90x worse) while our weighting improves on vanilla on 4/4 sequences with
every seed agreeing in sign, and beats the naive counterpart on 4/4.

Design (FIGURE_PLAN_v3.md):
- panel a: real per-seed dots + mean tick, log y, three arms on 4 held-out
  sequences; pt2 annotated as the decision cell;
- panel b: seed-wise log ATE ratio to vanilla - blue (ours) never crosses
  parity; orange (naive) straddles it on pt2 and balloon2.

All values computed from results/runs_remote_cache/WPB/WPB-CONFIRM run CSVs
(latest-run rule, 3 seeds per arm); means and half-ranges asserted against
the published Table 4.
"""
import csv
import glob

import numpy as np
import matplotlib.pyplot as plt

from _figstyle_v3 import C, TEXTWIDTH, apply_style, save

apply_style(font_size=6.8)

SEQ = ["pt1", "pt2", "mv_no_box2", "balloon2"]
ARMS = {"vanilla": "vanilla", "flowmask": "naive", "MRCS": "ours"}
BASE = "/data/monogs-ours/results/runs_remote_cache/WPB/WPB-CONFIRM"


def seed_ates(seq, arm):
    paths = sorted(glob.glob(f"{BASE}/{arm}_{seq}_*/tables/tracking_raw.csv"))
    assert len(paths) == 3, f"{arm}_{seq}: {len(paths)} seeds"
    out = []
    for p in paths:
        with open(p) as fh:
            out.append(float(list(csv.DictReader(fh))[-1]["ate_rmse_cm"]))
    return np.array(out)


D = {(s, a): seed_ates(s, a) for s in SEQ for a in ARMS}

# transcription guard: means and half-ranges must equal manuscript Table 4
_expect = {
    ("pt1", "vanilla"): (63.22, 10.65), ("pt2", "vanilla"): (45.37, 2.02),
    ("mv_no_box2", "vanilla"): (15.64, 14.14), ("balloon2", "vanilla"): (24.10, 0.56),
    ("pt1", "flowmask"): (51.41, 11.17), ("pt2", "flowmask"): (51.07, 11.09),
    ("mv_no_box2", "flowmask"): (6.23, 0.43), ("balloon2", "flowmask"): (23.30, 9.87),
    ("pt1", "MRCS"): (38.51, 2.51), ("pt2", "MRCS"): (9.09, 0.31),
    ("mv_no_box2", "MRCS"): (4.97, 0.29), ("balloon2", "MRCS"): (11.90, 1.85),
}
for (s, a), (m, e) in _expect.items():
    v = D[(s, a)]
    assert abs(v.mean() - m) < 0.01 and abs((v.max() - v.min()) / 2 - e) < 0.01, \
        f"{a}_{s}: {v.mean():.2f}+-{(v.max()-v.min())/2:.2f} != {m}+-{e}"

fig = plt.figure(figsize=(TEXTWIDTH, 4.3 / 2.54))
gs = fig.add_gridspec(1, 2, width_ratios=[1.15, 1.0], wspace=0.30,
                      left=0.075, right=0.988, top=0.92, bottom=0.175)
axa = fig.add_subplot(gs[0, 0])
axb = fig.add_subplot(gs[0, 1])

# --------------------------- panel a: absolute ATE --------------------------
x = np.arange(len(SEQ))
jitter = np.array([-0.045, 0.0, +0.045])
for xoff, key, color, name in [
        (-0.24, "vanilla", C["vanilla"], "vanilla (no flow)"),
        (0.0, "flowmask", C["naive"], "naive p90 threshold, same flow"),
        (+0.24, "MRCS", C["combined"], "our weighting, same flow")]:
    for i, seq in enumerate(SEQ):
        v = D[(seq, key)]
        axa.plot(i + xoff + jitter, v, "o", ms=2.2, color=color, alpha=0.55,
                 zorder=2)
        m = v.mean()
        axa.plot([i + xoff - 0.11, i + xoff + 0.11], [m, m], "-", lw=1.6,
                 color=color, zorder=3)

axa.set_yscale("log")
axa.set_ylim(3, 170)
axa.set_xticks(x)
axa.set_xticklabels(SEQ)
axa.set_xlim(-0.55, 3.55)
axa.set_ylabel("ATE RMSE (cm, 3 seeds)", fontsize=6.0)
axa.grid(axis="y", lw=0.4, alpha=0.6)
axa.tick_params(labelsize=5.8)

# decision-cell annotation on pt2
axa.annotate("naive: mean 0.90\u00d7 vanilla\n(pt2, worse)",
             xy=(1.0, 51.07), xytext=(1.42, 120),
             fontsize=5.2, color="#8A4E17", ha="left", va="center",
             arrowprops=dict(arrowstyle="-", lw=0.6, color="#8A4E17",
                             shrinkA=1, shrinkB=2))

# ----------------- panel b: seed-wise log ratio to vanilla -----------------
for i, seq in enumerate(SEQ):
    van = D[(seq, "vanilla")]
    for xoff, key, color in [(-0.13, "MRCS", C["combined"]),
                             (+0.13, "flowmask", C["naive"])]:
        v = D[(seq, key)]
        lr = np.log(v / van)
        axb.plot(i + xoff + jitter, lr, "o", ms=2.4, color=color, alpha=0.7,
                 zorder=3)
        m = lr.mean()
        axb.plot([i + xoff - 0.09, i + xoff + 0.09], [m, m], "-", lw=1.4,
                 color=color, zorder=4)

axb.axhline(0.0, color=C["ink"], lw=0.8)
axb.text(3.48, 0.05, "parity", fontsize=5.0, color="#707070", ha="right")

axb.set_xticks(x)
axb.set_xticklabels(SEQ)
axb.set_xlim(-0.55, 3.55)
axb.set_ylim(-2.45, 1.05)
axb.set_ylabel("log ATE ratio to vanilla", fontsize=6.0)
axb.tick_params(labelsize=5.8)
axb.grid(axis="y", lw=0.4, alpha=0.6)

# direct labels
axb.text(-0.48, 0.62, "ours \u00f7 vanilla", fontsize=5.6, color=C["combined"],
         fontweight="bold", ha="left")
axb.text(-0.48, 0.38, "12/12 seeds < 0", fontsize=5.2, color=C["combined"],
         ha="left")
axb.text(2.28, -2.02, "naive \u00f7 vanilla:", fontsize=5.6, color=C["naive"],
         fontweight="bold", ha="left")
axb.text(2.28, -2.28, "crosses parity on pt2", fontsize=5.2, color=C["naive"],
         ha="left")

# panel letters
axa.text(-0.09, 1.10, "a", transform=axa.transAxes, fontsize=8,
         fontweight="bold", color=C["ink"])
axb.text(-0.09, 1.10, "b", transform=axb.transAxes, fontsize=8,
         fontweight="bold", color=C["ink"])

# manual legend in the empty upper-left of panel a (no overlapping data)
for y, color, name in [(148, C["vanilla"], "vanilla (no flow)"),
                       (114, C["naive"], "naive p90, same flow"),
                       (86, C["combined"], "ours, same flow")]:
    axa.plot([-0.46, -0.32], [y, y], "-", lw=2.0, color=color)
    axa.text(-0.26, y, name, fontsize=5.4, color=C["ink"], ha="left",
             va="center")

save(fig, "fig5_controlled_v3")
