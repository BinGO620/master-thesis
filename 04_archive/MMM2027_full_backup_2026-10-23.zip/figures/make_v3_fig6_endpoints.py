"""Fig. 5 (main paper) - one intervention, three pose-side endpoints, opposite signs.

Compact single-panel rebuild of the v2 fig6 hero panel, restyled to the v3
direction pair (_figstyle_v3: orange = endpoint moved worse, blue = moved
better/lower; no red anywhere). Placed as a bottom float on the final content
page, so it must stay short: one row of three horizontal bars, each annotated
with its raw shift and its multiple of its own re-run noise floor - the only
scale on which the three quantities are comparable.

Source: results/evidence (exp37 ATE endpoint, exp38 coherent-amplitude
endpoint, both on balloon; numbers identical to SI S7 and Sec. 5.6).
"""
import numpy as np
import matplotlib.pyplot as plt

from _figstyle_v3 import C, TEXTWIDTH, apply_style, save

apply_style(font_size=6.5)

# endpoint label, shift, own re-run noise floor, unit, annotation, direction word.
# Row labels stay single-line: the figure is rendered at 0.60\textwidth, so any
# two-line label costs vertical mass the bottom-float slot does not have.
EP = [
    ("per-frame penalty", +0.0806, 0.0662,
     "+0.0806\n(1.22$\\times$ floor)", "worse"),
    ("coherent amplitude", -0.0248, 0.0180,
     "$-$0.0248 cm  (1.38$\\times$)", "lower"),
    ("full-trajectory ATE", -1.4157, 0.3519,
     "$-$1.42 cm  (4.0$\\times$)", "better"),
]
floor = np.array([e[2] for e in EP])
margin = np.abs([e[1] for e in EP]) / floor   # 1.22x, 1.38x, 4.02x

# Sized for native display at 0.60\textwidth, so nominal font sizes are the
# printed ones (an earlier 0.80-wide build printed at 0.54/0.80 = 68% and the
# 6 pt annotations became unreadable).
fig = plt.figure(figsize=(TEXTWIDTH * 0.60, 2.25 / 2.54))
ax = fig.add_axes([0.245, 0.30, 0.75, 0.56])

# Signed axis: left of zero = the endpoint moved worse, right = better/lower.
# "Better" is endpoint-specific, so the sign is set per row, not per value.
signed = np.array([-margin[0], +margin[1], +margin[2]])
cols = [C["bad"], C["good"], C["good"]]

ax.axvspan(-3.4, 0, color=C["bad"], alpha=0.05, lw=0, zorder=0)
ax.axvline(0, color=C["ink"], lw=0.8, zorder=4)
for m in (-1, 1):
    ax.axvline(m, color=C["vanilla"], lw=0.6, ls=(0, (2.5, 1.5)), zorder=3)

y = np.arange(len(EP))[::-1]
ax.barh(y, signed, height=0.50, color=cols, lw=0, zorder=2)

# Annotation above each bar's outer end; the long ATE bar carries its label
# inside (white) so the axis stays readable. Direction word sits below the
# same end, in the bar's colour.
for yy, s, e in zip(y, signed, EP):
    # The long ATE bar carries its label inside (white, centred); the other
    # two annotate just past their outer end, at mid-bar height.
    if abs(s) > 3.2:
        ax.text(s - 0.14, yy, e[3], fontsize=6.2, va="center", ha="right",
                color="white", zorder=5)
    elif s < 0:
        # left of the bar tip, wrapped to two lines: the right-running label
        # used to cross the +1 floor line through its final digit
        ax.text(s - 0.14, yy, e[3], fontsize=6.0, va="center",
                ha="right", color=C["ink"], zorder=5, linespacing=1.2)
    else:
        ax.text(max(s, 0.0) + 0.14, yy, e[3], fontsize=6.2, va="center",
                ha="left", color=C["ink"], zorder=5)

# Zone words at the top, clear of the tick labels.
ax.text(-1.0, 2.86, "worse", fontsize=5.8, style="italic", color=C["bad"],
        ha="center", va="bottom")
ax.text(1.0, 2.86, "better", fontsize=5.8, style="italic", color=C["good"],
        ha="center", va="bottom")

ax.set_yticks(y)
ax.set_yticklabels([e[0] for e in EP], fontsize=6.2)
ax.set_ylim(-0.70, 2.55)
ax.set_xlim(-3.4, 5.0)
ax.set_xticks([-1, 0, 1, 2, 3, 4, 5])
ax.set_xlabel("shift in units of the endpoint's re-run noise floor",
              fontsize=6.2, labelpad=1.5)
ax.tick_params(axis="y", length=0, pad=2)
ax.tick_params(axis="x", labelsize=5.8)

save(fig, "fig6_endpoints_v3")
