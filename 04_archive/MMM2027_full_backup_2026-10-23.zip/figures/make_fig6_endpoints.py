"""Fig. 6 - one intervention, three pose-side endpoints, opposite signs.

Core conclusion: widening the share of suppressed pixels makes per-frame tracking
error worse while making the full trajectory better, and the directly measured
intermediate quantity - the coherent, drift-contributing component - explains why
by falling; so a claim that pose estimation improved is not well formed until the
endpoint is named.

Archetype: quantitative grid. Panel (a) is the hero: each endpoint's shift in
units of its own re-run noise floor, which is the only scale on which three
different quantities can be compared. Panel (b) states the mechanism as a chain
and (c) gives the honest cross-sequence check that did not reach the floor.

Source: results/evidence (exp37 ATE endpoint, exp38 coherent-amplitude endpoint
and the f3_wk_xyz cross-sequence check).
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

from _figstyle import C, TEXTWIDTH, apply_style, panel_label, save

apply_style(font_size=6.8)

# ------------------------------------------------------------------- data ----
# endpoint, shift, own noise floor, unit, direction word
EP = [
    ("per-frame\ndynamic penalty", +0.0806, 0.0662, "", "worse"),
    ("coherent amplitude\non high-dynamic frames", -0.0248, 0.0180, " cm", "lower"),
    ("full-trajectory\nATE", -1.4157, 0.3519, " cm", "better"),
]
labels = [e[0] for e in EP]
shift  = np.array([e[1] for e in EP])
floor  = np.array([e[2] for e in EP])
margin = np.abs(shift) / floor          # 1.22x, 1.38x, 4.02x

fig = plt.figure(figsize=(TEXTWIDTH, 7.0 / 2.54))
gs = fig.add_gridspec(2, 2, width_ratios=[1.0, 0.62], height_ratios=[1.0, 0.50],
                      wspace=0.56, hspace=0.95,
                      left=0.185, right=0.985, top=0.91, bottom=0.245)
axa = fig.add_subplot(gs[:, 0])
axb = fig.add_subplot(gs[0, 1])
axc = fig.add_subplot(gs[1, 1])

# Preserve panel a and open a clearer gutter before the two supporting panels.
for axis in (axb, axc):
    pos = axis.get_position()
    axis.set_position([pos.x0 + 0.025, pos.y0, pos.width, pos.height])

# ------------------------- panel a: shifts in units of each endpoint's floor --
y = np.arange(len(EP))[::-1]
# Signed margin: left of zero = the endpoint got worse, right = it got better.
# "Better" is endpoint-specific, so the sign is set from the direction word.
signed = np.array([-margin[0], +margin[1], +margin[2]])
cols = [C["down"], C["div_pos"], C["div_pos"]]

axa.axvspan(-5.2, 0, color=C["down"], alpha=0.05, lw=0, zorder=0)
axa.axvline(0, color=C["ink"], lw=0.8, zorder=4)
for m in (-1, 1):
    axa.axvline(m, color=C["vanilla"], lw=0.6, ls=(0, (2.5, 1.5)), zorder=3)

axa.barh(y, signed, height=0.42, color=cols, lw=0, zorder=2)
# Every value label is placed to the RIGHT of zero regardless of the bar's sign.
# The negative bar is short and its outer edge sits close to the y tick labels,
# so mirroring the label outward would collide with them; anchoring all three
# labels on the same side also makes the three magnitudes easy to compare.
for i, (yy, s, mg, e) in enumerate(zip(y, signed, margin, EP)):
    txt = f"{e[1]:+.4f}{e[3]}   ({mg:.2f}$\\times$ floor)"
    xt = (max(s, 0.0) + 0.18) if s > 0 else 0.18
    axa.text(xt, yy + 0.055, txt, fontsize=5.6, va="bottom", ha="left",
             color=C["ink"])
    axa.text(xt, yy - 0.075, e[4], fontsize=5.4, va="top", ha="left",
             color=cols[i], style="italic")

axa.set_yticks(y)
axa.set_yticklabels(labels, fontsize=6.0, linespacing=1.25)
axa.set_ylim(-0.62, len(EP) - 0.38)
axa.set_xlim(-2.2, 6.4)
axa.set_xlabel("shift in units of that endpoint's own re-run noise floor")
axa.tick_params(axis="y", length=0)
axa.spines["left"].set_visible(False)
axa.grid(axis="x", alpha=0.4, zorder=1)
axa.set_axisbelow(True)
axa.text(-1.1, len(EP) - 0.52, "worse", fontsize=5.4, color=C["down"],
         ha="center", va="bottom")
axa.text(1.1, len(EP) - 0.52, "better", fontsize=5.4, color=C["div_pos"],
         ha="center", va="bottom")
axa.text(1.14, -0.52, "$\\pm$1 = the floor itself", fontsize=5.0,
         color=C["vanilla"], ha="left", va="center")

panel_label(axa, "a", x=-0.315)
axa.set_title("One single-variable intervention, three endpoints",
              loc="left", fontsize=7, pad=6)

# --------------------------------------------- panel b: the mechanism chain --
axb.set_xlim(0, 1)
axb.set_ylim(0, 1)
axb.axis("off")
steps = [
    (0.90, "suppress a larger share\nof dynamic pixels", C["ink"]),
    (0.60, "each frame noisier\nbut less systematically pulled", C["down"]),
    (0.30, "noise averages out along the path,\nbias would have accumulated", C["div_pos"]),
    (0.04, "trajectory improves", C["div_pos"]),
]
for i, (yy, txt, col) in enumerate(steps):
    axb.text(0.5, yy, txt, fontsize=5.5, ha="center", va="center", color=col,
             linespacing=1.35)
    if i < len(steps) - 1:
        nxt = steps[i + 1][0]
        axb.add_patch(FancyArrowPatch(
            (0.5, yy - 0.085), (0.5, nxt + 0.085),
            arrowstyle="-|>", mutation_scale=5.0, lw=0.7,
            color=C["vanilla"], shrinkA=0, shrinkB=0))
panel_label(axb, "b", x=-0.09, y=1.00)
axb.set_title("Variance$-$bias reading", loc="left", fontsize=7, pad=6)

# ------------------------------- panel c: the cross-sequence check, honest ---
seqs = ["balloon\n(decomposable)", "f3_wk_xyz\n(cross-check)"]
eff  = np.array([4.02, 0.93])         # ATE shift / that sequence's own floor
ccol = [C["div_pos"], C["vanilla_lt"]]
xx = np.arange(2)
axc.bar(xx, eff, width=0.5, color=ccol, lw=0, zorder=2)
axc.axhline(1.0, color=C["ink"], lw=0.7, ls=(0, (2.5, 1.5)), zorder=3)
axc.set_xticks(xx)
axc.set_xticklabels(seqs, fontsize=5.0, linespacing=1.25)
axc.set_ylabel("ATE shift\n/ floor", fontsize=5.8, linespacing=1.3)
axc.set_ylim(0, 5.4)
axc.set_yticks([0, 2, 4])
axc.set_xlim(-0.55, 1.55)
axc.grid(axis="y", alpha=0.4, zorder=0)
axc.set_axisbelow(True)
# Two annotations, two heights: the floor line is labelled at the left, the
# below-floor verdict sits directly over its own bar.
axc.text(-0.50, 1.16, "noise floor", fontsize=5.0, color=C["ink"],
         va="bottom", ha="left")
axc.text(1.0, eff[1] + 0.30, "below floor:\nindistinguishable", fontsize=5.0,
         color=C["vanilla"], ha="center", va="bottom", linespacing=1.3)
panel_label(axc, "c", x=-0.12, y=1.02)


save(fig, "fig6_endpoints")
