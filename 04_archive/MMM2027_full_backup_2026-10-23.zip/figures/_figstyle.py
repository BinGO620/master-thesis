"""Shared publication style for the MRCS manuscript figures.

One palette for the whole paper: a neutral family for the baseline, a signal
family for our two arms, and one accent for prior work. Colours are assigned by
ROLE, not by aesthetics, so the same method keeps the same colour in every panel.

Every figure in this directory imports from here; nothing sets its own rcParams.
"""
import matplotlib as mpl
import matplotlib.pyplot as plt

# ---------------------------------------------------------------- palette ----
# Role -> colour. Fixed across all panels of the paper.
C = {
    # baseline / unmodified backbone: neutral, deliberately quiet
    "vanilla":    "#8C8C8C",
    "vanilla_lt": "#D8D8D8",
    # our two configurations: one hue, two values (same family = same system)
    "maskfree":   "#3775BA",
    "combined":   "#0F4D92",
    # the controlled counterpart consuming the same flow (warm = "not ours")
    "naive":      "#C97B3E",
    # prior work reference line
    "prior":      "#9A4D8E",
    # directional cues, used ONLY for gain/loss semantics
    "up":         "#2E7D32",
    "down":       "#C62828",
    # structural greys
    "ink":        "#272727",
    "rule":       "#BFBFBF",
    "panel_bg":   "#F7F7F7",
    # diverging map for the regime figure (colour-blind safe, no red/green pair)
    "div_neg":    "#B2182B",
    "div_mid":    "#F7F7F7",
    "div_pos":    "#2166AC",
}

# LNCS text width is 12.2 cm; convert once here so no figure hard-codes inches.
CM = 1 / 2.54
TEXTWIDTH = 12.2 * CM


def apply_style(font_size=7):
    """Nature-style rcParams. Call once per script before creating figures."""
    # MANDATORY: keeps SVG text editable rather than converting glyphs to paths
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
    plt.rcParams["svg.fonttype"] = "none"
    mpl.rcParams.update({
        "pdf.fonttype": 42,          # editable TrueType in PDF
        "font.size": font_size,
        "axes.labelsize": font_size,
        "axes.titlesize": font_size,
        "xtick.labelsize": font_size - 0.5,
        "ytick.labelsize": font_size - 0.5,
        "legend.fontsize": font_size - 0.5,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.6,
        "axes.edgecolor": C["ink"],
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 2.2,
        "ytick.major.size": 2.2,
        "legend.frameon": False,
        "grid.color": C["rule"],
        "grid.linewidth": 0.4,
        "lines.linewidth": 1.0,
        "patch.linewidth": 0.5,
    })


def panel_label(ax, label, x=-0.055, y=1.04, size=8):
    """Nature-style bold panel letter at the top-left of an axes."""
    ax.text(x, y, label, transform=ax.transAxes, fontsize=size,
            fontweight="bold", color=C["ink"], ha="left", va="bottom")


def save(fig, stem, dpi=600):
    """Export the three formats the manuscript build and revision cycle need."""
    fig.savefig(f"{stem}.pdf", bbox_inches="tight", pad_inches=0.01)
    fig.savefig(f"{stem}.svg", bbox_inches="tight", pad_inches=0.01)
    fig.savefig(f"{stem}.png", dpi=dpi, bbox_inches="tight", pad_inches=0.01)
    print(f"wrote {stem}.{{pdf,svg,png}}")
