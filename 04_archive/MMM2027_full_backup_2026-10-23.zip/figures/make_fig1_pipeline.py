"""Fig. 1 - MRCS pipeline: where the four components plug into MonoGS.

Core conclusion: MRCS adds four components to the MonoGS backbone - robust
reweighting (R) acts on pose tracking, dense keyframing (K) on the keyframe
gate, lineage lifecycle (D) on the mapping backend - and the reliability
signal (L) is the fourth component, consumed at exactly two sites: the
pose-solve residual (alongside R) and candidate confirmation in the lifecycle
(alongside D). The optional semantic mask is omitted (Sec. 3.6).
"""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

from _figstyle import C, TEXTWIDTH, apply_style, save

apply_style(font_size=7)

fig = plt.figure(figsize=(TEXTWIDTH, 6.2 / 2.54))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 12)
ax.set_ylim(0, 5)
ax.axis("off")

# ========================== Top row: MonoGS backbone =======================
backbone = [
    (0.5, 3.8, "frame $t$", 1.2, 0.7, C["vanilla"]),
    (2.0, 3.8, "pose solve", 1.4, 0.7, C["vanilla"]),
    (3.8, 3.8, "keyframe\ngate", 1.4, 0.7, C["vanilla"]),
    (5.6, 3.8, "window BA", 1.4, 0.7, C["vanilla"]),
    (7.4, 3.8, "map", 1.0, 0.7, C["vanilla"]),
]

for x, y, label, w, h, color in backbone:
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.06",
        facecolor="white", edgecolor=color, lw=1.2, zorder=2))
    ax.text(x + w/2, y + h/2, label, ha="center", va="center",
            fontsize=6.5, color=C["ink"], linespacing=1.2)

# Backbone arrows
backbone_arrows = [
    (1.76, 4.15, 1.94, 4.15),  # frame -> pose
    (3.46, 4.15, 3.74, 4.15),  # pose -> gate
    (5.26, 4.15, 5.54, 4.15),  # gate -> BA
    (7.06, 4.15, 7.34, 4.15),  # BA -> map
]
for x1, y1, x2, y2 in backbone_arrows:
    ax.add_patch(FancyArrowPatch(
        (x1, y1), (x2, y2), arrowstyle="-", mutation_scale=6,
        lw=1.0, color=C["rule"], zorder=1, shrinkA=0, shrinkB=0))

# ========================== Bottom row: MRCS components ====================
components = [
    (1.95, 2.2, "R\nrobust\nreweighting", "residual weight", 1.5, 0.85, C["maskfree"]),
    (3.75, 2.2, "K\ndense\nkeyframing", "", 1.5, 0.85, C["maskfree"]),
    (5.55, 2.2, "D\nlineage\nlifecycle", "confirm / delete", 1.5, 0.85, C["maskfree"]),
]

for x, y, label, detail, w, h, color in components:
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.08",
        facecolor="#D6EAF8", edgecolor=color, lw=1.4, zorder=2))
    main_y = y + h/2 + (0.09 if detail else 0.0)
    ax.text(x + w/2, main_y, label, ha="center", va="center",
            fontsize=6.0, color=C["ink"], linespacing=1.08, weight="bold")
    if detail:
        ax.text(x + w/2, y + 0.10, detail, ha="center", va="bottom",
                fontsize=5.0, color=C["combined"], style="italic")

# Component -> backbone arrows
component_arrows = [
    (2.70, 3.13, 2.70, 3.74),  # R -> pose solve
    (4.50, 3.13, 4.50, 3.74),  # K -> keyframe gate
    (6.30, 3.13, 6.30, 3.74),  # D -> window BA
]
for x1, y1, x2, y2 in component_arrows:
    ax.add_patch(FancyArrowPatch(
        (x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=7,
        lw=1.2, color=C["combined"], zorder=3,
        shrinkA=0, shrinkB=0))

# ========================== Reliability: fourth component ==================
# L is a component in its own right, consumed at exactly TWO sites:
#   site 1: the pose-solve residual (alongside R)
#   site 2: candidate confirmation in the lifecycle (alongside D)
# NOT at the keyframe gate (that path belongs to the optional semantic mask).
ax.add_patch(FancyBboxPatch(
    (1.2, 0.4), 6.6, 0.8, boxstyle="round,pad=0.1",
    facecolor="#E8F5E9", edgecolor=C["up"], lw=1.5, zorder=2))
ax.text(4.5, 0.8, "L  reliability signal   "
        "$s = (1 - e_{\\mathrm{flow}})(1 - vg)$",
        ha="center", va="center", fontsize=6.5, color=C["ink"],
        weight="bold")
ax.text(4.5, 0.54, "computed once per frame, then frozen",
        ha="center", va="center", fontsize=5.0, color=C["vanilla"],
        style="italic")
# Reliability's two consumption arrows: site 1 enters the pose solve (with R),
# site 2 enters the lifecycle (with D). Each rises vertically from the signal
# box to the corresponding component box.
signal_boundary_y = 1.30
component_boundary_y = 2.12
reliability_targets = [(2.70, "site 1"), (6.30, "site 2")]
for cx, label in reliability_targets:
    ax.add_patch(FancyArrowPatch(
        (cx, signal_boundary_y), (cx, component_boundary_y),
        arrowstyle="-|>", mutation_scale=6,
        lw=1.1, color=C["up"], alpha=0.82, zorder=4,
        shrinkA=0, shrinkB=0))
    ax.text(cx, 1.70, label, ha="center", va="center", fontsize=5.0,
            color=C["up"], style="italic")

# Title
ax.text(4.5, 4.85, "MRCS adds four components to MonoGS; the reliability "
        "signal is consumed at two sites",
        ha="center", va="bottom", fontsize=7.8, color=C["ink"],
        weight="bold")

save(fig, "fig1_pipeline")
