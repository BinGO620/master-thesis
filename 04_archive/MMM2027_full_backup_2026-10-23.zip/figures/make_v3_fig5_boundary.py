"""Fig. 5 (v3) - where the mask-free configuration stops being sufficient.

Core conclusion: the mask-free arm's own per-frame RPE separates the
mask-redundant from the mask-necessary sequences without overlap (0.222-1.572
vs 1.717-2.980 cm/frame; 17/17 decided), and the pre-registered midpoint
tau = 1.6445 held on 4/4 decided held-out sequences.

Design (FIGURE_PLAN_v3.md): single scatter panel; blue = mask redundant,
orange = mask necessary, grey triangle = the ambiguous-band exclusion;
held-out check points drawn as black-edged squares; the separating band and
the N = 1.5 / 1.2 thresholds as reference lines. Labels on the points that
carry the argument in the text.

All 18 development points from results/evidence/rpe_stratification_rule_test.md;
the 5 held-out points from results/evidence/rpe_boundary_heldout.md.
"""
import numpy as np
import matplotlib.pyplot as plt

from _figstyle_v3 import C, TEXTWIDTH, apply_style, save

apply_style(font_size=6.8)

# sequence, mask-free RPE (cm/frame), N, group
DEV = [
    ("f2_xyz",     0.222, 0.99, "redundant"),
    ("f3_office",  0.456, 1.02, "redundant"),
    ("f2_person",  0.498, 0.92, "redundant"),
    ("f1_desk",    0.847, 1.07, "redundant"),
    ("f3_st_xyz",  0.910, 0.57, "redundant"),
    ("mv_no_box",  1.210, 1.17, "redundant"),
    ("f3_st_rpy",  1.465, 1.02, "redundant"),
    ("mv_no_box2", 1.521, 1.09, "redundant"),
    ("pt2",        1.572, 0.89, "redundant"),
    ("f3_st_hf",   1.041, 1.21, "ambiguous"),
    ("f3_wk_xyz",  1.717, 8.76, "necessary"),
    ("balloon",    2.028, 3.96, "necessary"),
    ("f3_wk_rpy",  2.264, 3.41, "necessary"),
    ("f3_wk_hf",   2.327, 5.27, "necessary"),
    ("crowd",      2.643, 15.24, "necessary"),
    ("balloon2",   2.730, 1.92, "necessary"),
    ("pt1",        2.894, 2.73, "necessary"),
    ("crowd2",     2.980, 20.95, "necessary"),
]
# held-out check: sequence, RPE, N, verdict
HELD = [
    ("obox2",       2.068, 1.62, "necessary"),
    ("synchronous", 2.424, 138.97, "necessary"),
    ("f2_desk_wp",  0.602, 0.94, "redundant"),
    ("f3_loh",      0.456, 1.09, "redundant"),
    ("obox",        2.117, 1.42, "in-band"),
]
TAU = 1.6445
BAND = (1.572, 1.717)

# transcription guards
assert len([r for r in DEV if r[3] == "redundant"]) == 9
assert len([r for r in DEV if r[3] == "necessary"]) == 8
assert abs([r for r in DEV if r[0] == "pt2"][0][1] - 1.572) < 1e-6
assert abs([r for r in DEV if r[0] == "f3_wk_xyz"][0][2] - 8.76) < 1e-6

fig = plt.figure(figsize=(TEXTWIDTH, 4.6 / 2.54))
ax = fig.add_axes([0.085, 0.145, 0.895, 0.83])

# separating band + tau
ax.axvspan(BAND[0], BAND[1], color="#EDEAE8", zorder=0)
ax.axvline(TAU, color="#8A8A8A", lw=0.8, ls="--", zorder=1)
ax.text(TAU, 148, r"$\tau$ = 1.6445", fontsize=5.4, color="#6E6E6E",
        ha="center", va="bottom")
ax.text(sum(BAND) / 2, 42, "separating\nband", fontsize=5.0, color="#6E6E6E",
        ha="center", va="center", linespacing=1.1)

# N thresholds
for y, lab, va in [(1.5, "N = 1.5", "bottom"),
                   (1.2, "N = 1.2", "top")]:
    ax.axhline(y, color=C["rule"], lw=0.6, ls=":", zorder=1)
    ax.text(0.988, y * (1.06 if va == "bottom" else 0.94), lab, fontsize=5.0,
            color="#8A8A8A", transform=ax.get_yaxis_transform(), ha="right",
            va=va)

# dev points
for grp, color, marker in [("redundant", C["redundant"], "o"),
                           ("necessary", C["necessary"], "D")]:
    xs = [r[1] for r in DEV if r[3] == grp]
    ys = [r[2] for r in DEV if r[3] == grp]
    ax.plot(xs, ys, marker, ms=4.0, color=color, alpha=0.9, ls="none",
            zorder=3, label=f"mask {grp} ({len(xs)})")
# ambiguous exclusion
amb = [r for r in DEV if r[3] == "ambiguous"][0]
ax.plot(amb[1], amb[2], "^", ms=4.4, color="#8A8A8A", ls="none", zorder=3,
        label="ambiguous band, excluded (1)")

# held-out squares
hx = {"necessary": [], "redundant": [], "in-band": []}
for seq, rpe, n, verdict in HELD:
    col = {"necessary": C["necessary"], "redundant": C["redundant"],
           "in-band": "#8A8A8A"}[verdict]
    ax.plot(rpe, n, "s", ms=4.4, markerfacecolor=col, markeredgecolor=C["ink"],
            markeredgewidth=0.8, linestyle="none", zorder=4,
            label="held-out check (5)" if seq == "obox2" else None)
    if seq == "synchronous":
        ax.annotate("synchronous (N=139)", xy=(rpe, n * 0.93),
                    xytext=(1.80, 60), fontsize=5.0, color="#6E6E6E",
                    arrowprops=dict(arrowstyle="-", lw=0.5, color="#9A9A9A",
                                    shrinkA=1, shrinkB=2.5))

# direct labels for the points the text leans on
for seq, dx, dy, ha in [("crowd2", -0.05, 1.15, "right"),
                        ("crowd", -0.05, 1.12, "right"),
                        ("pt1", -0.05, 0.78, "right"),
                        ("balloon", -0.05, 0.80, "right"),
                        ("f3_wk_xyz", +0.05, 1.35, "left"),
                        ("pt2", 0.0, 0.80, "center"),
                        ("f3_st_hf", 0.0, 0.72, "center")]:
    r = [q for q in DEV if q[0] == seq][0]
    col = {"redundant": C["redundant"], "necessary": C["necessary"],
           "ambiguous": "#8A8A8A"}[r[3]]
    ax.text(r[1] + dx, r[2] * dy, seq, fontsize=5.0, color=col, ha=ha,
            va="center", zorder=5)

ax.set_yscale("log")
ax.set_ylim(0.4, 240)
ax.set_xlim(0.0, 3.25)
ax.set_xlabel("mask-free arm's own RPE (cm/frame)", fontsize=6.2)
ax.set_ylabel("mask necessity  $N$", fontsize=6.2)
ax.tick_params(labelsize=5.8)
ax.legend(fontsize=5.2, loc="upper left", handlelength=1.2, borderaxespad=0.2)

save(fig, "fig7_boundary_v3")
