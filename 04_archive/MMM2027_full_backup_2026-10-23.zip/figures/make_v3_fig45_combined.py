"""Fig. 5 (v3 combined) - two controlled-comparison claims in one figure.

Panels (a,b): the flow-budget counterpart (F2). Panel (c): the RPE boundary
separation. One float instead of two saves a page-fraction of overhead.
"""
import csv, glob

import numpy as np
import matplotlib.pyplot as plt

from _figstyle_v3 import C, TEXTWIDTH, apply_style, save

apply_style(font_size=6.8)

SEQ = ["pt1", "pt2", "mv_no_box2", "balloon2"]
ARMS = {"vanilla": "vanilla", "flowmask": "naive", "MRCS": "ours"}
BASE = "/data/monogs-ours/results/runs_remote_cache/WPB/WPB-CONFIRM"


def seed_ates(seq, arm):
    paths = sorted(glob.glob(f"{BASE}/{arm}_{seq}_*/tables/tracking_raw.csv"))
    assert len(paths) == 3
    out = []
    for p in paths:
        with open(p) as fh:
            out.append(float(list(csv.DictReader(fh))[-1]["ate_rmse_cm"]))
    return np.array(out)


D = {(s, a): seed_ates(s, a) for s in SEQ for a in ARMS}

# boundary data
DEV = [
    ("f2_xyz", 0.222, 0.99, "redundant"), ("f3_office", 0.456, 1.02, "redundant"),
    ("f2_person", 0.498, 0.92, "redundant"), ("f1_desk", 0.847, 1.07, "redundant"),
    ("f3_st_xyz", 0.910, 0.57, "redundant"), ("mv_no_box", 1.210, 1.17, "redundant"),
    ("f3_st_rpy", 1.465, 1.02, "redundant"), ("mv_no_box2", 1.521, 1.09, "redundant"),
    ("pt2", 1.572, 0.89, "redundant"), ("f3_st_hf", 1.041, 1.21, "ambiguous"),
    ("f3_wk_xyz", 1.717, 8.76, "necessary"), ("balloon", 2.028, 3.96, "necessary"),
    ("f3_wk_rpy", 2.264, 3.41, "necessary"), ("f3_wk_hf", 2.327, 5.27, "necessary"),
    ("crowd", 2.643, 15.24, "necessary"), ("balloon2", 2.730, 1.92, "necessary"),
    ("pt1", 2.894, 2.73, "necessary"), ("crowd2", 2.980, 20.95, "necessary"),
]
HELD = [("obox2", 2.068, 1.62, "necessary"), ("synchronous", 2.424, 138.97, "necessary"),
        ("f2_desk_wp", 0.602, 0.94, "redundant"), ("f3_loh", 0.456, 1.09, "redundant"),
        ("obox", 2.117, 1.42, "in-band")]
TAU, BAND = 1.6445, (1.572, 1.717)

fig = plt.figure(figsize=(TEXTWIDTH, 3.85 / 2.54))
gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.05],
                      left=0.075, right=0.985, top=0.94, bottom=0.115,
                      hspace=0.55, wspace=0.30)
axa = fig.add_subplot(gs[0, 0])
axb = fig.add_subplot(gs[0, 1])
axc = fig.add_subplot(gs[1, :])

# ---- panels a,b: flow budget (from make_v3_fig4_controlled) ----
x = np.arange(len(SEQ))
jitter = np.array([-0.045, 0.0, +0.045])
for xoff, key, color, name in [
        (-0.24, "vanilla", C["vanilla"], "vanilla (no flow)"),
        (0.0, "flowmask", C["naive"], "naive p90, same flow"),
        (+0.24, "MRCS", C["combined"], "ours, same flow")]:
    for i, seq in enumerate(SEQ):
        v = D[(seq, key)]
        axa.plot(i + xoff + jitter, v, "o", ms=2.0, color=color, alpha=0.55, zorder=2)
        m = v.mean()
        axa.plot([i + xoff - 0.11, i + xoff + 0.11], [m, m], "-", lw=1.6,
                 color=color, zorder=3, label=name if i == 0 else None)
axa.set_yscale("log"); axa.set_ylim(3, 170)
axa.set_xticks(x); axa.set_xticklabels(SEQ)
axa.set_xlim(-0.55, 3.55)
axa.set_ylabel("ATE RMSE (cm)", fontsize=6.0)
axa.tick_params(labelsize=5.6)
axa.legend(fontsize=5.0, loc="lower left", handlelength=1.2, borderaxespad=0.2)
axa.annotate("naive: 1.13$\\times$ vanilla\non pt2 (worse)", xy=(1.0, 66),
             xytext=(1.0, 132), fontsize=5.0, color="#8A4E17",
             ha="center", va="bottom",
             arrowprops=dict(arrowstyle="-", lw=0.5, color="#8A4E17", shrinkA=1, shrinkB=2))

for i, seq in enumerate(SEQ):
    van = D[(seq, "vanilla")]
    for xoff, key, color in [(-0.13, "MRCS", C["combined"]),
                             (+0.13, "flowmask", C["naive"])]:
        v = D[(seq, key)]
        lr = np.log(v / van)
        axb.plot(i + xoff + jitter, lr, "o", ms=2.2, color=color, alpha=0.7, zorder=3)
        m = lr.mean()
        axb.plot([i + xoff - 0.09, i + xoff + 0.09], [m, m], "-", lw=1.4, color=color, zorder=4)
axb.axhline(0.0, color=C["ink"], lw=0.8)
axb.text(-0.48, 0.10, "parity", fontsize=5.0, color="#707070", ha="left", va="bottom")
axb.set_xticks(x); axb.set_xticklabels(SEQ)
axb.set_xlim(-0.55, 3.55); axb.set_ylim(-2.45, 1.05)
axb.set_ylabel("log ATE ratio to vanilla", fontsize=6.0)
axb.tick_params(labelsize=5.6)
axb.text(-0.48, 0.62, "ours $\\div$ vanilla: 12/12 seeds < 0", fontsize=5.2,
         color=C["combined"], ha="left")
axb.text(3.50, -2.38, "naive crosses parity on pt2 (mean)", fontsize=5.2,
         color=C["naive"], ha="right", va="bottom")

# ---- panel c: boundary separation (from make_v3_fig5_boundary) ----
axc.axvspan(BAND[0], BAND[1], color="#EDEAE8", zorder=0)
axc.axvline(TAU, color="#8A8A8A", lw=0.8, ls="--", zorder=1)
axc.text(TAU + 0.05, 148, r"$\tau$ = 1.6445", fontsize=5.2, color="#6E6E6E", ha="left", va="bottom")
for y, lab, va in [(1.5, "N = 1.5", "bottom"), (1.2, "N = 1.2", "top")]:
    axc.axhline(y, color=C["rule"], lw=0.6, ls=":", zorder=1)
    axc.text(0.988, y * (1.06 if va == "bottom" else 0.94), lab, fontsize=5.0,
             color="#8A8A8A", transform=axc.get_yaxis_transform(), ha="right", va=va)
for grp, color, marker in [("redundant", C["redundant"], "o"),
                           ("necessary", C["necessary"], "D")]:
    xs = [r[1] for r in DEV if r[3] == grp]
    ys = [r[2] for r in DEV if r[3] == grp]
    axc.plot(xs, ys, marker, ms=3.6, color=color, alpha=0.9, ls="none", zorder=3,
             label=f"mask {grp} ({len(xs)})")
amb = [r for r in DEV if r[3] == "ambiguous"][0]
axc.plot(amb[1], amb[2], "^", ms=4.0, color="#8A8A8A", ls="none", zorder=3,
         label="ambiguous, excluded (1)")
for seq, rpe, n, verdict in HELD:
    col = {"necessary": C["necessary"], "redundant": C["redundant"],
           "in-band": "#8A8A8A"}[verdict]
    axc.plot(rpe, n, "s", ms=4.0, markerfacecolor=col, markeredgecolor=C["ink"],
             markeredgewidth=0.8, linestyle="none", zorder=4,
             label="held-out check (5)" if seq == "obox2" else None)
    if seq == "synchronous":
        axc.annotate("synchronous (N=139)", xy=(rpe, n * 0.93), xytext=(1.80, 60),
                     fontsize=5.0, color="#6E6E6E",
                     arrowprops=dict(arrowstyle="-", lw=0.5, color="#9A9A9A",
                                     shrinkA=1, shrinkB=2.5))
for seq, dx, dy, ha in [("crowd2", -0.05, 1.15, "right"), ("crowd", -0.05, 1.12, "right"),
                        ("pt1", +0.07, 0.92, "left"), ("balloon", -0.05, 0.80, "right"),
                        ("f3_wk_xyz", +0.05, 1.35, "left"), ("pt2", 0.0, 0.74, "center"),
                        ("f3_st_hf", 0.0, 0.60, "center")]:
    r = [q for q in DEV if q[0] == seq][0]
    col = {"redundant": C["redundant"], "necessary": C["necessary"],
           "ambiguous": "#8A8A8A"}[r[3]]
    axc.text(r[1] + dx, r[2] * dy, seq, fontsize=4.8, color=col, ha=ha, va="center", zorder=5)
axc.set_yscale("log"); axc.set_ylim(0.4, 240); axc.set_xlim(0.0, 3.25)
axc.set_xlabel("mask-free arm's own RPE (cm/frame)", fontsize=6.0)
axc.set_ylabel("mask necessity  $N$", fontsize=6.0)
axc.tick_params(labelsize=5.6)
axc.legend(fontsize=5.0, loc="upper left", handlelength=1.2, borderaxespad=0.2, ncols=2)

for ax, lab, xy in [(axa, "a", (-0.09, 1.10)), (axb, "b", (-0.09, 1.10)),
                    (axc, "c", (-0.045, 1.14))]:
    ax.text(*xy, lab, transform=ax.transAxes, fontsize=8,
            fontweight="bold", color=C["ink"], ha="right")

save(fig, "fig5_controlled_v3")
