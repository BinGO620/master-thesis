#!/bin/bash
# 编译论文 1（MMM 2027 / Springer LNCS）。
#
# 用法：
#   ./build.sh           编译主文，产出 build/main_v3.pdf
#   ./build.sh --clean   清掉 build/
#
# 为什么产物放 build/：源码目录保持干净，交源码时不会把中间文件一起打进去。
#
# 编辑器：tectonic（xelatex 系不需要，这是 pdflatex 风格，但 tectonic 的 XeTeX 也吃得下）。
# 缺宏包会自动从网上拉，第一次编译需要网络。
set -euo pipefail
cd "$(dirname "$0")"

TECTONIC="${TECTONIC:-/data/conda_envs/tex/bin/tectonic}"

if [ "${1:-}" = "--clean" ]; then
    rm -rf build
    echo "已清理 build/"
    exit 0
fi

mkdir -p build
"$TECTONIC" -X compile --keep-logs --outdir build main_v3.tex

# 失败必须大声失败，绝不能让上一次的旧 PDF 冒充新构建
if [ -f build/main_v3.log ] && grep -q "^!" build/main_v3.log; then
    echo "❌ LaTeX 报错："
    grep -A3 "^!" build/main_v3.log | head -20
    exit 1
fi
[ -f build/main_v3.pdf ] || { echo "❌ 没有产出 PDF"; exit 1; }

# 页数守卫：MMM 规则是正文 12 页 + 参考文献最多 2 页，共 14 页
PAGES=$(pdfinfo build/main_v3.pdf 2>/dev/null | awk '/^Pages/{print $2}')
if [ "$PAGES" != "14" ]; then
    echo "⚠ 页数变成 $PAGES，投稿规则是 14 页（12 正文 + 2 参考文献）"
fi

echo "✅ 构建完成：build/main_v3.pdf（$PAGES 页）"
