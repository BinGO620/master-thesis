MMM 2027 submission assets
==========================

Main manuscript (the only file submitted)
-----------------------------------------
MMM2026_RoGS-SLAM_Main.pdf
  A4, 14 pages total: 12 content pages plus 2 pages of references only.
  Self-contained: every number cited in the text is stated in the paper;
  there are no references to any external supplementary document.

Submission rule (verified against mmm2027.net, Author Information and
Call for Papers, 2026-08-31)
-------------------------------------------------
"Full papers are limited to 12 content pages (including figures, tables
and appendices) with up to 2 additional pages for references."
MMM 2027 has NO supplementary-material or auxiliary-file upload channel;
the only upload is the paper itself via the ConfTool system. All content
must therefore live inside the 12+2 pages.

Internal archive (NOT submitted)
--------------------------------
MMM2026_RoGS-SLAM_Supplementary.pdf
  A4, 11 pages. Kept as internal record of the full protocols, complete
  tables, per-seed diagnostics, and reproducibility evidence. Do not
  submit; do not concatenate to the main paper.

Sources
-------
Main: ../latex/main_v3.tex + ../latex/body_v3.tex
SI (internal): ../latex_si/si_v3.tex + ../latex_si/si_body_v3.tex
