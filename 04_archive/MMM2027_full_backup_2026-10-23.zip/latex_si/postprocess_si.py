#!/usr/bin/env python3
"""Generate a self-contained supplementary-material LaTeX body from supplementary.md."""
from pathlib import Path
import re

p = Path("si_body_v3.tex")
s = p.read_text()
# Map remaining Unicode symbols to LaTeX math commands.
for a, b in {
    "≥": r"$\ge$", "≤": r"$\le$", "×": r"$\times$",
    "↓": r"$\downarrow$", "↑": r"$\uparrow$", "²": r"$^2$",
    "σ": r"$\sigma$", "λ": r"$\lambda$", "μ": r"$\mu$", "̂": "",
}.items():
    s = s.replace(a, b)
# The converter emits escaped code identifiers. Use url's breakable path formatter
# for path-like identifiers only, with a single backslash in the TeX source.
s = s.replace(r"\\path", r"\path")
s = re.sub(r"\\texttt\{([^{}]*[/_][^{}]*)\}",
           lambda m: r"\path{" + m.group(1).replace(r"\_", "_") + "}", s)
# Keep the opening dataset table after the SI title, not above it. Put the final
# S12 table at its section anchor so it does not become an isolated last page.
first_table = "\\begin{table}[t]\\centering\\footnotesize\n"
if first_table in s:
    s = s.replace(first_table, "\\begin{table}[H]\\centering\\footnotesize\n", 1)
last_table = s.rfind("\\begin{table}[t]")
if last_table != -1:
    s = s[:last_table] + s[last_table:].replace("\\begin{table}[t]", "\\begin{table}[H]", 1)
    # The final S12 table is the only isolated element on the last page; make it
    # compact enough to stay with its S12 heading and explanatory paragraph.
    s = s[:last_table] + s[last_table:].replace(
        "\\centering\\scriptsize\\setlength{\\tabcolsep}{3.5pt}",
        "\\centering\\tiny\\setlength{\\tabcolsep}{1pt}\\renewcommand{\\arraystretch}{0.75}", 1)

# Long SI tables use fixed-width, ragged-right columns rather than unbreakable l columns.
s = s.replace(
    r"\begin{tabular}{lp{5.20cm}l}",
    r"\begin{tabular}{>{\raggedright\arraybackslash}p{2.6cm}>{\raggedright\arraybackslash}p{11.0cm}>{\raggedright\arraybackslash}p{2.4cm}}",
)
s = s.replace(
    r"\begin{tabular}{llll}",
    r"\begin{tabular}{>{\raggedright\arraybackslash}p{2.5cm}>{\raggedright\arraybackslash}p{4.0cm}>{\raggedright\arraybackslash}p{4.1cm}>{\raggedright\arraybackslash}p{4.2cm}}",
)
p.write_text(s)
print(f"postprocessed {p}")
