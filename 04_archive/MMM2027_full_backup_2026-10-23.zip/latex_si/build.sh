#!/bin/bash
# 编译补充材料（SI）。SI 是独立文档，不依赖主文的任何文件。
#
# 用法：
#   ./build.sh
# 产物：build/si_v3.pdf
set -euo pipefail
cd "$(dirname "$0")"

TECTONIC="${TECTONIC:-/data/conda_envs/tex/bin/tectonic}"

mkdir -p build
"$TECTONIC" -X compile --keep-logs --outdir build si_v3.tex

if [ -f build/si_v3.log ] && grep -q "^!" build/si_v3.log; then
    echo "❌ LaTeX 报错："
    grep -A3 "^!" build/si_v3.log | head -20
    exit 1
fi
[ -f build/si_v3.pdf ] || { echo "❌ 没有产出 PDF"; exit 1; }

echo "✅ 构建完成：build/si_v3.pdf（$(pdfinfo build/si_v3.pdf | awk '/^Pages/{print $2}') 页）"
