# 论文 1（MMM 2027 / RoGS-SLAM）

这是投稿用的**最新版**，也是提交源码时要打包的那一版。

## 版本确认

源文件与 git tag `mmm2027-submission`（远端和本地备份里都有）逐字节一致：

| 文件 | 与 tag 比对 |
|---|---|
| `latex/main_v3.tex` | ✅ 一致 |
| `latex/body_v3.tex` | ✅ 一致 |
| `latex/references.bib` | ✅ 一致 |
| `latex/llncs.cls` | ✅ 一致 |
| `latex/splncs04.bst` | ✅ 一致 |
| `figures/` 六张图 | ✅ 一致 |

编译产物与已投出的 `papers/MMM2027_RoGS-SLAM_submission.pdf` 逐字一致（`pdftotext` 全文比对）。

## 目录

```
MMM2027/
├── latex/                 ← 投稿包主体
│   ├── main_v3.tex        主文件
│   ├── body_v3.tex        正文（由 manuscript_v3.md 机器生成）
│   ├── references.bib     29 条参考文献
│   ├── llncs.cls          Springer LNCS 文档类
│   ├── splncs04.bst       参考文献样式
│   ├── LLNCS_README.txt   模板说明
│   └── build.sh           一键编译 → build/main_v3.pdf
├── figures/               ← 投稿包主体
│   ├── fig1_pipeline_v3.pdf
│   ├── fig_reliability_v4.pdf
│   ├── fig2_mechanism_v3.pdf
│   ├── fig3_ablation_v4.pdf
│   ├── fig4_controlled_v4.pdf
│   ├── fig5_endpoints_v4.pdf
│   ├── *.png / *.svg         同名其他格式
│   ├── make_*.py             绘图脚本（v4 版对应正文用图）
│   └── archive/              被取代的旧图，不参与编译
├── latex_si/              补充材料（MMM 无 SI 通道，内部留档用）
├── tables/                5 张表的 csv 与 md，含 PROVENANCE
├── manuscript_v3.md       正文 Markdown 源
├── supplementary.md       SI 的 Markdown 源
├── MMM2026_submission/    提交快照
├── checks/                查重 docx、去 AI 痕迹脚本（不参与编译）
├── archive/               历史稿、审稿意见、写作路线图、禁词表
└── README.md              本文件
```

## 编译

```bash
cd latex && ./build.sh          # 产物 build/main_v3.pdf，14 页
cd latex_si && ./build.sh       # SI，11 页
```

## 提交源码时要打的东西

只打 `latex/` 和 `figures/` 就够了，两个目录自包含，不依赖仓库任何其他文件。
已验证：把这两样单独拷到一个空目录，`latex/` 下编译能出 14 页且与投稿件逐字一致。

具体清单：

```
latex/main_v3.tex
latex/body_v3.tex
latex/references.bib
latex/llncs.cls
latex/splncs04.bst
latex/LLNCS_README.txt
figures/fig1_pipeline_v3.pdf
figures/fig_reliability_v4.pdf
figures/fig2_mechanism_v3.pdf
figures/fig3_ablation_v4.pdf
figures/fig4_controlled_v4.pdf
figures/fig5_endpoints_v4.pdf
```

约 416 KB。**不需要**带：png/svg（pdf 版够用）、绘图脚本、tables、archive、checks、
MMM2026_submission。

## 几个坑

**body_v3.tex 是机器生成的。** 它由 `manuscript_v3.md` 经
`scripts/md2latex_manuscript.py` 转出来，那个脚本在仓库整理时被移走了。
改正文请改 md 再重新生成，直接手改 tex 会和 md 失去同步。要找回脚本从 git 历史取。

**tectonic 第一次编译要联网。** 缺的宏包会自动下载。Springer 的 llncs.cls 和
splncs04.bst 是随包带的，不依赖系统 TeX。

**旧版 v2 已移到** `../../04_archive/MMM2027_v2_2026-08-29/`。那一版是 MRCS 时期
（旧标题、旧叙事、22 条文献、23 页超页），不是投稿版，别拿错。

**绘图脚本不能独立复现 v4 图。** `make_v4_fig4_controlled.py` 读的是
`/data/monogs-ours/results/` 下的跑批结果，那些数据不在投稿包里。图本身是 pdf，
投稿不需要重画，脚本只作留档。
