# MRCS — Manuscript draft, **v3 (current — 12-page compression + rewording)**

> **Target**: CCF-C, initially MMM (Springer **LNCS**, `llncs.cls`; 12 pages body + 2 pages
> references). This is the live draft as of 2026-08-29.
>
> **v2 is frozen verbatim in `manuscript.md`** — an asset, not a discard. Every headline
> number in it was re-verified against raw run CSVs on 2026-08-29 by independent
> recomputation bypassing `build_paper_tables.py` (Table 1 key cells, Table 3 all 8 cells,
> EXP56/57 ladder, EXP55/58 kernel verdicts). v3 rewrites section by section for the
> 12-page budget under a fresh figure plan (`FIGURE_PLAN_v3.md`); v2 prose remains the
> fallback for any claim whose wording gets lost in compression. v0/v1 lineage and the
> SI-allocation history are unchanged: see `archive/manuscript_v{0,1}.md`,
> `WRITING_ROADMAP.md` §八-A, and `supplementary.md` §S2–S11.
>
> **Discipline for this file** (project rule, non-negotiable, unchanged by compression):
> 1. Every factual statement about a competitor is traceable to that paper's own text — see
>    `results/evidence/competitor_protocol_table.md` for the quote and line number of each.
>    **Paraphrase from memory is not evidence.**
> 2. Every number about our own system is traceable to a run artifact under `results/`.
> 3. The forbidden-phrase list in `WRITING_ROADMAP.md` §六 applies to every line here.
> 4. **A claim's scope statement travels with the claim.** Compression may move a *table* to the
>    supplement; it may never separate a claim from its caveat.

## Status of sections

| § | Section | Status | Blocked on |
|---|---|---|---|
| 1 | **Introduction** | ✅ **drafted (this file, exp46)** | — (contribution bullets are F1/F2/F3) |
| 2 | **Related Work** | ✅ **drafted (this file)** | — |
| 3 | **Method** | ✅ **drafted (this file, 2026-08-25)** | — (constants **and attachment points** verified against resolved config + source; audit `results/evidence/method_attachment_audit.md` corrected 3 errors and disclosed a 4th component) |
| 4 | **Experimental Protocol** | ✅ **drafted (this file)** | — |
| 5 | **Results / ablations** | ✅ **drafted (this file, exp46; §5.3 added exp54)** | — (ratios tiered by vanilla CV per `headline_ratio_recompute.md`; §5.6 boundary rebuilt on `rpe_stratification_rule_test.md` after the ~2.5 cm/frame threshold was falsified; §5.3 attribution from `exp54_component_attribution_verdict.md`) |
| 6 | **Limitations** | ✅ **drafted (this file, exp46)** | — (14 items: the roadmap's 8 + Δ_L compound scope + fitted boundary + no cue selector + TRC negative + rendering + map-side) |
| 7 | **Conclusion** | ✅ **drafted (this file, exp46)** | — |

---

# 1. Introduction

A moving object supplies photometric and geometric residuals that a rigid-world estimator resolves by moving the camera. Run unmodified, our 3DGS-SLAM backbone drifts to 39.3 cm on the mixed-mover sequence (`balloon`) and 147.5 cm on a crowded one, against roughly 1.5 cm on static scenes. The input is handheld RGB-D video, and it arrives full of uncontrolled content such as balloons, carried boxes, and objects placed and removed. The dominant response detects the movers and removes them. An external, class-conditioned network labels which pixels could move, and the estimator discards them (Sec. 2.1). This works, but it makes the dynamic decision a per-frame classification by a second model, with its cost and failure modes. It is also closed-set, which bites hardest on user-generated content, where the label set is open. Recent lines replace the *class* prior with a learned uncertainty (Sec. 2.2) or move the decision out of the segmentation network (Sec. 2.3).

Our configuration sits in that third line. It decides which pixels to trust from *consistency*, the disagreement between observed optical flow and the flow a rigid scene would produce, and it down-weights rather than removes. Operating without semantic segmentation is not itself a contribution we claim, since prior work has done that. Two kinds of evidence are missing. One shows which of its parts are necessary, and on which sequences. The other separates the mechanism's own effect from the extra information a method was handed.

We present RoGS-SLAM, a mask-free core for dynamic 3DGS-SLAM. On the crowd scenes it tracks at 2.2–2.3 cm where the backbone drifts to 86–147 cm, at 4.0 GB of GPU memory, and its mask-free core needs no category label. Its contributions are the measurements that bound this result:

1. **Component necessity is regime-dependent, and we measured it rather than asserting it.** A
   pre-registered three-factor factorial (8 cells × 5 sequences × 3 seeds = 120 runs) finds that
   uniform keyframe coverage is strongly positive on object-only sequences but negative on the two hardest. Robust reweighting is within seed noise on 3 of 5 sequences
   yet is the single largest effect on `balloon`. The reliability signal
   is the only component never negative anywhere (5 of 5, 3 cells directional).
   No sequence demonstrably rewards all three (0 of 5), so the full bundle is nowhere strictly necessary (Sec. 5.2). The useful subset is
   a function of the regime.

2. **The gain is not attributable to the information alone.** Under an equal, strictly causal budget on the byte-identical frozen flow, a naive per-pixel threshold stably improves on the baseline on only 2 of 4 held-out sequences and is worse on `pt2` (51.07 vs 45.37 cm). Our mechanism improves on 4 of 4 (1.63–4.99×) and beats the naive counterpart on all four (Sec. 5.4), closing the "it just had more information" reading.

3. **The pose-side mechanism is a variance–bias trade, measured on the intermediate
   quantity.** One single-variable intervention, extending the semantic hard tracking mask of the *combined* configuration from 10 to all 100 tracking iterations, moves the per-frame dynamic penalty worse (+0.0806 cm, 1.22× its noise floor) yet full-trajectory error better (−1.42 cm, 4.0×). This rests on one sequence with two legs near their floors (Sec. 5.6). The consequence generalises beyond this system. A pose-side claim must name its endpoint.

The same evidence delimits where the mask-free configuration is not sufficient (Sec. 5.5). We claim no state-of-the-art accuracy, and our full 18-sequence runs include the four sequences where both arms regress against the backbone (Sec. 6).

---

# 2. Related Work

## 2.1 Dynamic SLAM built on explicit dynamic priors

Dynamic SLAM has long followed *detect-then-exclude*. DynaSLAM~\cite{dynaslam} computes a per-pixel segmentation with Mask R-CNN~\cite{maskrcnn}, NGD-SLAM~\cite{ngdslam} uses a YOLO detector, and RoDyn-SLAM~\cite{rodynslam} fuses flow and
segmentation masks. The pattern is widespread in 3DGS dynamic SLAM:
RGD-SLAM~\cite{rgdslam} segments with a pre-trained OneFormer, DG-SLAM~\cite{dgslam} initialises poses from DROID-VO~\cite{droidslam},
and BDGS-SLAM~\cite{bdgsslam},
DAGS-SLAM~\cite{dagsslam} and DynaGSLAM~\cite{dynagslam} build per-Gaussian dynamic priors
from YOLO or SAM2~\cite{sam2} detections.
In every case the dynamic decision is delegated to an external, class-conditioned model, with the costs named in Sec. 1.

## 2.2 Replacing the class prior with a learned uncertainty

WildGS-SLAM~\cite{wildgsslam} drops the category prior while keeping a learned one.
It predicts per-pixel uncertainty from "a pre-trained
DINOv2 feature extractor" and metric depth "as estimated by Metric3D v2". Its own overview defines *Prior Free* as "not using class priors". We apply the same standard to ourselves. Our label is *mask-free*, never *prior-free*, and it, too, keeps a pretrained network (the frozen RAFT flow of Sec. 3.4).

## 2.3 Dynamic decisions from consistency rather than from categories

A third line keeps a segmentation or depth network but moves the *dynamic decision* out of
it, with pre-3DGS roots. ReFusion~\cite{bonn} rejects dynamic residual pixels in a
purely geometric RGB-D pipeline with no learned prior at all. Recent 3DGS systems refine
the same move with learned front ends.
Gassidy~\cite{gassidy} separates objects through the YOLO instance masks, then decides which are dynamic by analysing rendering-loss flows, so
the category label never decides motion. DGS-SLAM~\cite{dgsslamkong} runs an online
Track-Anything segmentation with a photometric-consistency mask.
Dy3DGS-SLAM~\cite{dy3dgsslam} fuses an optical-flow mask with a depth mask from "the
DepthanythingV2 estimation network". GARAD-SLAM~\cite{garadslam} goes furthest, stating that "we do not
perform semantic segmentation on the feature points in the tracking phase". Our
configuration belongs to this line (Sec. 1). The line shows that "mask-free" must be checked per system. Of these four, two still consume a segmentation network and a third a monocular depth network.

The ingredients we combine are each individually classical. Robust M-estimation~\cite{huber}, residual reweighting, and keyframe management all have ample precedent. Our backbone, MonoGS~\cite{monogs}, "maintain[s] a small window W_k" of keyframes and
performs no loop closure. The representation it optimises is 3D Gaussian splatting, and the dynamic systems of Secs. 2.1–2.3 are its SLAM-side descendants, down to SplaTAM~\cite{splatam} and Co-SLAM~\cite{coslam} in Table 1. What is missing is not another robust kernel but the measurements
Sec. 1 named, and cross-system absolute numbers are read only with protocol differences explicit.

---

# 3. Method

RoGS-SLAM adds four components to a 3DGS-SLAM backbone, none of them a new primitive. This
section states what each one changes in the estimator, so the ablations of Sec. 5 read
as interventions on named quantities. Constants are resolved from the run configuration.

## 3.1 Backbone and attachment points

The backbone is MonoGS~\cite{monogs} in its RGB-D configuration. The frontend estimates each frame's pose against a fixed Gaussian map, a 3D Gaussian splatting scene~\cite{3dgs}, and the backend re-optimises Gaussian parameters and the poses of a bounded keyframe window. Classical ORB-SLAM3~\cite{orbslam3} appears in Table 1 as a pre-Gaussian reference. We change neither the representation nor the rasteriser, but we do change the density lifecycle. Four components attach at four distinct places (Fig. 1):
**Uniform keyframe coverage (K)** decides which frames become keyframes. **Robust reweighting (R)** decides how much each pixel's residual counts in the pose solve. The **reliability signal (L)** decides which pixels are trusted as static, and the **lineage
lifecycle (D)** decides which newly created Gaussians survive. L is consumed at two sites (Fig. 1). A fifth, optional
component supplies a semantic person mask (Sec. 3.6). The *mask-free* configuration
disables it, the *combined* one enables it, and we never use a number obtained
with the mask to support a statement about the mask-free system.

> **Figure 1** (`figures/fig1_pipeline_v3.pdf`).
> *Where the components attach.* Grey boxes are the backbone. Blue and orange boxes modify the stage their arrow points into. Dashed grey is the optional semantic mask (combined only, never routed through L) with its three consumers: the mapping loss, the keyframe-insertion gate, and the warm-up-only hard tracking mask of Sec. 5.6. L is consumed at exactly two sites, the pose-solve residual (1) and candidate confirmation in the lifecycle (2).

## 3.2 Coverage: uniform temporal keyframe sampling

MonoGS selects keyframes adaptively by co-visibility, so density is a property of the
scene. Across our five ablation sequences the backbone's native density spans 0.045 to
0.075 keyframes per frame. Coverage adds one rule: more than `gap_cap = 5` frames since the last keyframe force an insert, and the native criterion is floored rather than replaced. Density becomes near-constant at 0.198 to 0.204 keyframes per frame, at a cost of 2.7–4.5× more keyframes and roughly double the map size.

## 3.3 Robust reweighting: Huber IRLS inside the pose solve

R replaces the L2 tracking residual with an iteratively-reweighted least-squares
step~\cite{zhang}. For residual $r$ the weight is the standard Huber~\cite{huber} IRLS
weight
$w_{\text{rob}}(r) = \min(\delta/|r|, 1)$ with $\delta = 0.1$ per channel. It is
computed from a detached residual and recomputed at every tracking iteration, so
the weights co-adapt with the pose, unlike the fixed per-frame map of Sec. 3.4. A
pre-registered ablation (6 sequences spanning five regimes × 2 alternative kernels × 3
seeds = 36 runs) supports Huber over the two other M-estimation kernels the codebase implements. Neither is ever better outside the pre-registered floor, and on `pt2` both degrade clearly, by 1.8 and 2.5 cm.

## 3.4 Reliability: a per-frame, per-pixel static-confidence map

This component consumes optical flow and decides, without any category label, which pixels count as evidence about camera motion (Fig. 2); Fig. 3 shows what this leaves in the final map.

> **Figure 2** (`figures/fig_reliability_v4.pdf`). *The reliability signal, from flows to weights (Sec. 3.4).* The observed flow (frozen RAFT) and the rigid reprojection flow disagree on movers. A per-frame robust MAD normaliser turns the disagreement into the cue $e_{\text{flow}}$, which combines with the depth-residual cue $g$ into the static confidence $s$ and the Cauchy tracking weight (floored at 0.10, never removing). The frozen map is consumed at two sites, the tracking residual and lifecycle confirmation.

**Observed and rigid flow.** For frame $t$ we take a precomputed backward flow
$f_{\text{obs}} = f_{t \to t-1}$ from a frozen RAFT~\cite{raft} network and the rigid-flow
prediction $f_{\text{static}}$ from reprojection through the current depth and ego-motion. The mover shows up in that disagreement, though so can occlusion boundaries and flow error, which the
robust normaliser of the next step absorbs.

**Threshold-free normalisation.** The disagreement magnitude becomes a cue
$e_{\text{flow}} \in [0,1]$ through the per-frame robust normaliser, `max(1.4826·MAD,
floor)`, which maps to 0 at or below the frame median and approaches 1 for robust outliers. The floor (2.0 px) keeps a near-static frame, where MAD collapses, from saturating.

**Combining the cues.** A geometric cue $g$ measures depth-residual anomaly, gated by
opacity $v$ so unmapped regions cannot vote. The two combine into the static confidence
$s = (1 - e_{\text{flow}})(1 - vg)$. A pixel is trusted only if both cues find it
unremarkable, and $s \to 1$ recovers the unmodified estimator. With $d = 1 - s$ the
tracking weight is a frame-adaptive Cauchy down-weight

$$w_{\text{rel}} = \frac{1}{1 + (d/\tau)^2}, \qquad
\tau = \operatorname{median}(d) + 1.4826\,\operatorname{MAD}(d) + \varepsilon,$$

where the knee $\tau$ is a Hampel-type robust z-score. MAD, the median absolute deviation, is a spread estimate that a minority of outliers cannot move, and the same normaliser that defines $e_{\text{flow}}$ prices deviation from the frame's own $d$ distribution.

> **Figure 3** (`figures/fig2_mechanism_v3.pdf`). *What each configuration bakes into the final map.* Top: the observed scene at frame 80 (person mid-sequence)
> and at frame 400 after both movers left. Bottom: each arm's final map rendered at frame 400
> from its own estimated pose. The backbone's map is shredded by the movers' ghost trails
> (circled). Both
> RoGS-SLAM configurations reconstruct the static office, the mask-free one without any class label.
> The two arms' maps are similar here, since they differ in tracking stability, not map appearance
> (ATE annotated, Sec. 5.1). Post-hoc offline renders of each
> run's saved final map, for illustration, not a benchmark metric.

**The weight is bounded away from zero.** What multiplies the residual is
$\max(w_{\text{rel}}, 0.10)$, so a pixel is attenuated by at most 10× and never removed. This is the sharpest difference from a mask and the comparison Sec. 5.4 leans on.

**When it is computed, and where it is consumed.** The map is computed once per frame
after `warmup_iters = 10` tracking iterations and then frozen. Without frozen flow,
$w_{\text{rel}} \equiv 1$ and the estimator is unchanged. It is consumed at
two sites. At the **tracking residual**, $\max(w_{\text{rel}}, 0.10)$ multiplies
the Huber weight of Sec. 3.3 in both channels, and at **candidate confirmation** in the
lifecycle of Sec. 3.5, $s$ weights the evidence. The ablation
removes this pair of interventions sharing one signal.

**Where the robust knee breaks.** $\tau$ is a *majority* statistic. A mover occupying
a large share of the frame joins the population that sets its own knee, which is one reason the mask stays dominant on mixed-mover sequences (Sec. 5.1).

## 3.5 The density lifecycle

The backbone commits every new Gaussian immediately. Our configuration replaces that commit
rule. Each Gaussian created at a keyframe carries a **lineage** identifier that accumulates
support and contradiction evidence. A lineage is retained after 2 units of support
(`confirming_views`) and deleted in full after 2 units of contradiction
(`reject_contradictions`) or 5 unconfirmed keyframes (`ttl_keyframes`), with $s$ weighting
the evidence when reliability is enabled. The replacement is materially active, since the deleted fraction of created lineages has median 0.55. A comparison against stock MonoGS therefore compares a different density rule.

## 3.6 The optional semantic mask, and the simpler configuration

In the *combined* configuration a Mask R-CNN~\cite{maskrcnn} person mask (dilated by
7 px) reaches three consumers: the **mapping loss**, the **keyframe-insertion gate**,
and the **tracking residual**. The last is a hard mask only for the first `warmup_iters` tracking
iterations, after which the soft weight of Sec. 3.4 takes over the
person region and the hard mask disengages. The switch between *mask-free* and
*combined* opens these paths inside *this* component only, never the reliability
signal. Holding the hard mask on for all tracking iterations instead (the
single-variable intervention of Sec. 5.6) keeps the hard-excluded region removed while
the soft reliability weight continues to apply on surviving static pixels, so the two
cues compose rather than replace each other. The attribution campaign uses
a third, *simpler* configuration
(native sparse keyframes, robust reweighting, the lifecycle, and the mask applied only at
the mapping loss) relative to which *combined* flips the three switches of coverage,
reliability, and insertion-gate masking. Sec. 5.3 measures the first two in isolation.
We report *mask-free*, *combined*, and *simpler* as configurations of one system. All sixteen constants, one of them a disclosed-inert threshold, are resolved from the run configuration.

---

# 4. Experimental Protocol

Decisions below were frozen before the campaigns of Sec. 5 ran.

**Sequences.** 18 RGB-D sequences (8 BONN RGB-D Dynamic~\cite{bonn}, 10 TUM RGB-D~\cite{tumrgbd}), spanning static, low-motion, high-motion and *object-only* scenes. The denominator is fixed, no campaign may select a subset after seeing results, and the object-only movers carry no person label.

**Trajectory accuracy.** Full-trajectory absolute-trajectory error (ATE) RMSE (cm) via `evo`~\cite{evo} after SE(3) Umeyama alignment~\cite{umeyama} without scale correction. ATE covers all frames, and we also report the relative pose error (RPE, translation, per frame).

**Seeds and completion.** Every configuration runs with 3 seeds (mean ± sd, spreads reaching 2× flagged). A run counts as completed only at ≥ 95% of frames, and a pair with fewer than two co-completed seeds is *unresolved*, not dropped.

**Rendering, efficiency, hardware.** Rendering metrics are computed offline from the final map, and refinement does not touch the reported trajectory. Efficiency is reported from the online phase and compared only on identical hardware. Flow is precomputed by a frozen RAFT~\cite{raft} network, so RAFT inference is not in the online rate (Sec. 5.7). All campaigns ran on an RTX 3090, and each reported cell maps to exactly one run directory.

---

# 5. Results

## 5.1 Trajectory accuracy under one protocol (Table 1)

**On the crowd scenes, combined tracks at 2.3/2.2 cm where the unmodified backbone drifts to 86.5/147.5 cm.** Table 1 compares all reproduced methods on four BONN dynamic scenes. On crowd, combined is the best RGB-D 3DGS configuration (4.4 cm average), although CPU-side NGD-SLAM and DynaSLAM have lower averages of 3.2 and 4.0 cm and produce no dense map. Crowd is the mask-dominant regime (34.9/45.9 cm mask-free). On the object-only scene the segmentation-free arms are unaffected (2.7/3.1), while DynaGSLAM pays for its person-only detector (12.1). On `pt2`, combined trails WildGS-SLAM (10.4 vs 3.1) and DG-SLAM (6.1), while mask-free is better than combined (9.3).

**Table 1.** ATE RMSE (cm, mean ± sd, 3 seeds) on four BONN dynamic scenes, grouped by representation and dynamic handling. Every row, competitors included, is our own reproduction under one protocol. Reading our rows: *combined* is the full system, *mask-free* its core without the optional semantic mask (Sec. 3.6). **Bold** marks the lowest ATE per column. Avg and GPU are unranked, since they mix modalities and hardware. div. = diverged. GPU memory: ours and RGD-SLAM share one RTX 3090, the only same-hardware pair. Other rows ran on other hardware and are not comparable across rows. Method citations: Secs. 2.1–2.3.

| Method | crowd | crowd2 | mv_no_box | pt2 | Avg. | GPU (GB) |
|---|---:|---:|---:|---:|---:|---:|
| _Ours, dynamic 3DGS_ | | | | | | |
| RoGS-SLAM combined (ours) | 2.3±0.0 | 2.2±0.1 | 2.7±0.1 | 10.4±0.8 | 4.4 | 4.0±1.0 |
| RoGS-SLAM mask-free (ours) | 34.9±28.3 | 45.9±17.4 | 3.1±0.5 | 9.3±0.6 | 23.3 | 3.4±1.0 |
| _Dynamic 3DGS_ | | | | | | |
| RGD-SLAM | 2.6±0.3 | 2.4±0.1 | 2.3±0.3 | 23.0±3.7 | 7.6 | 7.4±1.1 |
| DG-SLAM | 5.8±0.1 | 6.4±0.5 | 3.0±0.1 | 6.1±0.1 | 5.3 | 7.3±0.4 |
| DynaGSLAM | 23.8±0.0 | 13.7±0.0 | 12.1±0.0 | 13.7±0.0 | 15.8 | 2.2±0.7 |
| WildGS-SLAM (mono) | **1.55±0.06** | **2.17±0.05** | **1.6±0.0** | **3.1±0.0** | 2.1 | 12.1±1.9 |
| _Dynamic, non-3DGS_ | | | | | | |
| RoDyn-SLAM (NeRF) | 5.6±0.2 | 4.6±0.1 | 16.5±7.1 | 14.4±0.1 | 10.3 | 1.0±0.1 |
| DynaSLAM (CPU) | 2.1±0.2 | 2.8±0.3 | 2.3±0.1 | 8.8±1.2 | 4.0 | — |
| NGD-SLAM (CPU) | 1.8±0.2 | 2.2±0.1 | 2.0±0.1 | 6.6±0.4 | 3.2 | — |
| _Static_ | | | | | | |
| SplaTAM | 135.4±36.1 | 493.2±470.7 | 37.4±0.4 | 132.7±9.4 | 199.7 | 6.9±7.4 |
| MonoGS (unmodified) | 86.5±18.3 | 147.5±39.0 | 15.3±9.5 | 43.8±8.6 | 73.3 | 0.5±0.2 |
| Co-SLAM (implicit) | div. | div. | 10.1±0.3 | 71.3±2.9 | 40.7 | 1.1±0.0 |
| ORB-SLAM3 (sparse) | 76.6±27.9 | 111.4±14.8 | 24.9±5.9 | 76.8±2.1 | 72.4 | — |



**Where the mask matters, measured between our own two arms.** The ratio
$N = \text{ATE}_{\text{mask-free}} / \text{ATE}_{\text{combined}}$ never passes through
the vanilla denominator, so it is quotable wherever both arms ran. On the six BONN dynamic sequences beyond the crowd pair above, the
mask is redundant on `mv_no_box2`, `mv_no_box` and `pt2` (0.89–1.17×) and dominant
on `balloon2`, `pt1` and `balloon` (1.92–3.96×). Sec. 5.5 tracks this split with a
per-frame observable across all 18 sequences.

## 5.2 Component necessity is regime-dependent (Fig. 4)

The pre-registered factorial varies K, R, and L (8 cells × 5 sequences × 3 seeds = 120 runs). It runs mask-free, with D pinned identically in all cells. Writing the removal effect of component $f$
on sequence $s$ as

$$\Delta_f(s) = E[\log \text{ATE} \mid f \text{ removed}, s] - E[\log \text{ATE} \mid \text{full}, s],$$

positive $\Delta_f$ means removing $f$ hurts. Two questions follow: whether any single
component is globally necessary ($\Delta_f(s) \ge 0\ \forall s$), and whether any sequence rewards
the full bundle ($\Delta_f(s) \ge 0\ \forall f$). With 3 seeds per cell neither question
receives an inferential answer, so we apply a descriptive support rule. A cell supports a component only where $|\text{mean}| \ge 1$ sd. Fig. 4
marks a cell that fails the rule with $\circ$, and cells marked $\circ$ are directional, i.e. undetermined rather than negative.
Under this rule neither necessity reading is established. $\Delta_L$ is positive on 5 of 5
sequences (the only component with that property, though 3 of the 5 cells are
directional), and no sequence has all three components supported (0 of 5), so the full bundle is nowhere strictly necessary across the five measured sequences. Crowd is absent from this factorial. The crowd evidence is the crowd2 ladder of Sec. 5.3.

> **Figure 4** (`figures/fig3_ablation_v4.pdf`).
> *Component necessity is regime-dependent.* For each sequence,
> ATE RMSE (cm, log scale) of the full mask-free configuration (K·R·L) and of the three
> single-component removals, from the pre-registered factorial (8 cells × 5 sequences × 3 seeds
> = 120 runs). Bars are 3-seed means with ±1 sd error bars, and every bar is the factorial's own campaign. Removing coverage (−K) raises ATE by 1.3–2.1× on the three easier sequences
> yet lowers it on `balloon` and `pt1`. Removing robust reweighting (−R) is the largest effect
> in the matrix on `balloon` (2.2×) and within seed noise on the three easier ones. Removing
> the reliability signal (−L) never helps (5 of 5). ∘ marks a removal whose mean log-shift is
> within 1 sd of its seed spread, i.e. directional only (Sec. 5.2). No sequence rewards all
> three components (0 of 5).

$\Delta_K > 0$ strongly on the
object-only sequences and `pt2` yet $\Delta_K < 0$ on `balloon` and `pt1`. $\Delta_R$ is
not distinguishable from zero at three seeds on the three easier sequences yet is the largest effect in the
matrix on `balloon` (+0.780±0.037). $\Delta_L$ is the only one never negative (5/5), costing 1.19–1.34× on `pt2` and `balloon`. When L is off, both of its consumption sites go off with it (site 2 reverts to integer counts), so $\Delta_L$ is the joint effect of L's two sites (Sec. 3.4). Two further results belong beside these marginals. A two-by-two ablation over mask and coverage on `balloon` moves ATE fourfold along the mask axis and not at all along the coverage axis (3.06 vs 3.03 cm), so we do not describe coverage as the kernel. And a cue-split factorial finds geometry-only lower than the shipped fusion on 3 of 4 sequences, so fixed cue fusion is not universal.

## 5.3 Single-variable attribution

The full ladder is descriptive and covers two sequences (24 runs). On `mv_no_box`, coverage
alone recovers the full arm's advantage (2.71±0.04 vs 2.63±0.09 cm, within the
pre-registered floor). On `crowd2`, no tested subset comes close (coverage 5.16,
reliability 6.00, pair 4.55, insertion gating 5.66, full 2.11 cm), so the crowd gain is attributed to the bundle. These cells are attribution-campaign anchors. The 18-sequence denominator reads 2.19±0.09 (crowd2) and 2.65±0.12 (mv_no_box), inside the drift discipline (we budget ~30%: audited same-configuration anchors have moved by up to ~15% between campaigns, and a same-seed re-run by 1.36×), and the 18-sequence campaign is canonical.

## 5.4 The gain is not the flow information alone (Fig. 5a)

To isolate the gain from the information, the counterpart consumes
the same frozen backward flow, byte for byte, through a naive p90 threshold (frozen on pilot sequences) as a hard mask in place of our weighting. The control comprises 3 arms × 4 sequences × 3 seeds = 36 runs, rule fixed before the first.

The naive counterpart stably beats vanilla on only 2 of 4 under the all-seeds-same-sign rule and is worse on `pt2` (51.07 vs 45.37 cm, a 1.13× flow-mask/vanilla ratio). Ours improves on all four (1.63–4.99×) and beats the counterpart on all four. Every cell here, vanilla included, comes from the control's own campaign. The 18-sequence campaign's vanilla on `pt2` reads 43.85±8.55, a cross-campaign gap inside the drift discipline of Sec. 5.3, and ratios here divide same-campaign cells. The counterpart also lacks the MAD normaliser and geometric cue and uses hard removal, so the control rules out the information alone, not every flow-consuming treatment.

## 5.5 Where mask-free stops being sufficient (Fig. 5b)

We test whether the mask-free arm's own per-frame RPE tracks that split. Across all 18 sequences, necessity is read as $N$ ($N \ge 1.5$ necessary, $N \le 1.2$ redundant).

The groups do not overlap, spanning 0.222–1.572 against 1.717–2.980 cm/frame. Every threshold in
between separates all 17 decided sequences. `f3_st_hf` and `crowd` have nearly identical
mask-free ATE yet $N$ values differing 12.6-fold. Per-frame drift tracks mask necessity,
and accumulated error does not.

> **Figure 5** (`figures/fig4_controlled_v4.pdf`).
> *Two controlled comparisons.* (a) Flow-budget counterpart (Sec. 5.4): ATE RMSE
> (cm, log scale) when the same byte-identical frozen flow is consumed by nothing (vanilla),
> a naive p90 threshold, or our weighting. Dots are seeds, bars are 3-seed means (±1 sd).
> On `pt2` the naive threshold is worse than vanilla (51.1 vs 45.4 cm) while ours is 5.0×
> better, and ours stays below parity on all 12 seeds. (b) Mask necessity $N$ against the
> mask-free arm's own per-frame RPE (Sec. 5.5). The two groups do not overlap. The grey band is the empirical gap and the dashed line is the pre-registered midpoint $\tau$. Black-edged markers
> are the first-round held-out checks (5), of which four agree and one lands in the band, undecidable.

**Scope of the interval.** The interval requires running the mask-free arm, which makes it a post-hoc diagnosis rather than a selector. Its pre-registered midpoint ($\tau = 1.6445$ cm/frame) was tested on two rounds of unseen sequences (5, then 6, all outside the denominator). The ambiguity band is the open interval $(1.2, 1.5)$, and $N \le 0.8$ is the frozen-sense line. One first-round sequence lands in the band, undecidable, so 10 remain. Eight of the 10 agree in direction (4 of 4 decidable in round one, the black-edged points in Fig. 5b with one in-band, and 4 of 6 in round two), and both misses are conservative. No RPE fell inside the band, whose location is untested.

## 5.6 The pose-side mechanism

> **Figure 6** (`figures/fig5_endpoints_v4.pdf`).
> *One intervention, three pose-side endpoints, opposite signs (Sec. 5.6).* Shift on `balloon` from
> holding the semantic hard tracking mask on for all 100 tracking iterations instead of 10
> (intervention minus control, raw units per endpoint, grey band ±1 re-run noise floor of
> that endpoint). The per-frame dynamic penalty moves worse (+0.0806 cm/frame, 1.22× floor),
> the coherent amplitude lower (−0.0248 cm, 1.38×), and full-trajectory ATE better (−1.42 cm,
> 4.0×). This is the variance–bias trade of Sec. 5.6, measured on one sequence with two legs near their floors.

One intervention holds the semantic hard tracking mask of combined on for 100 tracking iterations instead of 10, with soft reliability retained on surviving static pixels. It changes three pose-side endpoints (Fig. 6). The *per-frame dynamic penalty*, median RPE on high-dynamic frame pairs minus median RPE on low-dynamic pairs (cm per frame), moves worse (+0.0806, 1.22× floor). The *coherent amplitude*, mean cosine similarity between consecutive RPE vectors times median |RPE| on the high-dynamic pairs (cm), moves lower (−0.0248, 1.38×). Full-trajectory ATE moves better (−1.42 cm, 4.0×). The measurement is consistent with a variance–bias trade but rests on `balloon` alone, two legs near their floors. Writing $e_t=b_t+\varepsilon_t$ with zero-mean $\varepsilon_t$, suppressing pixels can raise per-frame noise while lowering the systematic pull that accumulates into drift. A tracking claim must therefore name its endpoint.

## 5.7 Rendering and cost

Combined runs at 0.75±0.09 FPS and 4.02±1.01 GB on the same RTX 3090, within one sd of mask-free (0.77±0.21, 3.43±0.99). Mask R-CNN runs online, cached per keyframe, and precomputed RAFT (54 ms/frame) is excluded. Across 18 sequences, post-hoc renders show full-frame PSNR ranking the ghost-carrying backbone above both arms (19.1 vs 18.8/18.6 dB), so PSNR is read as map self-consistency, never trajectory evidence. Depth-L1, the one rendering metric co-ordered with ATE, improves from 46.9 to 31.4–32.3 cm, a geometry gain usable downstream.

---

# 6. Limitations



**1. Where our arms lose.** On `pt1`, mask-free reaches 32.41±8.52 cm against the mask's 11.89±2.36 (`pt2` needs no mask). On four of the 18 sequences both arms are worse than the backbone: `f3_st_hf` an order of magnitude (35.59/29.43 vs 2.80 cm), the others 1.1–2.8× (the `f3_st_hf` exception is recoverable, to 2.67±0.27 cm at a larger async budget).

**2. Accuracy scope.** Combined trails the best RGB-D comparator by 1.0–1.7× on the walking and person sequences (`f3_wk_hf` 3.29 vs 3.25 for RGD-SLAM and `pt2` 10.45 vs 6.1 for DG-SLAM), and monocular WildGS-SLAM by 3.4× on `pt2`.

**3. Static scenes.** On Replica~\cite{replica}, outside the denominator, combined is worse and less stable than the backbone (`office0` 3.82±4.58 vs 0.368±0.012 cm), so use it only when no dynamic content is present.

**4. Operating conditions.** On 8/18 sequences baseline CV exceeds 20%, making ratios basin-dependent (Sec. 4).

**5. Crowd attribution and scope.** The crowd gain is attributable to the bundle, since no single component recovers it (Sec. 5.3, descriptive). Evidence comes from one MonoGS implementation, and semantic area, the simplest cue selector tested, does not separate the regimes.

---

# 7. Conclusion

We presented RoGS-SLAM, a mask-free core for dynamic 3DGS-SLAM, and the measurements that bound it: component necessity is regime-dependent, the gain does not follow from the information alone, and pose-side claims must name the endpoint. The regime split holds within the stated limits, the RPE separation stays post-hoc, and a mask-free cue selector is future work.

---

# Evidence appendix (not part of the submitted paper)

Anchors for every competitor statement in §2. Line numbers are from
`pdftotext resources/01-references/<X>.pdf`; full quotes in
`results/evidence/competitor_protocol_table.md` §3.

| Claim in §2 | Source |
|---|---|
| DynaSLAM uses Mask R-CNN for pixel-wise semantic segmentation | DynaSLAM L199, L208–209 |
| NGD-SLAM uses YOLO detection | NGD-SLAM L72 |
| RoDyn-SLAM fuses optical-flow mask with semantic segmentation mask | RoDyn-SLAM L92–93 |
| RGD-SLAM uses COCO-pretrained OneFormer | RGD-SLAM L568, L363 |
| DG-SLAM uses OneFormer + DROID-VO + DROID-VO keyframe selection | DG-SLAM L804, L83, L805–806 |
| DG-SLAM runs dense BA upon completion of tracking | DG-SLAM L91–92 |
| BDGS-SLAM uses YOLOv5 + Bayesian per-Gaussian prior | BDGS-SLAM L49 |
| DAGS-SLAM fuses YOLO instance priors, on-demand scheduler | DAGS-SLAM L14, L607 |
| DynaGSLAM uses RAFT blobs + SAM2, poses from DynoSAM unmodified | DynaGSLAM L261–268 |
| WildGS-SLAM uses finetuned 3D-aware DINOv2 + Metric3D v2 | WildGS-SLAM L291–293, L306 |
| WildGS-SLAM "Prior Free" definition (class priors only) | WildGS-SLAM Table 7 caption |
| WildGS-SLAM is monocular; final global BA after all frames | WildGS-SLAM L24; "Final Global BA" |
| Gassidy separates objects via YOLO instance masks, then decides motion from rendering-loss flows | Gassidy L170 |
| Dy3DGS-SLAM fuses optical-flow mask with depth mask from DepthAnythingV2 | Dy3DGS-SLAM L164 |
| GARAD-SLAM performs no semantic segmentation on tracking feature points | GARAD-SLAM L68 |
| Co-SLAM global BA over all past keyframes | Co-SLAM L106, L43 |
| MonoGS keyframe window $W_k$ / no pretrained predictor / no loop closure | MonoGS L393, L103, L521+L526 |

Anchors for §3 (our own method). Every constant and every attachment point was read back from the
resolved configuration of a reported run and from the source, **not** from prose; the full audit,
including three errors it corrected in an earlier draft of this section, is
`results/evidence/method_attachment_audit.md`.

| Claim in §3 | Source |
|---|---|
| `gap_cap = 5`, keyframe density 0.045–0.075 → 0.198–0.204 kf/frame | `scripts/measure_keyframe_coverage.py`; resolved `DynamicKeyframe` |
| Huber IRLS, $\delta_{\text{rgb}}=\delta_{\text{depth}}=0.1$, detached, per-iteration | `utils/slam_utils.py:439-453` `_robust_irls_weight`; resolved `RobustTracking` |
| $s=(1-e_{\text{flow}})(1-vg)$, MAD normaliser, `flow_scale_floor = 2.0` | `utils/reliability_signal.py`; resolved `ReliabilitySignal` |
| computed once per frame at `warmup_iters = 10`, then frozen | `utils/slam_frontend.py:1136-1141` |
| **site 1** — tracking RGB *and* depth residual, weight floored at 0.10 | `utils/slam_frontend.py:1213,1294-1310` → `utils/slam_utils.py:541-594` (`static_conf = clamp(w, 0.10, 1)`) |
| **site 2** — reliability-weighted candidate confirmation $C^\pm$ | `utils/slam_frontend.py:1284-1290` (stash) → `utils/deferred_commit.py:141-144,427-456` |
| reliability off ⇒ confirmation reverts to integer counts | `utils/deferred_commit.py:17-29`; E0 gate table in `wpa_reliability_contribution.md` §1 |
| mapping loss + insertion gate belong to `SemanticMask`, not to reliability | `utils/slam_backend.py:429,484` → `utils/semantic_mask.py:88`; `utils/slam_frontend.py:863-870` |
| hard mask active only before `warmup_iters` | dispatch in `utils/slam_utils.py:132-154` (`hard_tracking_mask` unset ⇒ soft branch bypasses it) |
| lineage lifecycle: 3 arms, `immediate` = stock MonoGS | `utils/deferred_commit.py:35-56` `lifecycle_mode` docstring |
| deleted-lineage fraction median 0.55, range 0.27–0.81; contradiction median 6%, max 15% | 45 × `results/runs/P6/**/deferred_commit_summary.json` |
| withheld-candidate variant worse on 4/6 sequences (not adopted) | `our_method/03-results.md` R2-P01-E2 / E2 full-length row |
| `occ_tighten_thresh = 2.0` inert (twice over) | `utils/slam_frontend.py:1647,1657-1661`; `dyn_cov` ∈ [0,1] at `:863-870` |

Anchors for §4 (our own protocol):

| Claim in §4 | Source |
|---|---|
| SE(3) Umeyama, no scale for RGB-D | `utils/eval_utils.py:95` `align_trajectory(..., correct_scale=monocular)`, monocular=False |
| ATE = full-trajectory `ate_rmse_cm` | `tracking_raw.csv` schema; console KF-RMSE is a different quantity |
| 95% completion gate | `results/evidence/wpa_factorial_prereg.md`, `wpm_maskonly_prereg.md` |
| run-to-run 15.72 vs 21.42 cm, 873/873 both | `results/evidence/main_table_provenance_audit.md` |
| latest-run provenance rule + duplicate footer | `scripts/build_18seq_main_table.py:read_ate` + table footer |
| online-phase efficiency definition | `efficiency_raw.csv` notes field; `efficiency_stability_tables.md` |
| keyframe coverage measurement | `scripts/measure_keyframe_coverage.py` |
| refinement does not optimise poses | `utils/slam_backend.py: color_refinement()` (steps `gaussians.optimizer` only) |

Anchors for §5.3 (single-variable attribution, EXP53/EXP54; all runs on jiangwenheng RTX 3090,
`status=OK`, judged per the frozen pre-registrations):

| Claim in §5.3 | Source |
|---|---|
| simpler-arm definition (sparse KF, huber, prune lifecycle, mask at mapping loss only) | `results/evidence/exp52_p11_prereg.md` §4; `configs/rgbd/experiments/p11_maskonly/` |
| arm definitions + frozen floor `max(0.43, 6%·max)` | `results/evidence/exp54_component_attribution_prereg.md` §2, §6 |
| mv_no_box: +coverage 2.7097±0.0441 ≈ full 2.6336±0.0933 (Δ=0.08 < floor); +reliability 3.4637±0.2474 vs simpler 3.6526±0.3259 (Δ=−0.19 < floor) | `exp54_component_attribution_verdict.md` §1–§2.2 |
| crowd2: +coverage 5.1570±2.2514, +reliability 5.9951±2.1089 vs full 2.1086±0.0797 | `exp54_component_attribution_verdict.md` §1–§2.1 |
| 12/12 runs OK, rc=0; intervention arms verified active (KF counts, keyframe_diag crisis, reliability frames) | `exp54_component_attribution_verdict.md` §1, §3 |
| reliability arm switches both consumption sites (joint effect) | `exp54_component_attribution_prereg.md` §2 |
| sequence selection preceded attribution (EXP53 screen: full arm clearly better on 2 of 5) | `exp53_p11phase2_verdict.md` §2 |
| frame counts per sequence | loader `num_frames`, cross-checked constant across all runs of each sequence |

---

**Draft status: v2, exp46/exp47 (2026-08-26) + exp54 integration (2026-08-28: new §5.3
single-variable attribution, simpler-configuration defined in §3.6, Limitations §9,
cross-references renumbered 5.3→5.8, Tables 2–4 renumbered). All seven sections selected down from v0,
figures and references finalized in v2: `latex/main_v2.tex` builds to **23 pages** under
`llncs.cls` (real figures + verified bibliography in place; compression deferred by user
decision — the LNCS limit is 12 pages body + 2 pages references, and the compression plan
lives in `WRITING_ROADMAP.md` §四-A).
The build chain also caught a silent fault worth knowing about: XeTeX was
dropping every Unicode minus sign, which would have printed §5.2's load-bearing
Δ_K(balloon) = −0.182 as "0.182"; the converter now refuses to emit non-ASCII at all.
Calibration and the full defect list: `results/evidence/latex_page_rate_calibration.md`.
Regenerate the body with
`scripts/md2latex_manuscript.py papers/maskfree_bundle/manuscript.md --out papers/maskfree_bundle/latex/body_v2.tex --figdir papers/maskfree_bundle/figures`.
Version records: `archive/manuscript_v0.md` (exhaustive), `archive/manuscript_v1.md`
(selected, 18-page build), `archive/skeleton_exp21.md` (exp21-era skeleton, threshold
retracted in place).**